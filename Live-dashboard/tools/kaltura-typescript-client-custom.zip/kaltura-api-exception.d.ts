import { KalturaObjectBase, KalturaObjectMetadata } from './kaltura-object-base';
export declare class KalturaAPIException extends KalturaObjectBase {
    code: string;
    message: string;
    args: any;
    constructor(code?: string, message?: string, args?: any);
    protected _getMetadata(): KalturaObjectMetadata;
}
