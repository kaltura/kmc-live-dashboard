"use strict";
var tslib_1 = require("tslib");
var kaltura_types_factory_1 = require("./kaltura-types-factory");
var kaltura_object_base_1 = require("./kaltura-object-base");
var KalturaAPIException = (function (_super) {
    tslib_1.__extends(KalturaAPIException, _super);
    function KalturaAPIException(code, message, args) {
        var _this = _super.call(this) || this;
        _this.code = code;
        _this.message = message;
        _this.args = args;
        return _this;
    }
    KalturaAPIException.prototype._getMetadata = function () {
        var result = _super.prototype._getMetadata.call(this);
        Object.assign(result.properties, {
            code: { readOnly: true, type: 's' },
            message: { type: 's' }
        });
        return result;
    };
    return KalturaAPIException;
}(kaltura_object_base_1.KalturaObjectBase));
exports.KalturaAPIException = KalturaAPIException;
kaltura_types_factory_1.KalturaTypesFactory.registerType('KalturaAPIException', KalturaAPIException);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImthbHR1cmEtYXBpLWV4Y2VwdGlvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLGlFQUE4RDtBQUM5RCw2REFBaUY7QUFDakY7SUFBeUMsK0NBQWlCO0lBQ3RELDZCQUFtQixJQUFhLEVBQVMsT0FBZ0IsRUFBUyxJQUFVO1FBQTVFLFlBQ0ksaUJBQU8sU0FDVjtRQUZrQixVQUFJLEdBQUosSUFBSSxDQUFTO1FBQVMsYUFBTyxHQUFQLE9BQU8sQ0FBUztRQUFTLFVBQUksR0FBSixJQUFJLENBQU07O0lBRTVFLENBQUM7SUFFUywwQ0FBWSxHQUF0QjtRQUVJLElBQU0sTUFBTSxHQUFHLGlCQUFNLFlBQVksV0FBRSxDQUFDO1FBQ3BDLE1BQU0sQ0FBQyxNQUFNLENBQ1QsTUFBTSxDQUFDLFVBQVUsRUFDakI7WUFDSSxJQUFJLEVBQUcsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUU7WUFDcEMsT0FBTyxFQUFHLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRTtTQUMxQixDQUFDLENBQUM7UUFFUCxNQUFNLENBQUMsTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFDTCwwQkFBQztBQUFELENBakJBLEFBaUJDLENBakJ3Qyx1Q0FBaUIsR0FpQnpEO0FBakJZLGtEQUFtQjtBQWtCaEMsMkNBQW1CLENBQUMsWUFBWSxDQUFDLHFCQUFxQixFQUFDLG1CQUFtQixDQUFDLENBQUMiLCJmaWxlIjoia2FsdHVyYS1hcGktZXhjZXB0aW9uLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgS2FsdHVyYVR5cGVzRmFjdG9yeSB9IGZyb20gJy4va2FsdHVyYS10eXBlcy1mYWN0b3J5JztcbmltcG9ydCB7IEthbHR1cmFPYmplY3RCYXNlLCBLYWx0dXJhT2JqZWN0TWV0YWRhdGEgfSBmcm9tICcuL2thbHR1cmEtb2JqZWN0LWJhc2UnO1xuZXhwb3J0IGNsYXNzIEthbHR1cmFBUElFeGNlcHRpb24gZXh0ZW5kcyBLYWx0dXJhT2JqZWN0QmFzZSB7XG4gICAgY29uc3RydWN0b3IocHVibGljIGNvZGU/OiBzdHJpbmcsIHB1YmxpYyBtZXNzYWdlPzogc3RyaW5nLCBwdWJsaWMgYXJncz86IGFueSkge1xuICAgICAgICBzdXBlcigpO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBfZ2V0TWV0YWRhdGEoKSA6IEthbHR1cmFPYmplY3RNZXRhZGF0YVxuICAgIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gc3VwZXIuX2dldE1ldGFkYXRhKCk7XG4gICAgICAgIE9iamVjdC5hc3NpZ24oXG4gICAgICAgICAgICByZXN1bHQucHJvcGVydGllcyxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBjb2RlIDogeyByZWFkT25seTogdHJ1ZSwgdHlwZTogJ3MnIH0sXG4gICAgICAgICAgICAgICAgbWVzc2FnZSA6IHsgdHlwZTogJ3MnIH1cbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxufVxuS2FsdHVyYVR5cGVzRmFjdG9yeS5yZWdpc3RlclR5cGUoJ0thbHR1cmFBUElFeGNlcHRpb24nLEthbHR1cmFBUElFeGNlcHRpb24pOyJdfQ==
