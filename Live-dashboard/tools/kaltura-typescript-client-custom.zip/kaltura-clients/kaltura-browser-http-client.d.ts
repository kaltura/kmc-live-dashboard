import { KalturaRequest } from '../kaltura-request';
import { KalturaMultiRequest } from '../kaltura-multi-request';
import { KalturaMultiResponse } from '../kaltura-multi-response';
import { CancelableAction } from '../utils/cancelable-action';
import { KalturaHttpClientBase, KalturaHttpClientBaseConfiguration } from './kaltura-http-client-base';
export interface KalturaBrowserHttpClientConfiguration extends KalturaHttpClientBaseConfiguration {
}
export declare class KalturaBrowserHttpClient extends KalturaHttpClientBase {
    constructor(config: KalturaBrowserHttpClientConfiguration);
    protected _createCancelableAction(data: {
        endpoint: string;
        headers: any;
        body: {};
        type: any;
    }): CancelableAction;
    request<T>(request: KalturaRequest<T>): Promise<T>;
    multiRequest(requests: KalturaRequest<any>[]): Promise<KalturaMultiResponse>;
    multiRequest(request: KalturaMultiRequest): Promise<KalturaMultiResponse>;
}
