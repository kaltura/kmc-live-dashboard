import { KalturaRequest } from "../kaltura-request";
import { KalturaMultiRequest } from "../kaltura-multi-request";
import { CancelableAction } from '../utils/cancelable-action';
export interface KalturaClientBaseConfiguration {
    clientTag: string;
}
export declare abstract class KalturaClientBase {
    ks: string;
    partnerId: number;
    clientTag: string;
    constructor(config: KalturaClientBaseConfiguration);
    protected abstract _transmitFileUploadRequest(request: any): CancelableAction;
    protected abstract _transmitRequest(request: any): CancelableAction;
    protected _multiRequest(arg: KalturaMultiRequest | KalturaRequest<any>[]): CancelableAction;
    protected _request<T>(request: KalturaRequest<T>): CancelableAction;
    private transmit(request);
    protected _assignDefaultParameters(parameters: any): any;
}
