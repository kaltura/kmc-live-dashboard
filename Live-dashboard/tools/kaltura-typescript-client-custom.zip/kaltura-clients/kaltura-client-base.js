"use strict";
var kaltura_request_1 = require("../kaltura-request");
var kaltura_multi_request_1 = require("../kaltura-multi-request");
var kaltura_api_exception_1 = require("../kaltura-api-exception");
var kaltura_upload_request_1 = require("../kaltura-upload-request");
var KalturaClientBase = (function () {
    function KalturaClientBase(config) {
        this.clientTag = config.clientTag;
    }
    KalturaClientBase.prototype._multiRequest = function (arg) {
        var request = arg instanceof kaltura_multi_request_1.KalturaMultiRequest ? arg : (arg instanceof Array ? new (kaltura_multi_request_1.KalturaMultiRequest.bind.apply(kaltura_multi_request_1.KalturaMultiRequest, [void 0].concat(arg)))() : null);
        if (!request) {
            throw new Error("Missing or invalid argument");
        }
        var transmitAction = this.transmit(request);
        transmitAction.then(function (result) {
            return request.handleResponse(result);
        }, function (error) {
            throw error;
        });
        return transmitAction;
    };
    KalturaClientBase.prototype._request = function (request) {
        var transmitAction = this.transmit(request);
        transmitAction.then(function (result) {
            var response = request.handleResponse(result);
            if (response.error) {
                throw response.error;
            }
            else {
                return response.result;
            }
        }, function (error) {
            var kalturaAPIException;
            if (error instanceof kaltura_api_exception_1.KalturaAPIException) {
                kalturaAPIException = error;
            }
            else if (error instanceof Error && error.message) {
                kalturaAPIException = new kaltura_api_exception_1.KalturaAPIException("client::unknown-error", error.message);
            }
            else {
                var errorMessage = typeof error === 'string' ? error : 'Error connecting to server';
                kalturaAPIException = new kaltura_api_exception_1.KalturaAPIException("client::unknown-error", errorMessage);
            }
            throw kalturaAPIException;
        });
        return transmitAction;
    };
    KalturaClientBase.prototype.transmit = function (request) {
        if (request instanceof kaltura_upload_request_1.KalturaUploadRequest) {
            return this._transmitFileUploadRequest(request);
        }
        else if (request instanceof kaltura_request_1.KalturaRequest || request instanceof kaltura_multi_request_1.KalturaMultiRequest) {
            return this._transmitRequest(request);
        }
        else {
            throw new kaltura_api_exception_1.KalturaAPIException("client::request_type_error", 'unsupported request type requested');
        }
    };
    KalturaClientBase.prototype._assignDefaultParameters = function (parameters) {
        if (parameters) {
            if (this.ks && typeof parameters['ks'] === 'undefined') {
                parameters.ks = this.ks;
            }
            if (this.partnerId && typeof parameters['partnerId'] === 'undefined') {
                parameters.partnerId = this.partnerId;
            }
        }
        if (this.clientTag) {
            parameters.clientTag = this.clientTag;
        }
        return parameters;
    };
    return KalturaClientBase;
}());
exports.KalturaClientBase = KalturaClientBase;

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImthbHR1cmEtY2xpZW50cy9rYWx0dXJhLWNsaWVudC1iYXNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxzREFBb0Q7QUFDcEQsa0VBQStEO0FBRS9ELGtFQUErRDtBQUMvRCxvRUFBaUU7QUFRakU7SUFNSSwyQkFBWSxNQUF3QztRQUVoRCxJQUFJLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUM7SUFDdEMsQ0FBQztJQUtTLHlDQUFhLEdBQXZCLFVBQXdCLEdBQWdEO1FBRXBFLElBQUksT0FBTyxHQUFHLEdBQUcsWUFBWSwyQ0FBbUIsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLFlBQVksS0FBSyxRQUFPLDJDQUFtQixZQUFuQiwyQ0FBbUIsa0JBQUksR0FBRyxRQUFJLElBQUksQ0FBQyxDQUFDO1FBRXpILEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQ2IsQ0FBQztZQUNHLE1BQU0sSUFBSSxLQUFLLENBQUMsNkJBQTZCLENBQUMsQ0FBQztRQUNuRCxDQUFDO1FBRUQsSUFBSSxjQUFjLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUU1QyxjQUFjLENBQUMsSUFBSSxDQUNmLFVBQUEsTUFBTTtZQUNGLE1BQU0sQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzFDLENBQUMsRUFDRCxVQUFDLEtBQUs7WUFDRixNQUFNLEtBQUssQ0FBQztRQUNoQixDQUFDLENBQ0osQ0FBQztRQUVGLE1BQU0sQ0FBQyxjQUFjLENBQUM7SUFDMUIsQ0FBQztJQUVTLG9DQUFRLEdBQWxCLFVBQXNCLE9BQTBCO1FBQzVDLElBQUksY0FBYyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFNUMsY0FBYyxDQUFDLElBQUksQ0FDZixVQUFDLE1BQU07WUFFSCxJQUFNLFFBQVEsR0FBUSxPQUFPLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRXJELEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO2dCQUNqQixNQUFNLFFBQVEsQ0FBQyxLQUFLLENBQUM7WUFDekIsQ0FBQztZQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNKLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO1lBQzNCLENBQUM7UUFDTCxDQUFDLEVBQ0QsVUFBQyxLQUFLO1lBQ0YsSUFBSSxtQkFBbUIsQ0FBQztZQUN4QixFQUFFLENBQUMsQ0FBQyxLQUFLLFlBQVksMkNBQW1CLENBQUMsQ0FBQyxDQUFDO2dCQUN2QyxtQkFBbUIsR0FBRyxLQUFLLENBQUM7WUFDaEMsQ0FBQztZQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLFlBQVksS0FBSyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO2dCQUVqRCxtQkFBbUIsR0FBRyxJQUFJLDJDQUFtQixDQUFDLHVCQUF1QixFQUFFLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUMxRixDQUFDO1lBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ0osSUFBTSxZQUFZLEdBQUcsT0FBTyxLQUFLLEtBQUssUUFBUSxHQUFHLEtBQUssR0FBRyw0QkFBNEIsQ0FBQztnQkFDdEYsbUJBQW1CLEdBQUcsSUFBSSwyQ0FBbUIsQ0FBQyx1QkFBdUIsRUFBRSxZQUFZLENBQUMsQ0FBQztZQUN6RixDQUFDO1lBRUQsTUFBTSxtQkFBbUIsQ0FBQztRQUM5QixDQUFDLENBQ0osQ0FBQztRQUVGLE1BQU0sQ0FBQyxjQUFjLENBQUM7SUFDMUIsQ0FBQztJQUdPLG9DQUFRLEdBQWhCLFVBQWlCLE9BQTJCO1FBQ3hDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sWUFBWSw2Q0FBb0IsQ0FBQyxDQUFDLENBQUM7WUFDMUMsTUFBTSxDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNwRCxDQUFDO1FBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sWUFBWSxnQ0FBYyxJQUFJLE9BQU8sWUFBWSwyQ0FBbUIsQ0FBQyxDQUFDLENBQUM7WUFDckYsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMxQyxDQUFDO1FBQUMsSUFBSSxDQUFDLENBQUM7WUFDSixNQUFNLElBQUksMkNBQW1CLENBQUMsNEJBQTRCLEVBQUUsb0NBQW9DLENBQUMsQ0FBQztRQUN0RyxDQUFDO0lBQ0wsQ0FBQztJQUVTLG9EQUF3QixHQUFsQyxVQUFtQyxVQUFnQjtRQUUvQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO1lBQ2IsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxPQUFPLFVBQVUsQ0FBQyxJQUFJLENBQUMsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDO2dCQUNyRCxVQUFVLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUM7WUFDNUIsQ0FBQztZQUVELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksT0FBTyxVQUFVLENBQUMsV0FBVyxDQUFDLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQztnQkFDbkUsVUFBVSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1lBQzFDLENBQUM7UUFDTCxDQUFDO1FBRUQsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7WUFDakIsVUFBVSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQzFDLENBQUM7UUFFRCxNQUFNLENBQUMsVUFBVSxDQUFDO0lBQ3RCLENBQUM7SUFDTCx3QkFBQztBQUFELENBbkdBLEFBbUdDLElBQUE7QUFuR3FCLDhDQUFpQiIsImZpbGUiOiJrYWx0dXJhLWNsaWVudHMva2FsdHVyYS1jbGllbnQtYmFzZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEthbHR1cmFSZXF1ZXN0IH0gZnJvbSBcIi4uL2thbHR1cmEtcmVxdWVzdFwiO1xuaW1wb3J0IHsgS2FsdHVyYU11bHRpUmVxdWVzdCB9IGZyb20gXCIuLi9rYWx0dXJhLW11bHRpLXJlcXVlc3RcIjtcbmltcG9ydCB7IEthbHR1cmFSZXF1ZXN0QmFzZSB9IGZyb20gXCIuLi9rYWx0dXJhLXJlcXVlc3QtYmFzZVwiO1xuaW1wb3J0IHsgS2FsdHVyYUFQSUV4Y2VwdGlvbiB9IGZyb20gJy4uL2thbHR1cmEtYXBpLWV4Y2VwdGlvbic7XG5pbXBvcnQgeyBLYWx0dXJhVXBsb2FkUmVxdWVzdCB9IGZyb20gJy4uL2thbHR1cmEtdXBsb2FkLXJlcXVlc3QnO1xuaW1wb3J0IHsgQ2FuY2VsYWJsZUFjdGlvbiB9IGZyb20gJy4uL3V0aWxzL2NhbmNlbGFibGUtYWN0aW9uJztcblxuZXhwb3J0IGludGVyZmFjZSBLYWx0dXJhQ2xpZW50QmFzZUNvbmZpZ3VyYXRpb25cbntcbiAgICBjbGllbnRUYWcgOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBLYWx0dXJhQ2xpZW50QmFzZSB7XG5cbiAgICBrcyA6IHN0cmluZztcbiAgICBwYXJ0bmVySWQgOiBudW1iZXI7XG4gICAgcHVibGljIGNsaWVudFRhZyA6IHN0cmluZztcblxuICAgIGNvbnN0cnVjdG9yKGNvbmZpZyA6ICBLYWx0dXJhQ2xpZW50QmFzZUNvbmZpZ3VyYXRpb24pXG4gICAge1xuICAgICAgICB0aGlzLmNsaWVudFRhZyA9IGNvbmZpZy5jbGllbnRUYWc7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIGFic3RyYWN0IF90cmFuc21pdEZpbGVVcGxvYWRSZXF1ZXN0KHJlcXVlc3QpOiBDYW5jZWxhYmxlQWN0aW9uO1xuICAgIHByb3RlY3RlZCBhYnN0cmFjdCBfdHJhbnNtaXRSZXF1ZXN0KHJlcXVlc3QpOiBDYW5jZWxhYmxlQWN0aW9uO1xuXG4gICAgcHJvdGVjdGVkIF9tdWx0aVJlcXVlc3QoYXJnOiBLYWx0dXJhTXVsdGlSZXF1ZXN0IHwgS2FsdHVyYVJlcXVlc3Q8YW55PltdKTogQ2FuY2VsYWJsZUFjdGlvbiB7XG5cbiAgICAgICAgbGV0IHJlcXVlc3QgPSBhcmcgaW5zdGFuY2VvZiBLYWx0dXJhTXVsdGlSZXF1ZXN0ID8gYXJnIDogKGFyZyBpbnN0YW5jZW9mIEFycmF5ID8gbmV3IEthbHR1cmFNdWx0aVJlcXVlc3QoLi4uYXJnKSA6IG51bGwpO1xuXG4gICAgICAgIGlmICghcmVxdWVzdClcbiAgICAgICAge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBNaXNzaW5nIG9yIGludmFsaWQgYXJndW1lbnRgKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCB0cmFuc21pdEFjdGlvbiA9IHRoaXMudHJhbnNtaXQocmVxdWVzdCk7XG5cbiAgICAgICAgdHJhbnNtaXRBY3Rpb24udGhlbihcbiAgICAgICAgICAgIHJlc3VsdCA9PiB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlcXVlc3QuaGFuZGxlUmVzcG9uc2UocmVzdWx0KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAoZXJyb3IpID0+IHtcbiAgICAgICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgKTtcblxuICAgICAgICByZXR1cm4gdHJhbnNtaXRBY3Rpb247XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIF9yZXF1ZXN0PFQ+KHJlcXVlc3Q6IEthbHR1cmFSZXF1ZXN0PFQ+KTogQ2FuY2VsYWJsZUFjdGlvbiB7XG4gICAgICAgIGxldCB0cmFuc21pdEFjdGlvbiA9IHRoaXMudHJhbnNtaXQocmVxdWVzdCk7XG5cbiAgICAgICAgdHJhbnNtaXRBY3Rpb24udGhlbihcbiAgICAgICAgICAgIChyZXN1bHQpID0+XG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzcG9uc2U6IGFueSA9IHJlcXVlc3QuaGFuZGxlUmVzcG9uc2UocmVzdWx0KTtcblxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5lcnJvcikge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyByZXNwb25zZS5lcnJvcjtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UucmVzdWx0O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAoZXJyb3IpID0+IHtcbiAgICAgICAgICAgICAgICBsZXQga2FsdHVyYUFQSUV4Y2VwdGlvbjtcbiAgICAgICAgICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBLYWx0dXJhQVBJRXhjZXB0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIGthbHR1cmFBUElFeGNlcHRpb24gPSBlcnJvcjtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IgJiYgZXJyb3IubWVzc2FnZSkge1xuXG4gICAgICAgICAgICAgICAgICAgIGthbHR1cmFBUElFeGNlcHRpb24gPSBuZXcgS2FsdHVyYUFQSUV4Y2VwdGlvbihcImNsaWVudDo6dW5rbm93bi1lcnJvclwiLCBlcnJvci5tZXNzYWdlKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSB0eXBlb2YgZXJyb3IgPT09ICdzdHJpbmcnID8gZXJyb3IgOiAnRXJyb3IgY29ubmVjdGluZyB0byBzZXJ2ZXInO1xuICAgICAgICAgICAgICAgICAgICBrYWx0dXJhQVBJRXhjZXB0aW9uID0gbmV3IEthbHR1cmFBUElFeGNlcHRpb24oXCJjbGllbnQ6OnVua25vd24tZXJyb3JcIiwgZXJyb3JNZXNzYWdlKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB0aHJvdyBrYWx0dXJhQVBJRXhjZXB0aW9uO1xuICAgICAgICAgICAgfVxuICAgICAgICApO1xuXG4gICAgICAgIHJldHVybiB0cmFuc21pdEFjdGlvbjtcbiAgICB9XG5cblxuICAgIHByaXZhdGUgdHJhbnNtaXQocmVxdWVzdDogS2FsdHVyYVJlcXVlc3RCYXNlKTogQ2FuY2VsYWJsZUFjdGlvbiB7XG4gICAgICAgIGlmIChyZXF1ZXN0IGluc3RhbmNlb2YgS2FsdHVyYVVwbG9hZFJlcXVlc3QpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl90cmFuc21pdEZpbGVVcGxvYWRSZXF1ZXN0KHJlcXVlc3QpO1xuICAgICAgICB9IGVsc2UgaWYgKHJlcXVlc3QgaW5zdGFuY2VvZiBLYWx0dXJhUmVxdWVzdCB8fCByZXF1ZXN0IGluc3RhbmNlb2YgS2FsdHVyYU11bHRpUmVxdWVzdCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3RyYW5zbWl0UmVxdWVzdChyZXF1ZXN0KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBLYWx0dXJhQVBJRXhjZXB0aW9uKFwiY2xpZW50OjpyZXF1ZXN0X3R5cGVfZXJyb3JcIiwgJ3Vuc3VwcG9ydGVkIHJlcXVlc3QgdHlwZSByZXF1ZXN0ZWQnKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByb3RlY3RlZCBfYXNzaWduRGVmYXVsdFBhcmFtZXRlcnMocGFyYW1ldGVycyA6IGFueSkgOiBhbnlcbiAgICB7XG4gICAgICAgIGlmIChwYXJhbWV0ZXJzKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5rcyAmJiB0eXBlb2YgcGFyYW1ldGVyc1sna3MnXSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICBwYXJhbWV0ZXJzLmtzID0gdGhpcy5rcztcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHRoaXMucGFydG5lcklkICYmIHR5cGVvZiBwYXJhbWV0ZXJzWydwYXJ0bmVySWQnXSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICBwYXJhbWV0ZXJzLnBhcnRuZXJJZCA9IHRoaXMucGFydG5lcklkO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMuY2xpZW50VGFnKSB7XG4gICAgICAgICAgICBwYXJhbWV0ZXJzLmNsaWVudFRhZyA9IHRoaXMuY2xpZW50VGFnO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHBhcmFtZXRlcnM7XG4gICAgfVxufVxuIl19
