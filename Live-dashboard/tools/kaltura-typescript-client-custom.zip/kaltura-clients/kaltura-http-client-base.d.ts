import { CancelableAction } from '../utils/cancelable-action';
import { KalturaClientBase, KalturaClientBaseConfiguration } from './kaltura-client-base';
export interface KalturaHttpClientBaseConfiguration extends KalturaClientBaseConfiguration {
    endpointUrl: string;
}
export declare abstract class KalturaHttpClientBase extends KalturaClientBase {
    endpointUrl: string;
    constructor(config: KalturaHttpClientBaseConfiguration);
    private _getHeaders();
    protected _transmitFileUploadRequest(request: any): CancelableAction;
    protected abstract _createCancelableAction(data: {
        endpoint: string;
        headers: any;
        body: {};
    }): CancelableAction;
    protected _transmitRequest(request: any): CancelableAction;
    private _buildQuerystring(data, prefix?);
}
