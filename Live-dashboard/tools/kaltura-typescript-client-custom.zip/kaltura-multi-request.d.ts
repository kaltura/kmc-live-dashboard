import { KalturaRequest } from "./kaltura-request";
import { KalturaRequestBase } from "./kaltura-request-base";
import { KalturaMultiResponse } from "./kaltura-multi-response";
import { KalturaObjectMetadata } from './kaltura-object-base';
export declare class KalturaMultiRequest extends KalturaRequestBase {
    protected callback: (response: KalturaMultiResponse) => void;
    requests: KalturaRequest<any>[];
    constructor(...args: KalturaRequest<any>[]);
    toRequestObject(): any;
    protected _getMetadata(): KalturaObjectMetadata;
    setCompletion(callback: (response: KalturaMultiResponse) => void): KalturaMultiRequest;
    handleResponse(responses: any[]): KalturaMultiResponse;
}
