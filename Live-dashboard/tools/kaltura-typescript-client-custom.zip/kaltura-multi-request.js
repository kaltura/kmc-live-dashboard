"use strict";
var tslib_1 = require("tslib");
var kaltura_request_base_1 = require("./kaltura-request-base");
var kaltura_multi_response_1 = require("./kaltura-multi-response");
var kaltura_api_exception_1 = require("./kaltura-api-exception");
var KalturaMultiRequest = (function (_super) {
    tslib_1.__extends(KalturaMultiRequest, _super);
    function KalturaMultiRequest() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        var _this = _super.call(this, {}) || this;
        _this.requests = [];
        _this.requests = args;
        return _this;
    }
    KalturaMultiRequest.prototype.toRequestObject = function () {
        var result = _super.prototype.toRequestObject.call(this);
        for (var i = 0, length_1 = this.requests.length; i < length_1; i++) {
            result[i] = this.requests[i].toRequestObject();
        }
        return result;
    };
    KalturaMultiRequest.prototype._getMetadata = function () {
        var result = _super.prototype._getMetadata.call(this);
        Object.assign(result.properties, {
            service: { default: 'multirequest', type: 'c' },
            action: { default: 'null', type: 'c' }
        });
        return result;
    };
    KalturaMultiRequest.prototype.setCompletion = function (callback) {
        this.callback = callback;
        return this;
    };
    KalturaMultiRequest.prototype.handleResponse = function (responses) {
        var kalturaResponses = [];
        if (!responses || !(responses instanceof Array) || responses.length != this.requests.length) {
            var response = new kaltura_api_exception_1.KalturaAPIException('client::response_type_error', "server response is invalid, expected array of " + this.requests.length);
            for (var i = 0, len = this.requests.length; i < len; i++) {
                kalturaResponses.push(this.requests[i].handleResponse(response));
            }
        }
        else {
            for (var i = 0, len = this.requests.length; i < len; i++) {
                var serverResponse = responses[i];
                kalturaResponses.push(this.requests[i].handleResponse(serverResponse));
            }
            if (this.callback) {
                try {
                    this.callback(new kaltura_multi_response_1.KalturaMultiResponse(kalturaResponses));
                }
                catch (ex) {
                }
            }
        }
        return new kaltura_multi_response_1.KalturaMultiResponse(kalturaResponses);
    };
    return KalturaMultiRequest;
}(kaltura_request_base_1.KalturaRequestBase));
exports.KalturaMultiRequest = KalturaMultiRequest;

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImthbHR1cmEtbXVsdGktcmVxdWVzdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUVBLCtEQUE0RDtBQUU1RCxtRUFBZ0U7QUFDaEUsaUVBQThEO0FBSTlEO0lBQXlDLCtDQUFrQjtJQU12RDtRQUFZLGNBQThCO2FBQTlCLFVBQThCLEVBQTlCLHFCQUE4QixFQUE5QixJQUE4QjtZQUE5Qix5QkFBOEI7O1FBQTFDLFlBQ0ksa0JBQU0sRUFBRSxDQUFDLFNBRVo7UUFMRCxjQUFRLEdBQTBCLEVBQUUsQ0FBQztRQUlqQyxLQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQzs7SUFDekIsQ0FBQztJQUVELDZDQUFlLEdBQWY7UUFDSSxJQUFNLE1BQU0sR0FBRyxpQkFBTSxlQUFlLFdBQUUsQ0FBQztRQUV2QyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsUUFBTSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxRQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUM3RCxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUNuRCxDQUFDO1FBRUQsTUFBTSxDQUFDLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBRVMsMENBQVksR0FBdEI7UUFFSSxJQUFNLE1BQU0sR0FBRyxpQkFBTSxZQUFZLFdBQUUsQ0FBQztRQUNwQyxNQUFNLENBQUMsTUFBTSxDQUNULE1BQU0sQ0FBQyxVQUFVLEVBQ2pCO1lBQ0ksT0FBTyxFQUFHLEVBQUUsT0FBTyxFQUFHLGNBQWMsRUFBRSxJQUFJLEVBQUcsR0FBRyxFQUFHO1lBQ25ELE1BQU0sRUFBRyxFQUFFLE9BQU8sRUFBRyxNQUFNLEVBQUUsSUFBSSxFQUFHLEdBQUcsRUFBRztTQUM3QyxDQUFDLENBQUM7UUFFUCxNQUFNLENBQUMsTUFBTSxDQUFDO0lBRWxCLENBQUM7SUFFRCwyQ0FBYSxHQUFiLFVBQWMsUUFBa0Q7UUFDNUQsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7UUFDekIsTUFBTSxDQUFDLElBQUksQ0FBQztJQUNoQixDQUFDO0lBRUQsNENBQWMsR0FBZCxVQUFlLFNBQWdCO1FBQzNCLElBQU0sZ0JBQWdCLEdBQTJCLEVBQUUsQ0FBQztRQUVwRCxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsSUFBSSxDQUFDLENBQUMsU0FBUyxZQUFZLEtBQUssQ0FBQyxJQUFJLFNBQVMsQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQzFGLElBQU0sUUFBUSxHQUFHLElBQUksMkNBQW1CLENBQUMsNkJBQTZCLEVBQUUsbURBQWlELElBQUksQ0FBQyxRQUFRLENBQUMsTUFBUSxDQUFDLENBQUM7WUFDakosR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7Z0JBQ3ZELGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBQ3JFLENBQUM7UUFDTCxDQUFDO1FBQ0QsSUFBSSxDQUFDLENBQUM7WUFFRixHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsR0FBRyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztnQkFDdkQsSUFBTSxjQUFjLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztZQUMzRSxDQUFDO1lBRUQsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLElBQUksQ0FBQztvQkFDRCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksNkNBQW9CLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO2dCQUM5RCxDQUFDO2dCQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBRWQsQ0FBQztZQUNMLENBQUM7UUFDTCxDQUFDO1FBRUQsTUFBTSxDQUFDLElBQUksNkNBQW9CLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBQ0wsMEJBQUM7QUFBRCxDQW5FQSxBQW1FQyxDQW5Fd0MseUNBQWtCLEdBbUUxRDtBQW5FWSxrREFBbUIiLCJmaWxlIjoia2FsdHVyYS1tdWx0aS1yZXF1ZXN0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgS2FsdHVyYVJlc3BvbnNlIH0gZnJvbSBcIi4va2FsdHVyYS1yZXNwb25zZVwiO1xuaW1wb3J0IHsgS2FsdHVyYVJlcXVlc3QgfSBmcm9tIFwiLi9rYWx0dXJhLXJlcXVlc3RcIjtcbmltcG9ydCB7IEthbHR1cmFSZXF1ZXN0QmFzZSB9IGZyb20gXCIuL2thbHR1cmEtcmVxdWVzdC1iYXNlXCI7XG5cbmltcG9ydCB7IEthbHR1cmFNdWx0aVJlc3BvbnNlIH0gZnJvbSBcIi4va2FsdHVyYS1tdWx0aS1yZXNwb25zZVwiO1xuaW1wb3J0IHsgS2FsdHVyYUFQSUV4Y2VwdGlvbiB9IGZyb20gXCIuL2thbHR1cmEtYXBpLWV4Y2VwdGlvblwiO1xuaW1wb3J0IHsgS2FsdHVyYU9iamVjdE1ldGFkYXRhIH0gZnJvbSAnLi9rYWx0dXJhLW9iamVjdC1iYXNlJztcblxuXG5leHBvcnQgY2xhc3MgS2FsdHVyYU11bHRpUmVxdWVzdCBleHRlbmRzIEthbHR1cmFSZXF1ZXN0QmFzZSB7XG5cbiAgICBwcm90ZWN0ZWQgY2FsbGJhY2s6IChyZXNwb25zZTogS2FsdHVyYU11bHRpUmVzcG9uc2UpID0+IHZvaWQ7XG5cbiAgICByZXF1ZXN0czogS2FsdHVyYVJlcXVlc3Q8YW55PltdID0gW107XG5cbiAgICBjb25zdHJ1Y3RvciguLi5hcmdzOiBLYWx0dXJhUmVxdWVzdDxhbnk+W10pIHtcbiAgICAgICAgc3VwZXIoe30pO1xuICAgICAgICB0aGlzLnJlcXVlc3RzID0gYXJncztcbiAgICB9XG5cbiAgICB0b1JlcXVlc3RPYmplY3QoKTogYW55IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gc3VwZXIudG9SZXF1ZXN0T2JqZWN0KCk7XG5cbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIGxlbmd0aCA9IHRoaXMucmVxdWVzdHMubGVuZ3RoOyBpIDwgbGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHJlc3VsdFtpXSA9IHRoaXMucmVxdWVzdHNbaV0udG9SZXF1ZXN0T2JqZWN0KCk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBfZ2V0TWV0YWRhdGEoKSA6IEthbHR1cmFPYmplY3RNZXRhZGF0YVxuICAgIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gc3VwZXIuX2dldE1ldGFkYXRhKCk7XG4gICAgICAgIE9iamVjdC5hc3NpZ24oXG4gICAgICAgICAgICByZXN1bHQucHJvcGVydGllcyxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBzZXJ2aWNlIDogeyBkZWZhdWx0IDogJ211bHRpcmVxdWVzdCcsIHR5cGUgOiAnYycgIH0sXG4gICAgICAgICAgICAgICAgYWN0aW9uIDogeyBkZWZhdWx0IDogJ251bGwnLCB0eXBlIDogJ2MnICB9XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuXG4gICAgfVxuXG4gICAgc2V0Q29tcGxldGlvbihjYWxsYmFjazogKHJlc3BvbnNlOiBLYWx0dXJhTXVsdGlSZXNwb25zZSkgPT4gdm9pZCk6IEthbHR1cmFNdWx0aVJlcXVlc3Qge1xuICAgICAgICB0aGlzLmNhbGxiYWNrID0gY2FsbGJhY2s7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGhhbmRsZVJlc3BvbnNlKHJlc3BvbnNlczogYW55W10pOiBLYWx0dXJhTXVsdGlSZXNwb25zZSB7XG4gICAgICAgIGNvbnN0IGthbHR1cmFSZXNwb25zZXM6IEthbHR1cmFSZXNwb25zZTxhbnk+W10gPSBbXTtcblxuICAgICAgICBpZiAoIXJlc3BvbnNlcyB8fCAhKHJlc3BvbnNlcyBpbnN0YW5jZW9mIEFycmF5KSB8fCByZXNwb25zZXMubGVuZ3RoICE9IHRoaXMucmVxdWVzdHMubGVuZ3RoKSB7XG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IG5ldyBLYWx0dXJhQVBJRXhjZXB0aW9uKCdjbGllbnQ6OnJlc3BvbnNlX3R5cGVfZXJyb3InLCBgc2VydmVyIHJlc3BvbnNlIGlzIGludmFsaWQsIGV4cGVjdGVkIGFycmF5IG9mICR7dGhpcy5yZXF1ZXN0cy5sZW5ndGh9YCk7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbGVuID0gdGhpcy5yZXF1ZXN0cy5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgICAgICAgICAgIGthbHR1cmFSZXNwb25zZXMucHVzaCh0aGlzLnJlcXVlc3RzW2ldLmhhbmRsZVJlc3BvbnNlKHJlc3BvbnNlKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG5cbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBsZW4gPSB0aGlzLnJlcXVlc3RzLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgc2VydmVyUmVzcG9uc2UgPSByZXNwb25zZXNbaV07XG4gICAgICAgICAgICAgICAga2FsdHVyYVJlc3BvbnNlcy5wdXNoKHRoaXMucmVxdWVzdHNbaV0uaGFuZGxlUmVzcG9uc2Uoc2VydmVyUmVzcG9uc2UpKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHRoaXMuY2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNhbGxiYWNrKG5ldyBLYWx0dXJhTXVsdGlSZXNwb25zZShrYWx0dXJhUmVzcG9uc2VzKSk7XG4gICAgICAgICAgICAgICAgfSBjYXRjaCAoZXgpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gZG8gbm90aGluZyBieSBkZXNpZ25cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gbmV3IEthbHR1cmFNdWx0aVJlc3BvbnNlKGthbHR1cmFSZXNwb25zZXMpO1xuICAgIH1cbn1cbiJdfQ==
