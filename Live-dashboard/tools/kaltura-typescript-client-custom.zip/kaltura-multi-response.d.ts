import { KalturaResponse } from "./kaltura-response";
export declare class KalturaMultiResponse extends Array<KalturaResponse<any>> {
    constructor(results?: KalturaResponse<any>[]);
    hasErrors(): boolean;
}
