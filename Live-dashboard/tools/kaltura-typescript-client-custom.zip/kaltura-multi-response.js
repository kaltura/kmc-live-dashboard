"use strict";
var tslib_1 = require("tslib");
var KalturaMultiResponse = (function (_super) {
    tslib_1.__extends(KalturaMultiResponse, _super);
    function KalturaMultiResponse(results) {
        var _newTarget = this.constructor;
        if (results === void 0) { results = []; }
        var _this = _super.call(this) || this;
        if (_newTarget) {
            // Set the prototype explicitly - see: https://github.com/Microsoft/TypeScript/wiki/FAQ#why-doesnt-extending-built-ins-like-error-array-and-map-work
            Object.setPrototypeOf(_this, _newTarget.prototype);
        }
        if (results && results.length > 0) {
            _this.push.apply(_this, results);
        }
        return _this;
    }
    KalturaMultiResponse.prototype.hasErrors = function () {
        return this.filter(function (result) { return result.error; }).length > 0;
    };
    return KalturaMultiResponse;
}(Array));
exports.KalturaMultiResponse = KalturaMultiResponse;

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImthbHR1cmEtbXVsdGktcmVzcG9uc2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFFQTtJQUEwQyxnREFBMkI7SUFDakUsOEJBQVksT0FBb0M7O1FBQXBDLHdCQUFBLEVBQUEsWUFBb0M7UUFBaEQsWUFDSSxpQkFBTyxTQVVWO1FBUkcsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDO1lBQ2Isb0pBQW9KO1lBQ3BKLE1BQU0sQ0FBQyxjQUFjLENBQUMsS0FBSSxFQUFFLFdBQVcsU0FBUyxDQUFDLENBQUM7UUFDdEQsQ0FBQztRQUVELEVBQUUsQ0FBQyxDQUFDLE9BQU8sSUFBSSxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDaEMsS0FBSSxDQUFDLElBQUksT0FBVCxLQUFJLEVBQVMsT0FBTyxFQUFFO1FBQzFCLENBQUM7O0lBQ0wsQ0FBQztJQUVNLHdDQUFTLEdBQWhCO1FBQ0ksTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBQSxNQUFNLElBQUksT0FBQSxNQUFNLENBQUMsS0FBSyxFQUFaLENBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7SUFDMUQsQ0FBQztJQUdMLDJCQUFDO0FBQUQsQ0FuQkEsQUFtQkMsQ0FuQnlDLEtBQUssR0FtQjlDO0FBbkJZLG9EQUFvQiIsImZpbGUiOiJrYWx0dXJhLW11bHRpLXJlc3BvbnNlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgS2FsdHVyYVJlc3BvbnNlIH0gZnJvbSBcIi4va2FsdHVyYS1yZXNwb25zZVwiO1xuXG5leHBvcnQgY2xhc3MgS2FsdHVyYU11bHRpUmVzcG9uc2UgZXh0ZW5kcyBBcnJheTxLYWx0dXJhUmVzcG9uc2U8YW55Pj4ge1xuICAgIGNvbnN0cnVjdG9yKHJlc3VsdHM6IEthbHR1cmFSZXNwb25zZTxhbnk+W10gPSBbXSkge1xuICAgICAgICBzdXBlcigpO1xuXG4gICAgICAgIGlmIChuZXcudGFyZ2V0KSB7XG4gICAgICAgICAgICAvLyBTZXQgdGhlIHByb3RvdHlwZSBleHBsaWNpdGx5IC0gc2VlOiBodHRwczovL2dpdGh1Yi5jb20vTWljcm9zb2Z0L1R5cGVTY3JpcHQvd2lraS9GQVEjd2h5LWRvZXNudC1leHRlbmRpbmctYnVpbHQtaW5zLWxpa2UtZXJyb3ItYXJyYXktYW5kLW1hcC13b3JrXG4gICAgICAgICAgICBPYmplY3Quc2V0UHJvdG90eXBlT2YodGhpcywgbmV3LnRhcmdldC5wcm90b3R5cGUpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHJlc3VsdHMgJiYgcmVzdWx0cy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICB0aGlzLnB1c2goLi4ucmVzdWx0cyk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwdWJsaWMgaGFzRXJyb3JzKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5maWx0ZXIocmVzdWx0ID0+IHJlc3VsdC5lcnJvcikubGVuZ3RoID4gMDtcbiAgICB9XG5cblxufVxuIl19
