"use strict";
var kaltura_utils_1 = require("./utils/kaltura-utils");
var kaltura_types_factory_1 = require("./kaltura-types-factory");
;
var KalturaObjectBase = (function () {
    function KalturaObjectBase(data) {
        this._dependentProperties = {};
        if (data) {
            Object.assign(this, data);
        }
    }
    KalturaObjectBase.prototype.setData = function (handler) {
        if (handler) {
            handler(this);
        }
        return this;
    };
    KalturaObjectBase.prototype.getTypeName = function () {
        return this._getMetadata().properties['objectType'].default;
    };
    KalturaObjectBase.prototype._getMetadata = function () {
        return { properties: {} };
    };
    KalturaObjectBase.prototype.toRequestObject = function () {
        var _this = this;
        var metadata = this._getMetadata();
        var result = {};
        try {
            Object.keys(metadata.properties).forEach(function (propertyName) {
                var propertyData = metadata.properties[propertyName];
                var propertyValue = _this._createRequestPropertyValue(propertyName, propertyData);
                switch (propertyValue.status) {
                    case "exists":
                        result[propertyName] = propertyValue.value;
                        break;
                    case "removed":
                        result[propertyName + "__null"] = ''; // mark property for deletion
                        break;
                    case "missing":
                    default:
                        break;
                }
            });
        }
        catch (err) {
            // TODO [kaltura] should use logHandler
            console.warn(err.message);
            throw err;
        }
        return result;
    };
    KalturaObjectBase.prototype.fromResponseObject = function (data) {
        var _this = this;
        var metadata = this._getMetadata();
        var result = {};
        try {
            Object.keys(metadata.properties).forEach(function (propertyName) {
                var propertyData = metadata.properties[propertyName];
                var propertyValue = _this._parseResponseProperty(propertyName, propertyData, data);
                if (propertyValue != null && typeof propertyValue !== 'undefined') {
                    _this[propertyName] = propertyValue;
                }
            });
        }
        catch (err) {
            // TODO [kaltura] should use logHandler
            console.warn(err.message);
            throw err;
        }
        return result;
    };
    KalturaObjectBase.prototype._parseResponseProperty = function (propertyName, property, source) {
        var _this = this;
        var result;
        var sourceValue = propertyName ? source[propertyName] : source;
        if (typeof sourceValue !== 'undefined') {
            if (sourceValue === null) {
                result = null;
            }
            else {
                switch (property.type) {
                    case 'b':
                        if (typeof sourceValue === 'boolean') {
                            result = sourceValue;
                        }
                        else if (sourceValue + '' === '0') {
                            result = false;
                        }
                        else if (sourceValue + '' === '1') {
                            result = true;
                        }
                        break;
                    case 's':
                        result = sourceValue + '';
                        break;
                    case 'n': // number
                    case 'en':
                        result = sourceValue * 1;
                        break;
                    case 'o':
                        var propertyObjectType = sourceValue['objectType'];
                        if (propertyObjectType) {
                            result = this._createKalturaObject(propertyObjectType, property.subType);
                            if (result) {
                                result.fromResponseObject(sourceValue);
                            }
                            else {
                                throw new Error("Failed to create kaltura object of type '" + source['objectType'] + "' (fallback type '" + property.subType + "')");
                            }
                        }
                        else {
                            throw new Error("Failed to create kaltura object for property '" + propertyName + "' (type '" + property.subType + "'). provided response object is missing property 'objectType'.");
                        }
                        break;
                    case 'm':
                        var parsedMap_1 = {};
                        if (sourceValue instanceof Object) {
                            Object.keys(sourceValue).forEach(function (itemKey) {
                                var itemValue = sourceValue[itemKey];
                                var newItem = _this._createKalturaObject(property.subType);
                                if (itemValue && newItem) {
                                    newItem.fromResponseObject(itemValue);
                                    parsedMap_1[itemKey] = newItem;
                                }
                                else {
                                    throw new Error("Failed to create kaltura object for type '" + property.subType + "'");
                                }
                            });
                        }
                        else {
                            throw new Error("failed to parse property '" + propertyName + ". Expected type object, got type '" + typeof sourceValue);
                        }
                        break;
                    case 'a':
                        if (sourceValue instanceof Array) {
                            var parsedArray_1 = [];
                            sourceValue.forEach(function (responseItem) {
                                var newItem = _this._createKalturaObject(responseItem['objectType'], property.subType);
                                if (newItem) {
                                    newItem.fromResponseObject(responseItem);
                                    parsedArray_1.push(newItem);
                                }
                                else {
                                    throw new Error("Failed to create kaltura object for type '" + responseItem['objectType'] + "' and for fallback type '" + property.subType + "'");
                                }
                            });
                            if (parsedArray_1.length) {
                                result = parsedArray_1;
                            }
                        }
                        else {
                            throw new Error("failed to parse property '" + propertyName + ". Expected type array, got type '" + typeof sourceValue);
                        }
                        break;
                    case 'd':
                        if (this._isNumeric(sourceValue)) {
                            result = kaltura_utils_1.KalturaUtils.fromServerDate(sourceValue * 1);
                        }
                        else {
                            throw new Error("failed to parse property '" + propertyName + ". Expected type date, got type '" + typeof sourceValue);
                        }
                        break;
                    case "es":
                        result = this._createKalturaObject(property.subType);
                        if (result && typeof result !== 'undefined') {
                            result['_value'] = sourceValue + '';
                        }
                        else {
                            throw new Error("Failed to create kaltura enum for type '" + property.subType + "'");
                        }
                        break;
                    default:
                        break;
                }
            }
        }
        return result;
    };
    KalturaObjectBase.prototype._isNumeric = function (n) {
        return !isNaN(parseFloat(n)) && isFinite(n);
    };
    KalturaObjectBase.prototype._createKalturaObject = function (objectType, fallbackObjectType) {
        var result = null;
        var usedFallbackType = false;
        if (objectType) {
            result = kaltura_types_factory_1.KalturaTypesFactory.createObject(objectType);
        }
        if (!result && fallbackObjectType) {
            usedFallbackType = true;
            result = kaltura_types_factory_1.KalturaTypesFactory.createObject(fallbackObjectType);
        }
        if (usedFallbackType && result) {
            console.warn("[kaltura-typescript-client]: Could not find object type '" + objectType + "', Falling back to '" + fallbackObjectType + "' object type. (Did you remember to set your accepted object types in the request \u201CacceptedTypes\u201D attribute?)");
        }
        else if (!result) {
            console.warn("[kaltura-typescript-client]: Could not find object type '" + objectType + "'. (Did you remember to set your accepted object types in the request \u201CacceptedTypes\u201D attribute?)");
        }
        return result;
    };
    KalturaObjectBase.prototype._createRequestPropertyValue = function (propertyName, property) {
        var result = { status: 'missing' };
        if (property.type === 'c') {
            // constant string
            if (property.default) {
                result = { status: 'exists', value: property.default };
            }
        }
        else if (this._dependentProperties[propertyName]) {
            var dependentProperty = this._dependentProperties[propertyName];
            var resultValue = "{" + dependentProperty.request + ":result" + (dependentProperty.targetPath ? ':' + dependentProperty.targetPath : '') + "}";
            result = { status: 'exists', value: resultValue };
        }
        else if (!property.readOnly) {
            var value = this[propertyName];
            if (typeof value !== 'undefined') {
                if (value === null) {
                    result = { status: 'removed' };
                }
                else {
                    switch (property.type) {
                        case 'b':
                            result = { status: 'exists', value: value };
                            break;
                        case 's':
                            result = { status: 'exists', value: value + '' };
                            break;
                        case 'n': // number
                        case 'en':
                            result = { status: 'exists', value: value * 1 };
                            break;
                        case 'o':
                            if (value instanceof KalturaObjectBase) {
                                result = { status: 'exists', value: value.toRequestObject() };
                            }
                            else {
                                throw new Error("failed to parse property. Expected '" + propertyName + " to be kaltura object");
                            }
                            break;
                        case 'a':
                            if (value instanceof Array) {
                                var parsedArray_2 = [];
                                value.forEach(function (item) {
                                    if (item instanceof KalturaObjectBase) {
                                        parsedArray_2.push(item.toRequestObject());
                                    }
                                });
                                if (parsedArray_2.length !== 0) {
                                    if (parsedArray_2.length === value.length) {
                                        result = { status: 'exists', value: parsedArray_2 };
                                    }
                                    else {
                                        throw new Error("failed to parse array. Expected all '" + propertyName + " items to be kaltura object");
                                    }
                                }
                            }
                            else {
                                throw new Error("failed to parse property. Expected '" + propertyName + " to be kaltura object");
                            }
                            break;
                        case 'd':
                            if (value instanceof Date) {
                                result = { status: 'exists', value: kaltura_utils_1.KalturaUtils.toServerDate(value) };
                            }
                            else {
                                throw new Error("failed to parse property. Expected '" + propertyName + " to be date");
                            }
                            break;
                        case 'es':
                            if (typeof value._value !== 'undefined') {
                                result = { status: 'exists', value: value._value };
                            }
                            else {
                                throw new Error("failed to parse property. Expected '" + propertyName + " to be of type string enum");
                            }
                            break;
                        case 'f':
                            if (value instanceof FormData) {
                                result = { status: 'exists', value: value };
                            }
                            break;
                        default:
                            // do nothing
                            break;
                    }
                }
            }
        }
        return result;
    };
    KalturaObjectBase.prototype.setDependency = function () {
        var dependency = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            dependency[_i] = arguments[_i];
        }
        for (var i = 0, len = dependency.length; i < len; i++) {
            var item = dependency[i];
            var _a = item, property = _a.property, request = _a.request, targetPath = _a.targetPath;
            if (item instanceof Array) {
                property = item[0];
                // The server expect one based index (meaning the first item has index 1)
                // since Javascript array are zero based index we expose the api as zero based
                // and transform the index value in the actual request by adding 1
                request = item[1] + 1;
                targetPath = item.length == 3 ? item[2] : null;
            }
            this._dependentProperties[property] = { property: property, request: request, targetPath: targetPath };
        }
        return this;
    };
    return KalturaObjectBase;
}());
exports.KalturaObjectBase = KalturaObjectBase;

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImthbHR1cmEtb2JqZWN0LWJhc2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLHVEQUFxRDtBQUNyRCxpRUFBOEQ7QUFnQjdELENBQUM7QUFPRjtJQVdJLDJCQUFZLElBQVU7UUFUZCx5QkFBb0IsR0FBMkMsRUFBRSxDQUFDO1FBV3RFLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUNULENBQUM7WUFDRyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztRQUM5QixDQUFDO0lBQ0wsQ0FBQztJQWJELG1DQUFPLEdBQVAsVUFBUSxPQUFtQztRQUN2QyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1lBQ1YsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2xCLENBQUM7UUFDRCxNQUFNLENBQUMsSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFVTSx1Q0FBVyxHQUFsQjtRQUVJLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDLE9BQU8sQ0FBQztJQUNoRSxDQUFDO0lBRVMsd0NBQVksR0FBdEI7UUFFSSxNQUFNLENBQUMsRUFBRSxVQUFVLEVBQUcsRUFBRSxFQUFDLENBQUM7SUFDOUIsQ0FBQztJQUdELDJDQUFlLEdBQWY7UUFBQSxpQkE4QkM7UUE3QkcsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3JDLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQztRQUVoQixJQUFJLENBQUM7WUFDRCxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBQSxZQUFZO2dCQUNqRCxJQUFNLFlBQVksR0FBSSxRQUFRLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUN4RCxJQUFNLGFBQWEsR0FBRyxLQUFJLENBQUMsMkJBQTJCLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQyxDQUFDO2dCQUVuRixNQUFNLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQzdCLENBQUM7b0JBQ0csS0FBSyxRQUFRO3dCQUNULE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxhQUFhLENBQUMsS0FBSyxDQUFDO3dCQUMzQyxLQUFLLENBQUM7b0JBQ1YsS0FBSyxTQUFTO3dCQUNWLE1BQU0sQ0FBSSxZQUFZLFdBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLDZCQUE2Qjt3QkFDbkUsS0FBSyxDQUFDO29CQUNWLEtBQUssU0FBUyxDQUFDO29CQUNmO3dCQUNJLEtBQUssQ0FBQztnQkFDZCxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDO1FBQUEsS0FBSyxDQUFBLENBQUMsR0FBRyxDQUFDLENBQ1gsQ0FBQztZQUNHLHVDQUF1QztZQUN2QyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUMxQixNQUFNLEdBQUcsQ0FBQztRQUNkLENBQUM7UUFFRCxNQUFNLENBQUMsTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFRCw4Q0FBa0IsR0FBbEIsVUFBbUIsSUFBVTtRQUE3QixpQkFzQkM7UUFyQkcsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3JDLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQztRQUVoQixJQUFJLENBQUM7WUFDRCxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBQSxZQUFZO2dCQUNqRCxJQUFNLFlBQVksR0FBRyxRQUFRLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUN2RCxJQUFNLGFBQWEsR0FBRyxLQUFJLENBQUMsc0JBQXNCLENBQUMsWUFBWSxFQUFFLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFFcEYsRUFBRSxDQUFDLENBQUMsYUFBYSxJQUFJLElBQUksSUFBSSxPQUFPLGFBQWEsS0FBSyxXQUFXLENBQUMsQ0FDbEUsQ0FBQztvQkFDRyxLQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsYUFBYSxDQUFDO2dCQUN2QyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDO1FBQUEsS0FBSyxDQUFBLENBQUMsR0FBRyxDQUFDLENBQ1gsQ0FBQztZQUNHLHVDQUF1QztZQUN2QyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUMxQixNQUFNLEdBQUcsQ0FBQztRQUNkLENBQUM7UUFFRCxNQUFNLENBQUMsTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFUyxrREFBc0IsR0FBaEMsVUFBaUMsWUFBcUIsRUFBRSxRQUF3QyxFQUFFLE1BQVk7UUFBOUcsaUJBOEdDO1FBNUdHLElBQUksTUFBTSxDQUFDO1FBQ1gsSUFBSSxXQUFXLEdBQUcsWUFBWSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxNQUFNLENBQUM7UUFFL0QsRUFBRSxDQUFDLENBQUMsT0FBTyxXQUFXLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQztZQUNyQyxFQUFFLENBQUMsQ0FBQyxXQUFXLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDdkIsTUFBTSxHQUFHLElBQUksQ0FBQztZQUNsQixDQUFDO1lBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ0osTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7b0JBQ3BCLEtBQUssR0FBRzt3QkFDSixFQUFFLENBQUMsQ0FBQyxPQUFPLFdBQVcsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUNuQyxNQUFNLEdBQUcsV0FBVyxDQUFDO3dCQUN6QixDQUFDO3dCQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxXQUFXLEdBQUcsRUFBRSxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7NEJBQ2xDLE1BQU0sR0FBRyxLQUFLLENBQUM7d0JBQ25CLENBQUM7d0JBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFdBQVcsR0FBRyxFQUFFLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQzs0QkFDbEMsTUFBTSxHQUFHLElBQUksQ0FBQzt3QkFDbEIsQ0FBQzt3QkFDRCxLQUFLLENBQUM7b0JBQ1YsS0FBSyxHQUFHO3dCQUNKLE1BQU0sR0FBRyxXQUFXLEdBQUcsRUFBRSxDQUFDO3dCQUMxQixLQUFLLENBQUM7b0JBQ1YsS0FBSyxHQUFHLENBQUMsQ0FBQyxTQUFTO29CQUNuQixLQUFLLElBQUk7d0JBQ0wsTUFBTSxHQUFHLFdBQVcsR0FBRyxDQUFDLENBQUM7d0JBQ3pCLEtBQUssQ0FBQztvQkFDVixLQUFLLEdBQUc7d0JBQ0osSUFBTSxrQkFBa0IsR0FBRyxXQUFXLENBQUMsWUFBWSxDQUFDLENBQUM7d0JBRXJELEVBQUUsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQ3ZCLENBQUM7NEJBQ0csTUFBTSxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxrQkFBa0IsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7NEJBRXpFLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0NBQ1QsTUFBTSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUMzQyxDQUFDOzRCQUFDLElBQUksQ0FBQyxDQUFDO2dDQUNKLE1BQU0sSUFBSSxLQUFLLENBQUMsOENBQTRDLE1BQU0sQ0FBQyxZQUFZLENBQUMsMEJBQXFCLFFBQVEsQ0FBQyxPQUFPLE9BQUksQ0FBQyxDQUFDOzRCQUMvSCxDQUFDO3dCQUNMLENBQUM7d0JBQUEsSUFBSSxDQUNMLENBQUM7NEJBQ0csTUFBTSxJQUFJLEtBQUssQ0FBQyxtREFBaUQsWUFBWSxpQkFBWSxRQUFRLENBQUMsT0FBTyxtRUFBZ0UsQ0FBQyxDQUFDO3dCQUMvSyxDQUFDO3dCQUVELEtBQUssQ0FBQztvQkFDVixLQUFLLEdBQUc7d0JBQ0osSUFBTSxXQUFTLEdBQUcsRUFBRSxDQUFDO3dCQUNyQixFQUFFLENBQUMsQ0FBQyxXQUFXLFlBQVksTUFBTSxDQUFDLENBQUMsQ0FBQzs0QkFDaEMsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBQSxPQUFPO2dDQUVwQyxJQUFNLFNBQVMsR0FBRyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7Z0NBQ3hDLElBQU0sT0FBTyxHQUFJLEtBQUksQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7Z0NBRTVELEVBQUUsQ0FBQyxDQUFDLFNBQVMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDO29DQUN2QixPQUFPLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLENBQUM7b0NBQ3RDLFdBQVMsQ0FBQyxPQUFPLENBQUMsR0FBRyxPQUFPLENBQUM7Z0NBQ2pDLENBQUM7Z0NBQUMsSUFBSSxDQUFDLENBQUM7b0NBQ0osTUFBTSxJQUFJLEtBQUssQ0FBQywrQ0FBNkMsUUFBUSxDQUFDLE9BQU8sTUFBRyxDQUFDLENBQUM7Z0NBQ3RGLENBQUM7NEJBRUwsQ0FBQyxDQUFDLENBQUM7d0JBQ1AsQ0FBQzt3QkFBQyxJQUFJLENBQUMsQ0FBQzs0QkFDSixNQUFNLElBQUksS0FBSyxDQUFDLCtCQUE2QixZQUFZLDBDQUFxQyxPQUFPLFdBQWEsQ0FBQyxDQUFDO3dCQUN4SCxDQUFDO3dCQUNELEtBQUssQ0FBQztvQkFDVixLQUFLLEdBQUc7d0JBQ0osRUFBRSxDQUFDLENBQUMsV0FBVyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUM7NEJBQy9CLElBQU0sYUFBVyxHQUFHLEVBQUUsQ0FBQzs0QkFDdkIsV0FBVyxDQUFDLE9BQU8sQ0FBQyxVQUFBLFlBQVk7Z0NBQzVCLElBQU0sT0FBTyxHQUFHLEtBQUksQ0FBQyxvQkFBb0IsQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dDQUV4RixFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO29DQUNWLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUMsQ0FBQztvQ0FDekMsYUFBVyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztnQ0FDOUIsQ0FBQztnQ0FBQyxJQUFJLENBQUMsQ0FBQztvQ0FDSixNQUFNLElBQUksS0FBSyxDQUFDLCtDQUE2QyxZQUFZLENBQUMsWUFBWSxDQUFDLGlDQUE0QixRQUFRLENBQUMsT0FBTyxNQUFHLENBQUMsQ0FBQztnQ0FDNUksQ0FBQzs0QkFDTCxDQUFDLENBQUMsQ0FBQzs0QkFFSCxFQUFFLENBQUMsQ0FBQyxhQUFXLENBQUMsTUFBTSxDQUFDLENBQ3ZCLENBQUM7Z0NBQ0csTUFBTSxHQUFHLGFBQVcsQ0FBQzs0QkFDekIsQ0FBQzt3QkFDTCxDQUFDO3dCQUFDLElBQUksQ0FBQyxDQUFDOzRCQUNKLE1BQU0sSUFBSSxLQUFLLENBQUMsK0JBQTZCLFlBQVkseUNBQW9DLE9BQU8sV0FBYSxDQUFDLENBQUM7d0JBQ3ZILENBQUM7d0JBQ0QsS0FBSyxDQUFDO29CQUNWLEtBQUssR0FBRzt3QkFDSixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDL0IsTUFBTSxHQUFHLDRCQUFZLENBQUMsY0FBYyxDQUFDLFdBQVcsR0FBQyxDQUFDLENBQUMsQ0FBQTt3QkFDdkQsQ0FBQzt3QkFBQSxJQUFJLENBQUMsQ0FBQzs0QkFDSCxNQUFNLElBQUksS0FBSyxDQUFDLCtCQUE2QixZQUFZLHdDQUFtQyxPQUFPLFdBQWEsQ0FBQyxDQUFDO3dCQUN0SCxDQUFDO3dCQUNELEtBQUssQ0FBQztvQkFDVixLQUFLLElBQUk7d0JBQ0wsTUFBTSxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7d0JBRXJELEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSSxPQUFPLE1BQU0sS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDOzRCQUMxQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsV0FBVyxHQUFHLEVBQUUsQ0FBQzt3QkFDeEMsQ0FBQzt3QkFBQyxJQUFJLENBQUMsQ0FBQzs0QkFDSixNQUFNLElBQUksS0FBSyxDQUFDLDZDQUEyQyxRQUFRLENBQUMsT0FBTyxNQUFHLENBQUMsQ0FBQzt3QkFDcEYsQ0FBQzt3QkFDRCxLQUFLLENBQUM7b0JBQ1Y7d0JBQ0ksS0FBSyxDQUFDO2dCQUNkLENBQUM7WUFFTCxDQUFDO1FBQ0wsQ0FBQztRQUVELE1BQU0sQ0FBQyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVPLHNDQUFVLEdBQWxCLFVBQW1CLENBQU87UUFDdEIsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRU8sZ0RBQW9CLEdBQTVCLFVBQTZCLFVBQW1CLEVBQUUsa0JBQTRCO1FBRTFFLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQztRQUNsQixJQUFJLGdCQUFnQixHQUFHLEtBQUssQ0FBQztRQUM3QixFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FDZixDQUFDO1lBQ0csTUFBTSxHQUFHLDJDQUFtQixDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUMxRCxDQUFDO1FBRUQsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLElBQUksa0JBQWtCLENBQUMsQ0FDbEMsQ0FBQztZQUNHLGdCQUFnQixHQUFHLElBQUksQ0FBQztZQUN4QixNQUFNLEdBQUcsMkNBQW1CLENBQUMsWUFBWSxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFDbEUsQ0FBQztRQUVELEVBQUUsQ0FBQyxDQUFDLGdCQUFnQixJQUFJLE1BQU0sQ0FBQyxDQUMvQixDQUFDO1lBQ08sT0FBTyxDQUFDLElBQUksQ0FBQyw4REFBNEQsVUFBVSw0QkFBdUIsa0JBQWtCLDRIQUErRyxDQUFDLENBQUE7UUFDcFAsQ0FBQztRQUFBLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUNsQixDQUFDO1lBQ0csT0FBTyxDQUFDLElBQUksQ0FBQyw4REFBNEQsVUFBVSxnSEFBbUcsQ0FBQyxDQUFBO1FBQzNMLENBQUM7UUFFRCxNQUFNLENBQUMsTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFTyx1REFBMkIsR0FBbkMsVUFBb0MsWUFBcUIsRUFBRSxRQUF3QztRQUUvRixJQUFJLE1BQU0sR0FBaUUsRUFBRSxNQUFNLEVBQUcsU0FBUyxFQUFDLENBQUM7UUFFakcsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksS0FBSyxHQUFHLENBQUMsQ0FDMUIsQ0FBQztZQUNHLGtCQUFrQjtZQUNsQixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQ3JCLENBQUM7Z0JBQ0csTUFBTSxHQUFHLEVBQUUsTUFBTSxFQUFHLFFBQVEsRUFBRSxLQUFLLEVBQUcsUUFBUSxDQUFDLE9BQU8sRUFBQyxDQUFDO1lBQzVELENBQUM7UUFDTCxDQUFDO1FBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUNuRCxDQUFDO1lBQ0csSUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDbEUsSUFBTSxXQUFXLEdBQUcsTUFBSSxpQkFBaUIsQ0FBQyxPQUFPLGdCQUFVLGlCQUFpQixDQUFDLFVBQVUsR0FBRyxHQUFHLEdBQUcsaUJBQWlCLENBQUMsVUFBVSxHQUFHLEVBQUUsT0FBRyxDQUFDO1lBQ3JJLE1BQU0sR0FBRyxFQUFFLE1BQU0sRUFBRyxRQUFRLEVBQUUsS0FBSyxFQUFHLFdBQVcsRUFBQyxDQUFDO1FBQ3ZELENBQUM7UUFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUMxQixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFL0IsRUFBRSxDQUFDLENBQUMsT0FBTyxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQztnQkFDL0IsRUFBRSxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7b0JBQ2pCLE1BQU0sR0FBRyxFQUFFLE1BQU0sRUFBRyxTQUFTLEVBQUMsQ0FBQztnQkFDbkMsQ0FBQztnQkFBQyxJQUFJLENBQUMsQ0FBQztvQkFDSixNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDcEIsS0FBSyxHQUFHOzRCQUNKLE1BQU0sR0FBRyxFQUFFLE1BQU0sRUFBRyxRQUFRLEVBQUUsS0FBSyxFQUFHLEtBQUssRUFBQyxDQUFDOzRCQUM3QyxLQUFLLENBQUM7d0JBQ1YsS0FBSyxHQUFHOzRCQUNKLE1BQU0sR0FBRyxFQUFFLE1BQU0sRUFBRyxRQUFRLEVBQUUsS0FBSyxFQUFHLEtBQUssR0FBRyxFQUFFLEVBQUMsQ0FBQzs0QkFDbEQsS0FBSyxDQUFDO3dCQUNWLEtBQUssR0FBRyxDQUFDLENBQUMsU0FBUzt3QkFDbkIsS0FBSyxJQUFJOzRCQUNMLE1BQU0sR0FBRyxFQUFFLE1BQU0sRUFBRyxRQUFRLEVBQUUsS0FBSyxFQUFHLEtBQUssR0FBRyxDQUFDLEVBQUMsQ0FBQzs0QkFDakQsS0FBSyxDQUFDO3dCQUNWLEtBQUssR0FBRzs0QkFDSixFQUFFLENBQUMsQ0FBQyxLQUFLLFlBQVksaUJBQWlCLENBQUMsQ0FBQyxDQUFDO2dDQUNyQyxNQUFNLEdBQUcsRUFBRSxNQUFNLEVBQUcsUUFBUSxFQUFFLEtBQUssRUFBRyxLQUFLLENBQUMsZUFBZSxFQUFFLEVBQUMsQ0FBQzs0QkFDbkUsQ0FBQzs0QkFBQSxJQUFJLENBQ0wsQ0FBQztnQ0FDRyxNQUFNLElBQUksS0FBSyxDQUFDLHlDQUF1QyxZQUFZLDBCQUF1QixDQUFDLENBQUM7NEJBQ2hHLENBQUM7NEJBQ0QsS0FBSyxDQUFDO3dCQUNWLEtBQUssR0FBRzs0QkFDSixFQUFFLENBQUMsQ0FBQyxLQUFLLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQztnQ0FDekIsSUFBTSxhQUFXLEdBQUcsRUFBRSxDQUFDO2dDQUN2QixLQUFLLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTtvQ0FFZCxFQUFFLENBQUMsQ0FBQyxJQUFJLFlBQVksaUJBQWlCLENBQUMsQ0FDdEMsQ0FBQzt3Q0FDRyxhQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO29DQUM3QyxDQUFDO2dDQUNMLENBQUMsQ0FBQyxDQUFDO2dDQUVILEVBQUUsQ0FBQyxDQUFDLGFBQVcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDM0IsRUFBRSxDQUFDLENBQUMsYUFBVyxDQUFDLE1BQU0sS0FBSyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQzt3Q0FDdEMsTUFBTSxHQUFHLEVBQUMsTUFBTSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsYUFBVyxFQUFDLENBQUM7b0NBQ3BELENBQUM7b0NBQUMsSUFBSSxDQUFDLENBQUM7d0NBQ0osTUFBTSxJQUFJLEtBQUssQ0FBQywwQ0FBd0MsWUFBWSxnQ0FBNkIsQ0FBQyxDQUFDO29DQUN2RyxDQUFDO2dDQUNMLENBQUM7NEJBQ0wsQ0FBQzs0QkFBQSxJQUFJLENBQ0wsQ0FBQztnQ0FDRyxNQUFNLElBQUksS0FBSyxDQUFDLHlDQUF1QyxZQUFZLDBCQUF1QixDQUFDLENBQUM7NEJBQ2hHLENBQUM7NEJBQ0QsS0FBSyxDQUFDO3dCQUNWLEtBQUssR0FBRzs0QkFDSixFQUFFLENBQUMsQ0FBQyxLQUFLLFlBQVksSUFBSSxDQUFDLENBQUMsQ0FBQztnQ0FDeEIsTUFBTSxHQUFHLEVBQUUsTUFBTSxFQUFHLFFBQVEsRUFBRSxLQUFLLEVBQUcsNEJBQVksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLEVBQUMsQ0FBQzs0QkFDNUUsQ0FBQzs0QkFBQSxJQUFJLENBQUMsQ0FBQztnQ0FDSCxNQUFNLElBQUksS0FBSyxDQUFDLHlDQUF1QyxZQUFZLGdCQUFhLENBQUMsQ0FBQzs0QkFDdEYsQ0FBQzs0QkFDRCxLQUFLLENBQUM7d0JBQ1YsS0FBSyxJQUFJOzRCQUNMLEVBQUUsQ0FBQyxDQUFDLE9BQU8sS0FBSyxDQUFDLE1BQU0sS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDO2dDQUN0QyxNQUFNLEdBQUcsRUFBRSxNQUFNLEVBQUcsUUFBUSxFQUFFLEtBQUssRUFBRyxLQUFLLENBQUMsTUFBTSxFQUFDLENBQUM7NEJBQ3hELENBQUM7NEJBQUEsSUFBSSxDQUNMLENBQUM7Z0NBQ0csTUFBTSxJQUFJLEtBQUssQ0FBQyx5Q0FBdUMsWUFBWSwrQkFBNEIsQ0FBQyxDQUFDOzRCQUNyRyxDQUFDOzRCQUNELEtBQUssQ0FBQzt3QkFDVixLQUFLLEdBQUc7NEJBQ0osRUFBRSxDQUFDLENBQUMsS0FBSyxZQUFZLFFBQVEsQ0FBQyxDQUM5QixDQUFDO2dDQUNHLE1BQU0sR0FBRyxFQUFDLE1BQU0sRUFBRyxRQUFRLEVBQUUsS0FBSyxFQUFHLEtBQUssRUFBQyxDQUFDOzRCQUNoRCxDQUFDOzRCQUNELEtBQUssQ0FBQzt3QkFDVjs0QkFDSSxhQUFhOzRCQUNiLEtBQUssQ0FBQztvQkFDZCxDQUFDO2dCQUNMLENBQUM7WUFDTCxDQUFDO1FBQ0wsQ0FBQztRQUVELE1BQU0sQ0FBQyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVELHlDQUFhLEdBQWI7UUFBYyxvQkFBa0Y7YUFBbEYsVUFBa0YsRUFBbEYscUJBQWtGLEVBQWxGLElBQWtGO1lBQWxGLCtCQUFrRjs7UUFFNUYsR0FBRyxDQUFBLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFDLENBQUMsR0FBQyxHQUFHLEVBQUMsQ0FBQyxFQUFFLEVBQ2hELENBQUM7WUFDRyxJQUFNLElBQUksR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdkIsSUFBQSxTQUE2QyxFQUEzQyxzQkFBUSxFQUFFLG9CQUFPLEVBQUUsMEJBQVUsQ0FBZTtZQUNsRCxFQUFFLENBQUMsQ0FBQyxJQUFJLFlBQVksS0FBSyxDQUFDLENBQzFCLENBQUM7Z0JBQ0csUUFBUSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFbkIseUVBQXlFO2dCQUN6RSw4RUFBOEU7Z0JBQzlFLGtFQUFrRTtnQkFDbEUsT0FBTyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUM7Z0JBQ3BCLFVBQVUsR0FBRyxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDO1lBQ25ELENBQUM7WUFFRCxJQUFJLENBQUMsb0JBQW9CLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxRQUFRLFVBQUEsRUFBRyxPQUFPLFNBQUEsRUFBRSxVQUFVLFlBQUEsRUFBRSxDQUFDO1FBQzdFLENBQUM7UUFFRCxNQUFNLENBQUMsSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFDTCx3QkFBQztBQUFELENBNVZBLEFBNFZDLElBQUE7QUE1VnFCLDhDQUFpQiIsImZpbGUiOiJrYWx0dXJhLW9iamVjdC1iYXNlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgS2FsdHVyYVV0aWxzIH0gZnJvbSBcIi4vdXRpbHMva2FsdHVyYS11dGlsc1wiO1xuaW1wb3J0IHsgS2FsdHVyYVR5cGVzRmFjdG9yeSB9IGZyb20gJy4va2FsdHVyYS10eXBlcy1mYWN0b3J5JztcblxuZXhwb3J0IHR5cGUgRGVwZW5kZW50UHJvcGVydHkgPSB7IHByb3BlcnR5IDogc3RyaW5nLCByZXF1ZXN0IDogbnVtYmVyLCB0YXJnZXRQYXRoPyA6IHN0cmluZ1tdIH07XG5cbmV4cG9ydCBpbnRlcmZhY2UgS2FsdHVyYU9iamVjdE1ldGFkYXRhXG57XG4gICAgcHJvcGVydGllcyA6IHsgW2tleSA6IHN0cmluZ10gOiBLYWx0dXJhT2JqZWN0UHJvcGVydHlNZXRhZGF0YX07XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgS2FsdHVyYU9iamVjdFByb3BlcnR5TWV0YWRhdGFcbntcbiAgICByZWFkT25seT8gOiBib29sZWFuO1xuICAgIHR5cGUgOiBzdHJpbmc7XG4gICAgc3ViVHlwZT8gOiBzdHJpbmc7XG4gICAgZGVmYXVsdD8gOiBzdHJpbmc7XG4gICAgc3ViVHlwZUNvbnN0cnVjdG9yPyA6IHsgbmV3KCkgOiBLYWx0dXJhT2JqZWN0QmFzZSB9O1xufTtcblxuZXhwb3J0IGludGVyZmFjZSBLYWx0dXJhT2JqZWN0QmFzZUFyZ3NcbntcblxufVxuXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgS2FsdHVyYU9iamVjdEJhc2V7XG5cbiAgICBwcml2YXRlIF9kZXBlbmRlbnRQcm9wZXJ0aWVzIDogeyBba2V5IDogc3RyaW5nXSA6IERlcGVuZGVudFByb3BlcnR5fSA9IHt9O1xuXG4gICAgc2V0RGF0YShoYW5kbGVyIDogKHJlcXVlc3QgOiAgdGhpcykgPT4gdm9pZCkgOiAgdGhpcyB7XG4gICAgICAgIGlmIChoYW5kbGVyKSB7XG4gICAgICAgICAgICBoYW5kbGVyKHRoaXMpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGNvbnN0cnVjdG9yKGRhdGE/IDoge30pXG4gICAge1xuICAgICAgICBpZiAoZGF0YSlcbiAgICAgICAge1xuICAgICAgICAgICAgT2JqZWN0LmFzc2lnbih0aGlzLCBkYXRhKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHB1YmxpYyBnZXRUeXBlTmFtZSgpIDogc3RyaW5nXG4gICAge1xuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0TWV0YWRhdGEoKS5wcm9wZXJ0aWVzWydvYmplY3RUeXBlJ10uZGVmYXVsdDtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgX2dldE1ldGFkYXRhKCkgOiBLYWx0dXJhT2JqZWN0TWV0YWRhdGFcbiAgICB7XG4gICAgICAgIHJldHVybiB7IHByb3BlcnRpZXMgOiB7fX07XG4gICAgfVxuXG5cbiAgICB0b1JlcXVlc3RPYmplY3QoKSA6IHt9IHtcbiAgICAgICAgY29uc3QgbWV0YWRhdGEgPSB0aGlzLl9nZXRNZXRhZGF0YSgpO1xuICAgICAgICBsZXQgcmVzdWx0ID0ge307XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIE9iamVjdC5rZXlzKG1ldGFkYXRhLnByb3BlcnRpZXMpLmZvckVhY2gocHJvcGVydHlOYW1lID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBwcm9wZXJ0eURhdGEgID0gbWV0YWRhdGEucHJvcGVydGllc1twcm9wZXJ0eU5hbWVdO1xuICAgICAgICAgICAgICAgIGNvbnN0IHByb3BlcnR5VmFsdWUgPSB0aGlzLl9jcmVhdGVSZXF1ZXN0UHJvcGVydHlWYWx1ZShwcm9wZXJ0eU5hbWUsIHByb3BlcnR5RGF0YSk7XG5cbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHByb3BlcnR5VmFsdWUuc3RhdHVzKVxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBcImV4aXN0c1wiOlxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0W3Byb3BlcnR5TmFtZV0gPSBwcm9wZXJ0eVZhbHVlLnZhbHVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgXCJyZW1vdmVkXCI6XG4gICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbYCR7cHJvcGVydHlOYW1lfV9fbnVsbGBdID0gJyc7IC8vIG1hcmsgcHJvcGVydHkgZm9yIGRlbGV0aW9uXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBcIm1pc3NpbmdcIjpcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9Y2F0Y2goZXJyKVxuICAgICAgICB7XG4gICAgICAgICAgICAvLyBUT0RPIFtrYWx0dXJhXSBzaG91bGQgdXNlIGxvZ0hhbmRsZXJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihlcnIubWVzc2FnZSk7XG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cblxuICAgIGZyb21SZXNwb25zZU9iamVjdChkYXRhIDogYW55KSA6IHt9IHtcbiAgICAgICAgY29uc3QgbWV0YWRhdGEgPSB0aGlzLl9nZXRNZXRhZGF0YSgpO1xuICAgICAgICBsZXQgcmVzdWx0ID0ge307XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIE9iamVjdC5rZXlzKG1ldGFkYXRhLnByb3BlcnRpZXMpLmZvckVhY2gocHJvcGVydHlOYW1lID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBwcm9wZXJ0eURhdGEgPSBtZXRhZGF0YS5wcm9wZXJ0aWVzW3Byb3BlcnR5TmFtZV07XG4gICAgICAgICAgICAgICAgY29uc3QgcHJvcGVydHlWYWx1ZSA9IHRoaXMuX3BhcnNlUmVzcG9uc2VQcm9wZXJ0eShwcm9wZXJ0eU5hbWUsIHByb3BlcnR5RGF0YSwgZGF0YSk7XG5cbiAgICAgICAgICAgICAgICBpZiAocHJvcGVydHlWYWx1ZSAhPSBudWxsICYmIHR5cGVvZiBwcm9wZXJ0eVZhbHVlICE9PSAndW5kZWZpbmVkJylcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXNbcHJvcGVydHlOYW1lXSA9IHByb3BlcnR5VmFsdWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1jYXRjaChlcnIpXG4gICAgICAgIHtcbiAgICAgICAgICAgIC8vIFRPRE8gW2thbHR1cmFdIHNob3VsZCB1c2UgbG9nSGFuZGxlclxuICAgICAgICAgICAgY29uc29sZS53YXJuKGVyci5tZXNzYWdlKTtcbiAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIF9wYXJzZVJlc3BvbnNlUHJvcGVydHkocHJvcGVydHlOYW1lIDogc3RyaW5nLCBwcm9wZXJ0eSA6IEthbHR1cmFPYmplY3RQcm9wZXJ0eU1ldGFkYXRhLCBzb3VyY2UgOiBhbnkpIDogYW55IHtcblxuICAgICAgICBsZXQgcmVzdWx0O1xuICAgICAgICBsZXQgc291cmNlVmFsdWUgPSBwcm9wZXJ0eU5hbWUgPyBzb3VyY2VbcHJvcGVydHlOYW1lXSA6IHNvdXJjZTtcblxuICAgICAgICBpZiAodHlwZW9mIHNvdXJjZVZhbHVlICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgaWYgKHNvdXJjZVZhbHVlID09PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0ID0gbnVsbDtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgc3dpdGNoIChwcm9wZXJ0eS50eXBlKSB7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgJ2InOiAvLyBib29sZWFuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHNvdXJjZVZhbHVlID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBzb3VyY2VWYWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoc291cmNlVmFsdWUgKyAnJyA9PT0gJzAnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHNvdXJjZVZhbHVlICsgJycgPT09ICcxJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAncyc6IC8vIHN0cmluZ1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gc291cmNlVmFsdWUgKyAnJztcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBjYXNlICduJzogLy8gbnVtYmVyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgJ2VuJzogLy8gZW51bSBvZiB0eXBlIG51bWJlclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gc291cmNlVmFsdWUgKiAxO1xuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgJ28nOiAvLyBvYmplY3RcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHByb3BlcnR5T2JqZWN0VHlwZSA9IHNvdXJjZVZhbHVlWydvYmplY3RUeXBlJ107XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0eU9iamVjdFR5cGUpXG4gICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gdGhpcy5fY3JlYXRlS2FsdHVyYU9iamVjdChwcm9wZXJ0eU9iamVjdFR5cGUsIHByb3BlcnR5LnN1YlR5cGUpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQuZnJvbVJlc3BvbnNlT2JqZWN0KHNvdXJjZVZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBjcmVhdGUga2FsdHVyYSBvYmplY3Qgb2YgdHlwZSAnJHtzb3VyY2VbJ29iamVjdFR5cGUnXX0nIChmYWxsYmFjayB0eXBlICcke3Byb3BlcnR5LnN1YlR5cGV9JylgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9ZWxzZVxuICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIGNyZWF0ZSBrYWx0dXJhIG9iamVjdCBmb3IgcHJvcGVydHkgJyR7cHJvcGVydHlOYW1lfScgKHR5cGUgJyR7cHJvcGVydHkuc3ViVHlwZX0nKS4gcHJvdmlkZWQgcmVzcG9uc2Ugb2JqZWN0IGlzIG1pc3NpbmcgcHJvcGVydHkgJ29iamVjdFR5cGUnLmApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAnbSc6IC8vIG1hcFxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcGFyc2VkTWFwID0ge307XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoc291cmNlVmFsdWUgaW5zdGFuY2VvZiBPYmplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBPYmplY3Qua2V5cyhzb3VyY2VWYWx1ZSkuZm9yRWFjaChpdGVtS2V5ID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpdGVtVmFsdWUgPSBzb3VyY2VWYWx1ZVtpdGVtS2V5XTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdJdGVtID0gIHRoaXMuX2NyZWF0ZUthbHR1cmFPYmplY3QocHJvcGVydHkuc3ViVHlwZSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGl0ZW1WYWx1ZSAmJiBuZXdJdGVtKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuZXdJdGVtLmZyb21SZXNwb25zZU9iamVjdChpdGVtVmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VkTWFwW2l0ZW1LZXldID0gbmV3SXRlbTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIGNyZWF0ZSBrYWx0dXJhIG9iamVjdCBmb3IgdHlwZSAnJHtwcm9wZXJ0eS5zdWJUeXBlfSdgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgZmFpbGVkIHRvIHBhcnNlIHByb3BlcnR5ICcke3Byb3BlcnR5TmFtZX0uIEV4cGVjdGVkIHR5cGUgb2JqZWN0LCBnb3QgdHlwZSAnJHt0eXBlb2Ygc291cmNlVmFsdWV9YCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAnYSc6IC8vIGFycmF5XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoc291cmNlVmFsdWUgaW5zdGFuY2VvZiBBcnJheSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHBhcnNlZEFycmF5ID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc291cmNlVmFsdWUuZm9yRWFjaChyZXNwb25zZUl0ZW0gPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdJdGVtID0gdGhpcy5fY3JlYXRlS2FsdHVyYU9iamVjdChyZXNwb25zZUl0ZW1bJ29iamVjdFR5cGUnXSwgcHJvcGVydHkuc3ViVHlwZSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG5ld0l0ZW0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5ld0l0ZW0uZnJvbVJlc3BvbnNlT2JqZWN0KHJlc3BvbnNlSXRlbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJzZWRBcnJheS5wdXNoKG5ld0l0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gY3JlYXRlIGthbHR1cmEgb2JqZWN0IGZvciB0eXBlICcke3Jlc3BvbnNlSXRlbVsnb2JqZWN0VHlwZSddfScgYW5kIGZvciBmYWxsYmFjayB0eXBlICcke3Byb3BlcnR5LnN1YlR5cGV9J2ApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocGFyc2VkQXJyYXkubGVuZ3RoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gcGFyc2VkQXJyYXk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYGZhaWxlZCB0byBwYXJzZSBwcm9wZXJ0eSAnJHtwcm9wZXJ0eU5hbWV9LiBFeHBlY3RlZCB0eXBlIGFycmF5LCBnb3QgdHlwZSAnJHt0eXBlb2Ygc291cmNlVmFsdWV9YCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAnZCc6IC8vIGRhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc051bWVyaWMoc291cmNlVmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gS2FsdHVyYVV0aWxzLmZyb21TZXJ2ZXJEYXRlKHNvdXJjZVZhbHVlKjEpXG4gICAgICAgICAgICAgICAgICAgICAgICB9ZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBmYWlsZWQgdG8gcGFyc2UgcHJvcGVydHkgJyR7cHJvcGVydHlOYW1lfS4gRXhwZWN0ZWQgdHlwZSBkYXRlLCBnb3QgdHlwZSAnJHt0eXBlb2Ygc291cmNlVmFsdWV9YCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBcImVzXCI6XG4gICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSB0aGlzLl9jcmVhdGVLYWx0dXJhT2JqZWN0KHByb3BlcnR5LnN1YlR5cGUpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0ICYmIHR5cGVvZiByZXN1bHQgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0WydfdmFsdWUnXSA9IHNvdXJjZVZhbHVlICsgJyc7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIGNyZWF0ZSBrYWx0dXJhIGVudW0gZm9yIHR5cGUgJyR7cHJvcGVydHkuc3ViVHlwZX0nYCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG5cbiAgICBwcml2YXRlIF9pc051bWVyaWMobiA6IGFueSkgOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuICFpc05hTihwYXJzZUZsb2F0KG4pKSAmJiBpc0Zpbml0ZShuKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIF9jcmVhdGVLYWx0dXJhT2JqZWN0KG9iamVjdFR5cGUgOiBzdHJpbmcsIGZhbGxiYWNrT2JqZWN0VHlwZT8gOiBzdHJpbmcpIDogS2FsdHVyYU9iamVjdEJhc2VcbiAgICB7XG4gICAgICAgIGxldCByZXN1bHQgPSBudWxsO1xuICAgICAgICBsZXQgdXNlZEZhbGxiYWNrVHlwZSA9IGZhbHNlO1xuICAgICAgICBpZiAob2JqZWN0VHlwZSlcbiAgICAgICAge1xuICAgICAgICAgICAgcmVzdWx0ID0gS2FsdHVyYVR5cGVzRmFjdG9yeS5jcmVhdGVPYmplY3Qob2JqZWN0VHlwZSk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIXJlc3VsdCAmJiBmYWxsYmFja09iamVjdFR5cGUpXG4gICAgICAgIHtcbiAgICAgICAgICAgIHVzZWRGYWxsYmFja1R5cGUgPSB0cnVlO1xuICAgICAgICAgICAgcmVzdWx0ID0gS2FsdHVyYVR5cGVzRmFjdG9yeS5jcmVhdGVPYmplY3QoZmFsbGJhY2tPYmplY3RUeXBlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh1c2VkRmFsbGJhY2tUeXBlICYmIHJlc3VsdClcbiAgICAgICAge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgW2thbHR1cmEtdHlwZXNjcmlwdC1jbGllbnRdOiBDb3VsZCBub3QgZmluZCBvYmplY3QgdHlwZSAnJHtvYmplY3RUeXBlfScsIEZhbGxpbmcgYmFjayB0byAnJHtmYWxsYmFja09iamVjdFR5cGV9JyBvYmplY3QgdHlwZS4gKERpZCB5b3UgcmVtZW1iZXIgdG8gc2V0IHlvdXIgYWNjZXB0ZWQgb2JqZWN0IHR5cGVzIGluIHRoZSByZXF1ZXN0IOKAnGFjY2VwdGVkVHlwZXPigJ0gYXR0cmlidXRlPylgKVxuICAgICAgICB9ZWxzZSBpZiAoIXJlc3VsdClcbiAgICAgICAge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKGBba2FsdHVyYS10eXBlc2NyaXB0LWNsaWVudF06IENvdWxkIG5vdCBmaW5kIG9iamVjdCB0eXBlICcke29iamVjdFR5cGV9Jy4gKERpZCB5b3UgcmVtZW1iZXIgdG8gc2V0IHlvdXIgYWNjZXB0ZWQgb2JqZWN0IHR5cGVzIGluIHRoZSByZXF1ZXN0IOKAnGFjY2VwdGVkVHlwZXPigJ0gYXR0cmlidXRlPylgKVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG5cbiAgICBwcml2YXRlIF9jcmVhdGVSZXF1ZXN0UHJvcGVydHlWYWx1ZShwcm9wZXJ0eU5hbWUgOiBzdHJpbmcsIHByb3BlcnR5IDogS2FsdHVyYU9iamVjdFByb3BlcnR5TWV0YWRhdGEpIDogeyBzdGF0dXMgOiAnbWlzc2luZycgfCAncmVtb3ZlZCcgfCAnZXhpc3RzJywgdmFsdWU/IDogYW55IH0ge1xuXG4gICAgICAgIGxldCByZXN1bHQgOiB7IHN0YXR1cyA6ICdtaXNzaW5nJyB8ICdyZW1vdmVkJyB8ICdleGlzdHMnLCB2YWx1ZT8gOiBhbnkgfSA9IHsgc3RhdHVzIDogJ21pc3NpbmcnfTtcblxuICAgICAgICBpZiAocHJvcGVydHkudHlwZSA9PT0gJ2MnKVxuICAgICAgICB7XG4gICAgICAgICAgICAvLyBjb25zdGFudCBzdHJpbmdcbiAgICAgICAgICAgIGlmIChwcm9wZXJ0eS5kZWZhdWx0KVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHJlc3VsdCA9IHsgc3RhdHVzIDogJ2V4aXN0cycsIHZhbHVlIDogcHJvcGVydHkuZGVmYXVsdH07XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5fZGVwZW5kZW50UHJvcGVydGllc1twcm9wZXJ0eU5hbWVdKVxuICAgICAgICB7XG4gICAgICAgICAgICBjb25zdCBkZXBlbmRlbnRQcm9wZXJ0eSA9IHRoaXMuX2RlcGVuZGVudFByb3BlcnRpZXNbcHJvcGVydHlOYW1lXTtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdFZhbHVlID0gYHske2RlcGVuZGVudFByb3BlcnR5LnJlcXVlc3R9OnJlc3VsdCR7ZGVwZW5kZW50UHJvcGVydHkudGFyZ2V0UGF0aCA/ICc6JyArIGRlcGVuZGVudFByb3BlcnR5LnRhcmdldFBhdGggOiAnJ319YDtcbiAgICAgICAgICAgIHJlc3VsdCA9IHsgc3RhdHVzIDogJ2V4aXN0cycsIHZhbHVlIDogcmVzdWx0VmFsdWV9O1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKCFwcm9wZXJ0eS5yZWFkT25seSkge1xuICAgICAgICAgICAgbGV0IHZhbHVlID0gdGhpc1twcm9wZXJ0eU5hbWVdO1xuXG4gICAgICAgICAgICBpZiAodHlwZW9mIHZhbHVlICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIGlmICh2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSB7IHN0YXR1cyA6ICdyZW1vdmVkJ307XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgc3dpdGNoIChwcm9wZXJ0eS50eXBlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlICdiJzogLy8gYm9vbGVhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IHsgc3RhdHVzIDogJ2V4aXN0cycsIHZhbHVlIDogdmFsdWV9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAncyc6IC8vIHN0cmluZ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IHsgc3RhdHVzIDogJ2V4aXN0cycsIHZhbHVlIDogdmFsdWUgKyAnJ307XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlICduJzogLy8gbnVtYmVyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlICdlbic6IC8vIGVudW0gb2YgdHlwZSBudW1iZXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSB7IHN0YXR1cyA6ICdleGlzdHMnLCB2YWx1ZSA6IHZhbHVlICogMX07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlICdvJzogLy8gb2JqZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlIGluc3RhbmNlb2YgS2FsdHVyYU9iamVjdEJhc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0geyBzdGF0dXMgOiAnZXhpc3RzJywgdmFsdWUgOiB2YWx1ZS50b1JlcXVlc3RPYmplY3QoKX07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgZmFpbGVkIHRvIHBhcnNlIHByb3BlcnR5LiBFeHBlY3RlZCAnJHtwcm9wZXJ0eU5hbWV9IHRvIGJlIGthbHR1cmEgb2JqZWN0YCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAnYSc6IC8vIGFycmF5XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlIGluc3RhbmNlb2YgQXJyYXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcGFyc2VkQXJyYXkgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWUuZm9yRWFjaChpdGVtID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpdGVtIGluc3RhbmNlb2YgS2FsdHVyYU9iamVjdEJhc2UpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VkQXJyYXkucHVzaChpdGVtLnRvUmVxdWVzdE9iamVjdCgpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHBhcnNlZEFycmF5Lmxlbmd0aCAhPT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHBhcnNlZEFycmF5Lmxlbmd0aCA9PT0gdmFsdWUubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0ge3N0YXR1czogJ2V4aXN0cycsIHZhbHVlOiBwYXJzZWRBcnJheX07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgZmFpbGVkIHRvIHBhcnNlIGFycmF5LiBFeHBlY3RlZCBhbGwgJyR7cHJvcGVydHlOYW1lfSBpdGVtcyB0byBiZSBrYWx0dXJhIG9iamVjdGApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgZmFpbGVkIHRvIHBhcnNlIHByb3BlcnR5LiBFeHBlY3RlZCAnJHtwcm9wZXJ0eU5hbWV9IHRvIGJlIGthbHR1cmEgb2JqZWN0YCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAnZCc6IC8vIGRhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsdWUgaW5zdGFuY2VvZiBEYXRlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IHsgc3RhdHVzIDogJ2V4aXN0cycsIHZhbHVlIDogS2FsdHVyYVV0aWxzLnRvU2VydmVyRGF0ZSh2YWx1ZSl9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1lbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBmYWlsZWQgdG8gcGFyc2UgcHJvcGVydHkuIEV4cGVjdGVkICcke3Byb3BlcnR5TmFtZX0gdG8gYmUgZGF0ZWApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgJ2VzJzogLy8gZW51bSBvZiB0eXBlIHN0cmluZ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdmFsdWUuX3ZhbHVlICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSB7IHN0YXR1cyA6ICdleGlzdHMnLCB2YWx1ZSA6IHZhbHVlLl92YWx1ZX07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgZmFpbGVkIHRvIHBhcnNlIHByb3BlcnR5LiBFeHBlY3RlZCAnJHtwcm9wZXJ0eU5hbWV9IHRvIGJlIG9mIHR5cGUgc3RyaW5nIGVudW1gKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlICdmJzpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsdWUgaW5zdGFuY2VvZiBGb3JtRGF0YSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IHtzdGF0dXMgOiAnZXhpc3RzJywgdmFsdWUgOiB2YWx1ZX07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkbyBub3RoaW5nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cblxuICAgIHNldERlcGVuZGVuY3koLi4uZGVwZW5kZW5jeSA6IChEZXBlbmRlbnRQcm9wZXJ0eSB8IFtzdHJpbmcsIG51bWJlcl0gfCBbc3RyaW5nLCBudW1iZXIsc3RyaW5nXSlbXSkgOiB0aGlzXG4gICAge1xuICAgICAgICBmb3IobGV0IGkgPSAwLCBsZW4gPSBkZXBlbmRlbmN5Lmxlbmd0aDtpPGxlbjtpKyspXG4gICAgICAgIHtcbiAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSBkZXBlbmRlbmN5W2ldO1xuICAgICAgICAgICAgbGV0IHsgcHJvcGVydHksIHJlcXVlc3QsIHRhcmdldFBhdGggfSA9IDxhbnk+aXRlbTtcbiAgICAgICAgICAgIGlmIChpdGVtIGluc3RhbmNlb2YgQXJyYXkpXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcHJvcGVydHkgPSBpdGVtWzBdO1xuXG4gICAgICAgICAgICAgICAgLy8gVGhlIHNlcnZlciBleHBlY3Qgb25lIGJhc2VkIGluZGV4IChtZWFuaW5nIHRoZSBmaXJzdCBpdGVtIGhhcyBpbmRleCAxKVxuICAgICAgICAgICAgICAgIC8vIHNpbmNlIEphdmFzY3JpcHQgYXJyYXkgYXJlIHplcm8gYmFzZWQgaW5kZXggd2UgZXhwb3NlIHRoZSBhcGkgYXMgemVybyBiYXNlZFxuICAgICAgICAgICAgICAgIC8vIGFuZCB0cmFuc2Zvcm0gdGhlIGluZGV4IHZhbHVlIGluIHRoZSBhY3R1YWwgcmVxdWVzdCBieSBhZGRpbmcgMVxuICAgICAgICAgICAgICAgIHJlcXVlc3QgPSBpdGVtWzFdKzE7XG4gICAgICAgICAgICAgICAgdGFyZ2V0UGF0aCA9IGl0ZW0ubGVuZ3RoID09IDMgPyBpdGVtWzJdIDogbnVsbDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdGhpcy5fZGVwZW5kZW50UHJvcGVydGllc1twcm9wZXJ0eV0gPSB7IHByb3BlcnR5ICwgcmVxdWVzdCwgdGFyZ2V0UGF0aCB9O1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxufVxuIl19
