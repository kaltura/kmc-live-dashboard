import { KalturaObjectMetadata } from './kaltura-object-base';
import { KalturaBaseResponseProfile } from './types/KalturaBaseResponseProfile';
import { KalturaObjectBase, KalturaObjectBaseArgs } from './kaltura-object-base';
export interface KalturaRequestBaseArgs extends KalturaObjectBaseArgs {
    acceptedTypes?: KalturaObjectBase[];
    partnerId?: number;
    ks?: string;
    responseProfile?: KalturaBaseResponseProfile;
}
export declare class KalturaRequestBase extends KalturaObjectBase {
    acceptedTypes: KalturaObjectBase[];
    partnerId: number;
    ks: string;
    responseProfile: KalturaBaseResponseProfile;
    constructor(data: KalturaRequestBaseArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
