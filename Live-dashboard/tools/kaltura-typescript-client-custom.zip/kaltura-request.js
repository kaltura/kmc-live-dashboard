"use strict";
var tslib_1 = require("tslib");
var kaltura_response_1 = require("./kaltura-response");
var kaltura_request_base_1 = require("./kaltura-request-base");
var kaltura_api_exception_1 = require("./kaltura-api-exception");
var KalturaRequest = (function (_super) {
    tslib_1.__extends(KalturaRequest, _super);
    function KalturaRequest(data, _a) {
        var responseType = _a.responseType, responseSubType = _a.responseSubType, responseConstructor = _a.responseConstructor;
        var _this = _super.call(this, data) || this;
        _this.responseSubType = responseSubType;
        _this.responseType = responseType;
        _this._responseConstructor = responseConstructor;
        return _this;
    }
    KalturaRequest.prototype.setCompletion = function (callback) {
        this.callback = callback;
        return this;
    };
    KalturaRequest.prototype._unwrapResponse = function (response) {
        // if response is object without 'objectType' property and with 'result' property -> it is ott response
        if (response && typeof response === 'object' && !response.objectType && response.result) {
            // if response.result is object without 'objectType' property and with 'error' property -> it is ott error response
            if (typeof response.result === 'object' && !response.result.objectType && response.result.error) {
                return response.result.error;
            }
            else {
                return response.result;
            }
        }
        else {
            return response;
        }
    };
    KalturaRequest.prototype.handleResponse = function (response) {
        var responseResult;
        var responseError;
        try {
            var unwrappedResponse = this._unwrapResponse(response);
            var responseObject = null;
            if (unwrappedResponse) {
                if (unwrappedResponse.objectType === 'KalturaAPIException') {
                    responseObject = _super.prototype._parseResponseProperty.call(this, "", {
                        type: 'o',
                        subType: 'KalturaAPIException'
                    }, unwrappedResponse);
                }
                else {
                    responseObject = _super.prototype._parseResponseProperty.call(this, "", {
                        type: this.responseType,
                        subType: this.responseSubType
                    }, unwrappedResponse);
                }
            }
            if (!responseObject && this.responseType !== 'v') {
                responseError = new kaltura_api_exception_1.KalturaAPIException('client::response_type_error', "server response is undefined, expected '" + this.responseType + " / " + this.responseSubType + "'");
            }
            else if (responseObject instanceof kaltura_api_exception_1.KalturaAPIException) {
                // got exception from library
                responseError = responseObject;
            }
            else {
                responseResult = responseObject;
            }
        }
        catch (ex) {
            // TODO [kmc] should implement
            responseError = new kaltura_api_exception_1.KalturaAPIException('client::general_error', ex.message);
        }
        var result = new kaltura_response_1.KalturaResponse(responseResult, responseError);
        if (this.callback) {
            try {
                this.callback(result);
            }
            catch (ex) {
            }
        }
        return result;
    };
    return KalturaRequest;
}(kaltura_request_base_1.KalturaRequestBase));
exports.KalturaRequest = KalturaRequest;

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImthbHR1cmEtcmVxdWVzdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHVEQUFxRDtBQUNyRCwrREFBb0Y7QUFDcEYsaUVBQThEO0FBUzlEO0lBQWdELDBDQUFrQjtJQU85RCx3QkFBWSxJQUE2QixFQUFFLEVBQStKO1lBQTlKLDhCQUFZLEVBQUUsb0NBQWUsRUFBRSw0Q0FBbUI7UUFBOUYsWUFDSSxrQkFBTSxJQUFJLENBQUMsU0FJZDtRQUhHLEtBQUksQ0FBQyxlQUFlLEdBQUcsZUFBZSxDQUFDO1FBQ3ZDLEtBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO1FBQ2pDLEtBQUksQ0FBQyxvQkFBb0IsR0FBRyxtQkFBbUIsQ0FBQzs7SUFDcEQsQ0FBQztJQUVELHNDQUFhLEdBQWIsVUFBYyxRQUFnRDtRQUMxRCxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztRQUN6QixNQUFNLENBQUMsSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFTyx3Q0FBZSxHQUF2QixVQUF3QixRQUFjO1FBRWxDLHVHQUF1RztRQUN2RyxFQUFFLENBQUMsQ0FBQyxRQUFRLElBQUksT0FBTyxRQUFRLEtBQUssUUFBUSxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsSUFBSSxRQUFRLENBQUMsTUFBTSxDQUFDLENBQ3hGLENBQUM7WUFDRyxtSEFBbUg7WUFDbkgsRUFBRSxDQUFDLENBQUMsT0FBTyxRQUFRLENBQUMsTUFBTSxLQUFLLFFBQVEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsVUFBVSxJQUFJLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztnQkFDOUYsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1lBQ2pDLENBQUM7WUFBQSxJQUFJLENBQ0wsQ0FBQztnQkFDRyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztZQUMzQixDQUFDO1FBQ0wsQ0FBQztRQUFBLElBQUksQ0FBQyxDQUFDO1lBQ0gsTUFBTSxDQUFDLFFBQVEsQ0FBQztRQUNwQixDQUFDO0lBQ0wsQ0FBQztJQUVELHVDQUFjLEdBQWQsVUFBZSxRQUFhO1FBQ3hCLElBQUksY0FBbUIsQ0FBQztRQUN4QixJQUFJLGFBQWtCLENBQUM7UUFFdkIsSUFBSSxDQUFDO1lBQ0QsSUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3pELElBQUksY0FBYyxHQUFHLElBQUksQ0FBQztZQUUxQixFQUFFLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BCLEVBQUUsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLFVBQVUsS0FBSyxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7b0JBQ3pELGNBQWMsR0FBRyxpQkFBTSxzQkFBc0IsWUFDekMsRUFBRSxFQUNGO3dCQUNJLElBQUksRUFBRSxHQUFHO3dCQUNULE9BQU8sRUFBRSxxQkFBcUI7cUJBQ2pDLEVBQ0QsaUJBQWlCLENBQ3BCLENBQUM7Z0JBQ04sQ0FBQztnQkFBQyxJQUFJLENBQUMsQ0FBQztvQkFDSixjQUFjLEdBQUcsaUJBQU0sc0JBQXNCLFlBQ3pDLEVBQUUsRUFDRjt3QkFDSSxJQUFJLEVBQUUsSUFBSSxDQUFDLFlBQVk7d0JBQ3ZCLE9BQU8sRUFBRSxJQUFJLENBQUMsZUFBZTtxQkFDaEMsRUFDRCxpQkFBaUIsQ0FDcEIsQ0FBQztnQkFDTixDQUFDO1lBQ0wsQ0FBQztZQUVELEVBQUUsQ0FBQyxDQUFDLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxZQUFZLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDL0MsYUFBYSxHQUFHLElBQUksMkNBQW1CLENBQUMsNkJBQTZCLEVBQUUsNkNBQTJDLElBQUksQ0FBQyxZQUFZLFdBQU0sSUFBSSxDQUFDLGVBQWUsTUFBRyxDQUFDLENBQUM7WUFDdEssQ0FBQztZQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxjQUFjLFlBQVksMkNBQW1CLENBQUMsQ0FBQyxDQUFDO2dCQUNuRCw2QkFBNkI7Z0JBQzdCLGFBQWEsR0FBRyxjQUFjLENBQUM7WUFDdkMsQ0FBQztZQUFBLElBQUksQ0FBQyxDQUFDO2dCQUNILGNBQWMsR0FBRyxjQUFjLENBQUM7WUFDcEMsQ0FBQztRQUNMLENBQUM7UUFBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ1YsOEJBQThCO1lBQzlCLGFBQWEsR0FBRyxJQUFJLDJDQUFtQixDQUFDLHVCQUF1QixFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNqRixDQUFDO1FBR0QsSUFBTSxNQUFNLEdBQUcsSUFBSSxrQ0FBZSxDQUFJLGNBQWMsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUVyRSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUNoQixJQUFJLENBQUM7Z0JBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUMxQixDQUFDO1lBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUVkLENBQUM7UUFDTCxDQUFDO1FBRUQsTUFBTSxDQUFDLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBR0wscUJBQUM7QUFBRCxDQTlGQSxBQThGQyxDQTlGK0MseUNBQWtCLEdBOEZqRTtBQTlGcUIsd0NBQWMiLCJmaWxlIjoia2FsdHVyYS1yZXF1ZXN0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgS2FsdHVyYVJlc3BvbnNlIH0gZnJvbSBcIi4va2FsdHVyYS1yZXNwb25zZVwiO1xuaW1wb3J0IHsgS2FsdHVyYVJlcXVlc3RCYXNlLCBLYWx0dXJhUmVxdWVzdEJhc2VBcmdzIH0gZnJvbSBcIi4va2FsdHVyYS1yZXF1ZXN0LWJhc2VcIjtcbmltcG9ydCB7IEthbHR1cmFBUElFeGNlcHRpb24gfSBmcm9tICcuL2thbHR1cmEtYXBpLWV4Y2VwdGlvbic7XG5pbXBvcnQgeyBLYWx0dXJhT2JqZWN0QmFzZSB9IGZyb20gJy4va2FsdHVyYS1vYmplY3QtYmFzZSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgS2FsdHVyYVJlcXVlc3RBcmdzIGV4dGVuZHMgS2FsdHVyYVJlcXVlc3RCYXNlQXJnc1xue1xuXG59XG5cblxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIEthbHR1cmFSZXF1ZXN0PFQ+IGV4dGVuZHMgS2FsdHVyYVJlcXVlc3RCYXNlIHtcblxuICAgIHByb3RlY3RlZCBjYWxsYmFjazogKHJlc3BvbnNlOiBLYWx0dXJhUmVzcG9uc2U8VD4pID0+IHZvaWQ7XG4gICAgcHJpdmF0ZSByZXNwb25zZVR5cGUgOiBzdHJpbmc7XG4gICAgcHJpdmF0ZSByZXNwb25zZVN1YlR5cGUgOiBzdHJpbmc7XG4gICAgcHJpdmF0ZSBfcmVzcG9uc2VDb25zdHJ1Y3RvciA6IHsgbmV3KCkgOiBLYWx0dXJhT2JqZWN0QmFzZX07IC8vIE5PVElDRTogdGhpcyBwcm9wZXJ0eSBpcyBub3QgdXNlZCBkaXJlY3RseS4gSXQgaXMgaGVyZSB0byBmb3JjZSBpbXBvcnQgb2YgdGhhdCB0eXBlIGZvciBidW5kbGluZyBpc3N1ZXMuXG5cbiAgICBjb25zdHJ1Y3RvcihkYXRhIDogS2FsdHVyYVJlcXVlc3RCYXNlQXJncywge3Jlc3BvbnNlVHlwZSwgcmVzcG9uc2VTdWJUeXBlLCByZXNwb25zZUNvbnN0cnVjdG9yfSA6IHtyZXNwb25zZVR5cGUgOiBzdHJpbmcsIHJlc3BvbnNlU3ViVHlwZT8gOiBzdHJpbmcsIHJlc3BvbnNlQ29uc3RydWN0b3IgOiB7IG5ldygpIDogS2FsdHVyYU9iamVjdEJhc2V9ICB9ICkge1xuICAgICAgICBzdXBlcihkYXRhKTtcbiAgICAgICAgdGhpcy5yZXNwb25zZVN1YlR5cGUgPSByZXNwb25zZVN1YlR5cGU7XG4gICAgICAgIHRoaXMucmVzcG9uc2VUeXBlID0gcmVzcG9uc2VUeXBlO1xuICAgICAgICB0aGlzLl9yZXNwb25zZUNvbnN0cnVjdG9yID0gcmVzcG9uc2VDb25zdHJ1Y3RvcjtcbiAgICB9XG5cbiAgICBzZXRDb21wbGV0aW9uKGNhbGxiYWNrOiAocmVzcG9uc2U6IEthbHR1cmFSZXNwb25zZTxUPikgPT4gdm9pZCk6IHRoaXMge1xuICAgICAgICB0aGlzLmNhbGxiYWNrID0gY2FsbGJhY2s7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHByaXZhdGUgX3Vud3JhcFJlc3BvbnNlKHJlc3BvbnNlIDogYW55KSA6IGFueVxuICAgIHtcbiAgICAgICAgLy8gaWYgcmVzcG9uc2UgaXMgb2JqZWN0IHdpdGhvdXQgJ29iamVjdFR5cGUnIHByb3BlcnR5IGFuZCB3aXRoICdyZXN1bHQnIHByb3BlcnR5IC0+IGl0IGlzIG90dCByZXNwb25zZVxuICAgICAgICBpZiAocmVzcG9uc2UgJiYgdHlwZW9mIHJlc3BvbnNlID09PSAnb2JqZWN0JyAmJiAhcmVzcG9uc2Uub2JqZWN0VHlwZSAmJiByZXNwb25zZS5yZXN1bHQpXG4gICAgICAgIHtcbiAgICAgICAgICAgIC8vIGlmIHJlc3BvbnNlLnJlc3VsdCBpcyBvYmplY3Qgd2l0aG91dCAnb2JqZWN0VHlwZScgcHJvcGVydHkgYW5kIHdpdGggJ2Vycm9yJyBwcm9wZXJ0eSAtPiBpdCBpcyBvdHQgZXJyb3IgcmVzcG9uc2VcbiAgICAgICAgICAgIGlmICh0eXBlb2YgcmVzcG9uc2UucmVzdWx0ID09PSAnb2JqZWN0JyAmJiAhcmVzcG9uc2UucmVzdWx0Lm9iamVjdFR5cGUgJiYgcmVzcG9uc2UucmVzdWx0LmVycm9yKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLnJlc3VsdC5lcnJvcjtcbiAgICAgICAgICAgIH1lbHNlXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLnJlc3VsdDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfWVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgaGFuZGxlUmVzcG9uc2UocmVzcG9uc2U6IGFueSk6IEthbHR1cmFSZXNwb25zZTxUPiB7XG4gICAgICAgIGxldCByZXNwb25zZVJlc3VsdDogYW55O1xuICAgICAgICBsZXQgcmVzcG9uc2VFcnJvcjogYW55O1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCB1bndyYXBwZWRSZXNwb25zZSA9IHRoaXMuX3Vud3JhcFJlc3BvbnNlKHJlc3BvbnNlKTtcbiAgICAgICAgICAgIGxldCByZXNwb25zZU9iamVjdCA9IG51bGw7XG5cbiAgICAgICAgICAgIGlmICh1bndyYXBwZWRSZXNwb25zZSkge1xuICAgICAgICAgICAgICAgIGlmICh1bndyYXBwZWRSZXNwb25zZS5vYmplY3RUeXBlID09PSAnS2FsdHVyYUFQSUV4Y2VwdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2VPYmplY3QgPSBzdXBlci5fcGFyc2VSZXNwb25zZVByb3BlcnR5KFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnbycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3ViVHlwZTogJ0thbHR1cmFBUElFeGNlcHRpb24nXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgdW53cmFwcGVkUmVzcG9uc2VcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXNwb25zZU9iamVjdCA9IHN1cGVyLl9wYXJzZVJlc3BvbnNlUHJvcGVydHkoXG4gICAgICAgICAgICAgICAgICAgICAgICBcIlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IHRoaXMucmVzcG9uc2VUeXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1YlR5cGU6IHRoaXMucmVzcG9uc2VTdWJUeXBlXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgdW53cmFwcGVkUmVzcG9uc2VcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICghcmVzcG9uc2VPYmplY3QgJiYgdGhpcy5yZXNwb25zZVR5cGUgIT09ICd2Jykge1xuICAgICAgICAgICAgICAgIHJlc3BvbnNlRXJyb3IgPSBuZXcgS2FsdHVyYUFQSUV4Y2VwdGlvbignY2xpZW50OjpyZXNwb25zZV90eXBlX2Vycm9yJywgYHNlcnZlciByZXNwb25zZSBpcyB1bmRlZmluZWQsIGV4cGVjdGVkICcke3RoaXMucmVzcG9uc2VUeXBlfSAvICR7dGhpcy5yZXNwb25zZVN1YlR5cGV9J2ApO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChyZXNwb25zZU9iamVjdCBpbnN0YW5jZW9mIEthbHR1cmFBUElFeGNlcHRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gZ290IGV4Y2VwdGlvbiBmcm9tIGxpYnJhcnlcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2VFcnJvciA9IHJlc3BvbnNlT2JqZWN0O1xuICAgICAgICAgICAgfWVsc2Uge1xuICAgICAgICAgICAgICAgIHJlc3BvbnNlUmVzdWx0ID0gcmVzcG9uc2VPYmplY3Q7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGV4KSB7XG4gICAgICAgICAgICAvLyBUT0RPIFtrbWNdIHNob3VsZCBpbXBsZW1lbnRcbiAgICAgICAgICAgIHJlc3BvbnNlRXJyb3IgPSBuZXcgS2FsdHVyYUFQSUV4Y2VwdGlvbignY2xpZW50OjpnZW5lcmFsX2Vycm9yJywgZXgubWVzc2FnZSk7XG4gICAgICAgIH1cblxuXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBLYWx0dXJhUmVzcG9uc2U8VD4ocmVzcG9uc2VSZXN1bHQsIHJlc3BvbnNlRXJyb3IpO1xuXG4gICAgICAgIGlmICh0aGlzLmNhbGxiYWNrKSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHRoaXMuY2FsbGJhY2socmVzdWx0KTtcbiAgICAgICAgICAgIH0gY2F0Y2ggKGV4KSB7XG4gICAgICAgICAgICAgICAgLy8gZG8gbm90aGluZyBieSBkZXNpZ25cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuXG5cbn1cbiJdfQ==
