"use strict";
var KalturaResponse = (function () {
    function KalturaResponse(result, error) {
        this.result = result;
        this.error = error;
    }
    return KalturaResponse;
}());
exports.KalturaResponse = KalturaResponse;

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImthbHR1cmEtcmVzcG9uc2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUVBO0lBRUkseUJBQW1CLE1BQVUsRUFBUyxLQUEyQjtRQUE5QyxXQUFNLEdBQU4sTUFBTSxDQUFJO1FBQVMsVUFBSyxHQUFMLEtBQUssQ0FBc0I7SUFJakUsQ0FBQztJQUNMLHNCQUFDO0FBQUQsQ0FQQSxBQU9DLElBQUE7QUFQWSwwQ0FBZSIsImZpbGUiOiJrYWx0dXJhLXJlc3BvbnNlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgS2FsdHVyYUFQSUV4Y2VwdGlvbiB9IGZyb20gXCIuL2thbHR1cmEtYXBpLWV4Y2VwdGlvblwiO1xuXG5leHBvcnQgY2xhc3MgS2FsdHVyYVJlc3BvbnNlPFQ+IHtcblxuICAgIGNvbnN0cnVjdG9yKHB1YmxpYyByZXN1bHQgOiBULCBwdWJsaWMgZXJyb3IgOiBLYWx0dXJhQVBJRXhjZXB0aW9uKVxuICAgIHtcblxuXG4gICAgfVxufVxuIl19
