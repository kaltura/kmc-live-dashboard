import { KalturaObjectBase } from './kaltura-object-base';
export declare type KalturaObjectClass = {
    new (...args): any;
};
export declare class KalturaTypesFactory {
    static registerType(typeName: string, objectCtor: KalturaObjectClass): void;
    static createObject(type: KalturaObjectBase): KalturaObjectBase;
    static createObject(typeName: string): KalturaObjectBase;
}
