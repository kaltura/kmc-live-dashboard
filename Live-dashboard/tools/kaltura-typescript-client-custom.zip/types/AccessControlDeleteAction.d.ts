import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AccessControlDeleteActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Delete Access Control Profile by id
**/
export declare class AccessControlDeleteAction extends KalturaRequest<void> {
    id: number;
    constructor(data: AccessControlDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
