import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaAccessControl } from './KalturaAccessControl';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AccessControlGetActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Get Access Control Profile by id
**/
export declare class AccessControlGetAction extends KalturaRequest<KalturaAccessControl> {
    id: number;
    constructor(data: AccessControlGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
