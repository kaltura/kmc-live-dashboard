import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaAccessControlProfile } from './KalturaAccessControlProfile';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AccessControlProfileAddActionArgs extends KalturaRequestArgs {
    accessControlProfile: KalturaAccessControlProfile;
}
/**
* Add new access control profile
**/
export declare class AccessControlProfileAddAction extends KalturaRequest<KalturaAccessControlProfile> {
    accessControlProfile: KalturaAccessControlProfile;
    constructor(data: AccessControlProfileAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
