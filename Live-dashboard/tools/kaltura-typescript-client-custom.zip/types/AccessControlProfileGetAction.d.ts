import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaAccessControlProfile } from './KalturaAccessControlProfile';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AccessControlProfileGetActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Get access control profile by id
**/
export declare class AccessControlProfileGetAction extends KalturaRequest<KalturaAccessControlProfile> {
    id: number;
    constructor(data: AccessControlProfileGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
