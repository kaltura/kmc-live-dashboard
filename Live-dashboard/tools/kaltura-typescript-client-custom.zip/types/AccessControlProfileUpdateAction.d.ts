import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaAccessControlProfile } from './KalturaAccessControlProfile';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AccessControlProfileUpdateActionArgs extends KalturaRequestArgs {
    id: number;
    accessControlProfile: KalturaAccessControlProfile;
}
/**
* Update access control profile by id
**/
export declare class AccessControlProfileUpdateAction extends KalturaRequest<KalturaAccessControlProfile> {
    id: number;
    accessControlProfile: KalturaAccessControlProfile;
    constructor(data: AccessControlProfileUpdateActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
