import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AdminUserResetPasswordActionArgs extends KalturaRequestArgs {
    email: string;
}
/**
* Reset admin user password and send it to the users email address
**/
export declare class AdminUserResetPasswordAction extends KalturaRequest<void> {
    email: string;
    constructor(data: AdminUserResetPasswordActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
