import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCuePoint } from './KalturaCuePoint';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AnnotationCloneActionArgs extends KalturaRequestArgs {
    id: string;
    entryId: string;
}
/**
* Clone cuePoint with id to given entry
**/
export declare class AnnotationCloneAction extends KalturaRequest<KalturaCuePoint> {
    id: string;
    entryId: string;
    constructor(data: AnnotationCloneActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
