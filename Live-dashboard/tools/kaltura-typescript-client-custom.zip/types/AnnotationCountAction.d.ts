import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCuePointFilter } from './KalturaCuePointFilter';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AnnotationCountActionArgs extends KalturaRequestArgs {
    filter?: KalturaCuePointFilter;
}
/**
* count cue point objects by filter
**/
export declare class AnnotationCountAction extends KalturaRequest<number> {
    filter: KalturaCuePointFilter;
    constructor(data?: AnnotationCountActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
