import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AnnotationDeleteActionArgs extends KalturaRequestArgs {
    id: string;
}
/**
* delete cue point by id, and delete all children cue points
**/
export declare class AnnotationDeleteAction extends KalturaRequest<void> {
    id: string;
    constructor(data: AnnotationDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
