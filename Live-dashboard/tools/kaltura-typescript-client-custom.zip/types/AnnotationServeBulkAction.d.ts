import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCuePointFilter } from './KalturaCuePointFilter';
import { KalturaFilterPager } from './KalturaFilterPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AnnotationServeBulkActionArgs extends KalturaRequestArgs {
    filter?: KalturaCuePointFilter;
    pager?: KalturaFilterPager;
}
/**
* Download multiple cue points objects as XML definitions
**/
export declare class AnnotationServeBulkAction extends KalturaRequest<string> {
    filter: KalturaCuePointFilter;
    pager: KalturaFilterPager;
    constructor(data?: AnnotationServeBulkActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
