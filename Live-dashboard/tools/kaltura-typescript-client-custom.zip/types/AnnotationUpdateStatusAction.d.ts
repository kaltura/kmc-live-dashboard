import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCuePointStatus } from './KalturaCuePointStatus';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AnnotationUpdateStatusActionArgs extends KalturaRequestArgs {
    id: string;
    status: KalturaCuePointStatus;
}
/**
* Update cuePoint status by id
**/
export declare class AnnotationUpdateStatusAction extends KalturaRequest<void> {
    id: string;
    status: KalturaCuePointStatus;
    constructor(data: AnnotationUpdateStatusActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
