import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AppTokenDeleteActionArgs extends KalturaRequestArgs {
    id: string;
}
/**
* Delete application authentication token by id
**/
export declare class AppTokenDeleteAction extends KalturaRequest<void> {
    id: string;
    constructor(data: AppTokenDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
