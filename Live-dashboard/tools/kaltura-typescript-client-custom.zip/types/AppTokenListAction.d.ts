import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaAppTokenListResponse } from './KalturaAppTokenListResponse';
import { KalturaAppTokenFilter } from './KalturaAppTokenFilter';
import { KalturaFilterPager } from './KalturaFilterPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AppTokenListActionArgs extends KalturaRequestArgs {
    filter?: KalturaAppTokenFilter;
    pager?: KalturaFilterPager;
}
/**
* List application authentication tokens by filter and pager
**/
export declare class AppTokenListAction extends KalturaRequest<KalturaAppTokenListResponse> {
    filter: KalturaAppTokenFilter;
    pager: KalturaFilterPager;
    constructor(data?: AppTokenListActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
