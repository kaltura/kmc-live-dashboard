import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AttachmentAssetDeleteActionArgs extends KalturaRequestArgs {
    attachmentAssetId: string;
}
export declare class AttachmentAssetDeleteAction extends KalturaRequest<void> {
    attachmentAssetId: string;
    constructor(data: AttachmentAssetDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
