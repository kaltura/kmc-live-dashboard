import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaAttachmentAsset } from './KalturaAttachmentAsset';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AttachmentAssetGetActionArgs extends KalturaRequestArgs {
    attachmentAssetId: string;
}
export declare class AttachmentAssetGetAction extends KalturaRequest<KalturaAttachmentAsset> {
    attachmentAssetId: string;
    constructor(data: AttachmentAssetGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
