import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRemotePathListResponse } from './KalturaRemotePathListResponse';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AttachmentAssetGetRemotePathsActionArgs extends KalturaRequestArgs {
    id: string;
}
/**
* Get remote storage existing paths for the asset
**/
export declare class AttachmentAssetGetRemotePathsAction extends KalturaRequest<KalturaRemotePathListResponse> {
    id: string;
    constructor(data: AttachmentAssetGetRemotePathsActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
