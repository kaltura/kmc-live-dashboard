import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AttachmentAssetGetUrlActionArgs extends KalturaRequestArgs {
    id: string;
    storageId?: number;
}
/**
* Get download URL for the asset
**/
export declare class AttachmentAssetGetUrlAction extends KalturaRequest<string> {
    id: string;
    storageId: number;
    constructor(data: AttachmentAssetGetUrlActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
