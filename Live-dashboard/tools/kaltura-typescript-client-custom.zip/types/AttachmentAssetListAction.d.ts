import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaAttachmentAssetListResponse } from './KalturaAttachmentAssetListResponse';
import { KalturaAssetFilter } from './KalturaAssetFilter';
import { KalturaFilterPager } from './KalturaFilterPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AttachmentAssetListActionArgs extends KalturaRequestArgs {
    filter?: KalturaAssetFilter;
    pager?: KalturaFilterPager;
}
/**
* List attachment Assets by filter and pager
**/
export declare class AttachmentAssetListAction extends KalturaRequest<KalturaAttachmentAssetListResponse> {
    filter: KalturaAssetFilter;
    pager: KalturaFilterPager;
    constructor(data?: AttachmentAssetListActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
