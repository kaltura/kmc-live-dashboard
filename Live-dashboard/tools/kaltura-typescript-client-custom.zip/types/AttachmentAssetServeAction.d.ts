import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaAttachmentServeOptions } from './KalturaAttachmentServeOptions';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AttachmentAssetServeActionArgs extends KalturaRequestArgs {
    attachmentAssetId: string;
    serveOptions?: KalturaAttachmentServeOptions;
}
/**
* Serves attachment by its id
**/
export declare class AttachmentAssetServeAction extends KalturaRequest<string> {
    attachmentAssetId: string;
    serveOptions: KalturaAttachmentServeOptions;
    constructor(data: AttachmentAssetServeActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
