import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaAttachmentAsset } from './KalturaAttachmentAsset';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface AttachmentAssetUpdateActionArgs extends KalturaRequestArgs {
    id: string;
    attachmentAsset: KalturaAttachmentAsset;
}
/**
* Update attachment asset
**/
export declare class AttachmentAssetUpdateAction extends KalturaRequest<KalturaAttachmentAsset> {
    id: string;
    attachmentAsset: KalturaAttachmentAsset;
    constructor(data: AttachmentAssetUpdateActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
