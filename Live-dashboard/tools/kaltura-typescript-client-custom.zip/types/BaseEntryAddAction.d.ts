import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBaseEntry } from './KalturaBaseEntry';
import { KalturaEntryType } from './KalturaEntryType';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BaseEntryAddActionArgs extends KalturaRequestArgs {
    entry: KalturaBaseEntry;
    type?: KalturaEntryType;
}
/**
* Generic add entry, should be used when the uploaded entry type is not known.
**/
export declare class BaseEntryAddAction extends KalturaRequest<KalturaBaseEntry> {
    entry: KalturaBaseEntry;
    type: KalturaEntryType;
    constructor(data: BaseEntryAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
