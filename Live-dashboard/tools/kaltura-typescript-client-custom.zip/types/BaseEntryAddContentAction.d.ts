import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBaseEntry } from './KalturaBaseEntry';
import { KalturaResource } from './KalturaResource';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BaseEntryAddContentActionArgs extends KalturaRequestArgs {
    entryId: string;
    resource: KalturaResource;
}
/**
* Attach content resource to entry in status NO_MEDIA
**/
export declare class BaseEntryAddContentAction extends KalturaRequest<KalturaBaseEntry> {
    entryId: string;
    resource: KalturaResource;
    constructor(data: BaseEntryAddContentActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
