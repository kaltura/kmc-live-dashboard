import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BaseEntryApproveActionArgs extends KalturaRequestArgs {
    entryId: string;
}
/**
* Approve the entry and mark the pending flags (if any) as moderated (this will
* make the entry playable).
**/
export declare class BaseEntryApproveAction extends KalturaRequest<void> {
    entryId: string;
    constructor(data: BaseEntryApproveActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
