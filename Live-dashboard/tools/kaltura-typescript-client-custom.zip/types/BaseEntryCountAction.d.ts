import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBaseEntryFilter } from './KalturaBaseEntryFilter';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BaseEntryCountActionArgs extends KalturaRequestArgs {
    filter?: KalturaBaseEntryFilter;
}
/**
* Count base entries by filter.
**/
export declare class BaseEntryCountAction extends KalturaRequest<number> {
    filter: KalturaBaseEntryFilter;
    constructor(data?: BaseEntryCountActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
