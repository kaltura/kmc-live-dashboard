import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBaseEntry } from './KalturaBaseEntry';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BaseEntryExportActionArgs extends KalturaRequestArgs {
    entryId: string;
    storageProfileId: number;
}
export declare class BaseEntryExportAction extends KalturaRequest<KalturaBaseEntry> {
    entryId: string;
    storageProfileId: number;
    constructor(data: BaseEntryExportActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
