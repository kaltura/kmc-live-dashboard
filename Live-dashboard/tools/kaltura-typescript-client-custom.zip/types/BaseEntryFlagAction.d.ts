import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaModerationFlag } from './KalturaModerationFlag';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BaseEntryFlagActionArgs extends KalturaRequestArgs {
    moderationFlag: KalturaModerationFlag;
}
/**
* Flag inappropriate entry for moderation.
**/
export declare class BaseEntryFlagAction extends KalturaRequest<void> {
    moderationFlag: KalturaModerationFlag;
    constructor(data: BaseEntryFlagActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
