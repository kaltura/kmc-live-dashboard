import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBaseEntry } from './KalturaBaseEntry';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BaseEntryGetByIdsActionArgs extends KalturaRequestArgs {
    entryIds: string;
}
/**
* Get an array of KalturaBaseEntry objects by a comma-separated list of ids.
**/
export declare class BaseEntryGetByIdsAction extends KalturaRequest<KalturaBaseEntry[]> {
    entryIds: string;
    constructor(data: BaseEntryGetByIdsActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
