import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBaseEntryListResponse } from './KalturaBaseEntryListResponse';
import { KalturaBaseEntryFilter } from './KalturaBaseEntryFilter';
import { KalturaFilterPager } from './KalturaFilterPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BaseEntryListActionArgs extends KalturaRequestArgs {
    filter?: KalturaBaseEntryFilter;
    pager?: KalturaFilterPager;
}
/**
* List base entries by filter with paging support.
**/
export declare class BaseEntryListAction extends KalturaRequest<KalturaBaseEntryListResponse> {
    filter: KalturaBaseEntryFilter;
    pager: KalturaFilterPager;
    constructor(data?: BaseEntryListActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
