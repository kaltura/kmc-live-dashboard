import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBaseEntryListResponse } from './KalturaBaseEntryListResponse';
import { KalturaFilterPager } from './KalturaFilterPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BaseEntryListByReferenceIdActionArgs extends KalturaRequestArgs {
    refId: string;
    pager?: KalturaFilterPager;
}
/**
* List base entries by filter according to reference id
**/
export declare class BaseEntryListByReferenceIdAction extends KalturaRequest<KalturaBaseEntryListResponse> {
    refId: string;
    pager: KalturaFilterPager;
    constructor(data: BaseEntryListByReferenceIdActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
