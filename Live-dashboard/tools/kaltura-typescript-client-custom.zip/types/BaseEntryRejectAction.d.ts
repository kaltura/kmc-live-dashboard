import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BaseEntryRejectActionArgs extends KalturaRequestArgs {
    entryId: string;
}
/**
* Reject the entry and mark the pending flags (if any) as moderated (this will
* make the entry non-playable).
**/
export declare class BaseEntryRejectAction extends KalturaRequest<void> {
    entryId: string;
    constructor(data: BaseEntryRejectActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
