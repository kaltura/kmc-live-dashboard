import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBeacon } from './KalturaBeacon';
import { KalturaNullableBoolean } from './KalturaNullableBoolean';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BeaconAddActionArgs extends KalturaRequestArgs {
    beacon: KalturaBeacon;
    shouldLog?: KalturaNullableBoolean;
    ttl?: number;
}
export declare class BeaconAddAction extends KalturaRequest<boolean> {
    beacon: KalturaBeacon;
    shouldLog: KalturaNullableBoolean;
    ttl: number;
    constructor(data: BeaconAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
