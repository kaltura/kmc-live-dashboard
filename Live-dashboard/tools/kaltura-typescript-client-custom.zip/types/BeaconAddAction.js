"use strict";
var tslib_1 = require("tslib");
var KalturaBeacon_1 = require("./KalturaBeacon");
var KalturaNullableBoolean_1 = require("./KalturaNullableBoolean");
var kaltura_request_1 = require("../kaltura-request");
var BeaconAddAction = (function (_super) {
    tslib_1.__extends(BeaconAddAction, _super);
    function BeaconAddAction(data) {
        var _this = _super.call(this, data, { responseType: 'b', responseSubType: '', responseConstructor: null }) || this;
        if (typeof _this.ttl === 'undefined')
            _this.ttl = 600;
        return _this;
    }
    BeaconAddAction.prototype._getMetadata = function () {
        var result = _super.prototype._getMetadata.call(this);
        Object.assign(result.properties, {
            service: { type: 'c', default: 'beacon_beacon' },
            action: { type: 'c', default: 'add' },
            beacon: { type: 'o', subTypeConstructor: KalturaBeacon_1.KalturaBeacon, subType: 'KalturaBeacon' },
            shouldLog: { type: 'en', subTypeConstructor: KalturaNullableBoolean_1.KalturaNullableBoolean, subType: 'KalturaNullableBoolean' },
            ttl: { type: 'n' }
        });
        return result;
    };
    return BeaconAddAction;
}(kaltura_request_1.KalturaRequest));
exports.BeaconAddAction = BeaconAddAction;

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInR5cGVzL0JlYWNvbkFkZEFjdGlvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUlBLGlEQUFnRDtBQUNoRCxtRUFBa0U7QUFDbEUsc0RBQXdFO0FBU3hFO0lBQXFDLDJDQUF1QjtJQU14RCx5QkFBWSxJQUEwQjtRQUF0QyxZQUVJLGtCQUFNLElBQUksRUFBRSxFQUFDLFlBQVksRUFBRyxHQUFHLEVBQUUsZUFBZSxFQUFHLEVBQUUsRUFBRSxtQkFBbUIsRUFBRyxJQUFJLEVBQUUsQ0FBQyxTQUV2RjtRQURHLEVBQUUsQ0FBQyxDQUFDLE9BQU8sS0FBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLENBQUM7WUFBQyxLQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQzs7SUFDeEQsQ0FBQztJQUVTLHNDQUFZLEdBQXRCO1FBRUksSUFBTSxNQUFNLEdBQUcsaUJBQU0sWUFBWSxXQUFFLENBQUM7UUFDcEMsTUFBTSxDQUFDLE1BQU0sQ0FDVCxNQUFNLENBQUMsVUFBVSxFQUNqQjtZQUNJLE9BQU8sRUFBRyxFQUFFLElBQUksRUFBRyxHQUFHLEVBQUUsT0FBTyxFQUFHLGVBQWUsRUFBRTtZQUMvRCxNQUFNLEVBQUcsRUFBRSxJQUFJLEVBQUcsR0FBRyxFQUFFLE9BQU8sRUFBRyxLQUFLLEVBQUU7WUFDeEMsTUFBTSxFQUFHLEVBQUUsSUFBSSxFQUFHLEdBQUcsRUFBRSxrQkFBa0IsRUFBRyw2QkFBYSxFQUFFLE9BQU8sRUFBRyxlQUFlLEVBQUU7WUFDdEYsU0FBUyxFQUFHLEVBQUUsSUFBSSxFQUFHLElBQUksRUFBRSxrQkFBa0IsRUFBRywrQ0FBc0IsRUFBRSxPQUFPLEVBQUcsd0JBQXdCLEVBQUU7WUFDNUcsR0FBRyxFQUFHLEVBQUUsSUFBSSxFQUFHLEdBQUcsRUFBRTtTQUNYLENBQ0osQ0FBQztRQUNGLE1BQU0sQ0FBQyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUNMLHNCQUFDO0FBQUQsQ0EzQkEsQUEyQkMsQ0EzQm9DLGdDQUFjLEdBMkJsRDtBQTNCWSwwQ0FBZSIsImZpbGUiOiJ0eXBlcy9CZWFjb25BZGRBY3Rpb24uanMiLCJzb3VyY2VzQ29udGVudCI6WyJcbmltcG9ydCB7IEthbHR1cmFPYmplY3RNZXRhZGF0YSB9IGZyb20gJy4uL2thbHR1cmEtb2JqZWN0LWJhc2UnO1xuXG5cbmltcG9ydCB7IEthbHR1cmFCZWFjb24gfSBmcm9tICcuL0thbHR1cmFCZWFjb24nO1xuaW1wb3J0IHsgS2FsdHVyYU51bGxhYmxlQm9vbGVhbiB9IGZyb20gJy4vS2FsdHVyYU51bGxhYmxlQm9vbGVhbic7XG5pbXBvcnQgeyBLYWx0dXJhUmVxdWVzdCwgS2FsdHVyYVJlcXVlc3RBcmdzIH0gZnJvbSAnLi4va2FsdHVyYS1yZXF1ZXN0JztcblxuZXhwb3J0IGludGVyZmFjZSBCZWFjb25BZGRBY3Rpb25BcmdzICBleHRlbmRzIEthbHR1cmFSZXF1ZXN0QXJncyB7XG4gICAgYmVhY29uIDogS2FsdHVyYUJlYWNvbjtcblx0c2hvdWxkTG9nPyA6IEthbHR1cmFOdWxsYWJsZUJvb2xlYW47XG5cdHR0bD8gOiBudW1iZXI7XG59XG5cblxuZXhwb3J0IGNsYXNzIEJlYWNvbkFkZEFjdGlvbiBleHRlbmRzIEthbHR1cmFSZXF1ZXN0PGJvb2xlYW4+IHtcblxuICAgIGJlYWNvbiA6IEthbHR1cmFCZWFjb247XG5cdHNob3VsZExvZyA6IEthbHR1cmFOdWxsYWJsZUJvb2xlYW47XG5cdHR0bCA6IG51bWJlcjtcblxuICAgIGNvbnN0cnVjdG9yKGRhdGEgOiBCZWFjb25BZGRBY3Rpb25BcmdzKVxuICAgIHtcbiAgICAgICAgc3VwZXIoZGF0YSwge3Jlc3BvbnNlVHlwZSA6ICdiJywgcmVzcG9uc2VTdWJUeXBlIDogJycsIHJlc3BvbnNlQ29uc3RydWN0b3IgOiBudWxsIH0pO1xuICAgICAgICBpZiAodHlwZW9mIHRoaXMudHRsID09PSAndW5kZWZpbmVkJykgdGhpcy50dGwgPSA2MDA7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIF9nZXRNZXRhZGF0YSgpIDogS2FsdHVyYU9iamVjdE1ldGFkYXRhXG4gICAge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBzdXBlci5fZ2V0TWV0YWRhdGEoKTtcbiAgICAgICAgT2JqZWN0LmFzc2lnbihcbiAgICAgICAgICAgIHJlc3VsdC5wcm9wZXJ0aWVzLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHNlcnZpY2UgOiB7IHR5cGUgOiAnYycsIGRlZmF1bHQgOiAnYmVhY29uX2JlYWNvbicgfSxcblx0XHRcdFx0YWN0aW9uIDogeyB0eXBlIDogJ2MnLCBkZWZhdWx0IDogJ2FkZCcgfSxcblx0XHRcdFx0YmVhY29uIDogeyB0eXBlIDogJ28nLCBzdWJUeXBlQ29uc3RydWN0b3IgOiBLYWx0dXJhQmVhY29uLCBzdWJUeXBlIDogJ0thbHR1cmFCZWFjb24nIH0sXG5cdFx0XHRcdHNob3VsZExvZyA6IHsgdHlwZSA6ICdlbicsIHN1YlR5cGVDb25zdHJ1Y3RvciA6IEthbHR1cmFOdWxsYWJsZUJvb2xlYW4sIHN1YlR5cGUgOiAnS2FsdHVyYU51bGxhYmxlQm9vbGVhbicgfSxcblx0XHRcdFx0dHRsIDogeyB0eXBlIDogJ24nIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG59XG5cbiJdfQ==
