import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBeaconListResponse } from './KalturaBeaconListResponse';
import { KalturaBeaconFilter } from './KalturaBeaconFilter';
import { KalturaFilterPager } from './KalturaFilterPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BeaconGetLastActionArgs extends KalturaRequestArgs {
    filter?: KalturaBeaconFilter;
    pager?: KalturaFilterPager;
}
export declare class BeaconGetLastAction extends KalturaRequest<KalturaBeaconListResponse> {
    filter: KalturaBeaconFilter;
    pager: KalturaFilterPager;
    constructor(data?: BeaconGetLastActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
