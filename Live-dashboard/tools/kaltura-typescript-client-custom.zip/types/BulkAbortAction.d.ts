import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBulkUpload } from './KalturaBulkUpload';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BulkAbortActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Aborts the bulk upload and all its child jobs
**/
export declare class BulkAbortAction extends KalturaRequest<KalturaBulkUpload> {
    id: number;
    constructor(data: BulkAbortActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
