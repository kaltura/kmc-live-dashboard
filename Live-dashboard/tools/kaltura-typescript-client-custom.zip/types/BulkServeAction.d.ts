import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BulkServeActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* serve action returns the original file.
**/
export declare class BulkServeAction extends KalturaRequest<string> {
    id: number;
    constructor(data: BulkServeActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
