import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BulkServeLogActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* serveLog action returns the log file for the bulk-upload job.
**/
export declare class BulkServeLogAction extends KalturaRequest<string> {
    id: number;
    constructor(data: BulkServeLogActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
