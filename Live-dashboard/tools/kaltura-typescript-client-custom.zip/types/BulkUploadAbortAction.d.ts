import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBulkUpload } from './KalturaBulkUpload';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BulkUploadAbortActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Aborts the bulk upload and all its child jobs
**/
export declare class BulkUploadAbortAction extends KalturaRequest<KalturaBulkUpload> {
    id: number;
    constructor(data: BulkUploadAbortActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
