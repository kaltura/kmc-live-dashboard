import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBulkUpload } from './KalturaBulkUpload';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BulkUploadGetActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Get bulk upload batch job by id
**/
export declare class BulkUploadGetAction extends KalturaRequest<KalturaBulkUpload> {
    id: number;
    constructor(data: BulkUploadGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
