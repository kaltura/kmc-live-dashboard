import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BulkUploadServeActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* serve action returan the original file.
**/
export declare class BulkUploadServeAction extends KalturaRequest<string> {
    id: number;
    constructor(data: BulkUploadServeActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
