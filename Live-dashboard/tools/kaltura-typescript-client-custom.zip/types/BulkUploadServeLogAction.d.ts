import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface BulkUploadServeLogActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* serveLog action returan the original file.
**/
export declare class BulkUploadServeLogAction extends KalturaRequest<string> {
    id: number;
    constructor(data: BulkUploadServeLogActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
