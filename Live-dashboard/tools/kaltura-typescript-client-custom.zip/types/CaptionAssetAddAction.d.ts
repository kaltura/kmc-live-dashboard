import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCaptionAsset } from './KalturaCaptionAsset';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CaptionAssetAddActionArgs extends KalturaRequestArgs {
    entryId: string;
    captionAsset: KalturaCaptionAsset;
}
/**
* Add caption asset
**/
export declare class CaptionAssetAddAction extends KalturaRequest<KalturaCaptionAsset> {
    entryId: string;
    captionAsset: KalturaCaptionAsset;
    constructor(data: CaptionAssetAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
