import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CaptionAssetDeleteActionArgs extends KalturaRequestArgs {
    captionAssetId: string;
}
export declare class CaptionAssetDeleteAction extends KalturaRequest<void> {
    captionAssetId: string;
    constructor(data: CaptionAssetDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
