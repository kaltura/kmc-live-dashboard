import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRemotePathListResponse } from './KalturaRemotePathListResponse';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CaptionAssetGetRemotePathsActionArgs extends KalturaRequestArgs {
    id: string;
}
/**
* Get remote storage existing paths for the asset
**/
export declare class CaptionAssetGetRemotePathsAction extends KalturaRequest<KalturaRemotePathListResponse> {
    id: string;
    constructor(data: CaptionAssetGetRemotePathsActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
