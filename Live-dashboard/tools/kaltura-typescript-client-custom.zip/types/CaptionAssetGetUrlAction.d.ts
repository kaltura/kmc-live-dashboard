import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CaptionAssetGetUrlActionArgs extends KalturaRequestArgs {
    id: string;
    storageId?: number;
}
/**
* Get download URL for the asset
**/
export declare class CaptionAssetGetUrlAction extends KalturaRequest<string> {
    id: string;
    storageId: number;
    constructor(data: CaptionAssetGetUrlActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
