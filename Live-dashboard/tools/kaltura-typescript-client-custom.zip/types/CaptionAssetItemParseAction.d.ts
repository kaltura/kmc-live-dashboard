import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CaptionAssetItemParseActionArgs extends KalturaRequestArgs {
    captionAssetId: string;
}
/**
* Parse content of caption asset and index it
**/
export declare class CaptionAssetItemParseAction extends KalturaRequest<void> {
    captionAssetId: string;
    constructor(data: CaptionAssetItemParseActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
