import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaBaseEntryListResponse } from './KalturaBaseEntryListResponse';
import { KalturaBaseEntryFilter } from './KalturaBaseEntryFilter';
import { KalturaCaptionAssetItemFilter } from './KalturaCaptionAssetItemFilter';
import { KalturaFilterPager } from './KalturaFilterPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CaptionAssetItemSearchEntriesActionArgs extends KalturaRequestArgs {
    entryFilter?: KalturaBaseEntryFilter;
    captionAssetItemFilter?: KalturaCaptionAssetItemFilter;
    captionAssetItemPager?: KalturaFilterPager;
}
/**
* Search caption asset items by filter, pager and free text
**/
export declare class CaptionAssetItemSearchEntriesAction extends KalturaRequest<KalturaBaseEntryListResponse> {
    entryFilter: KalturaBaseEntryFilter;
    captionAssetItemFilter: KalturaCaptionAssetItemFilter;
    captionAssetItemPager: KalturaFilterPager;
    constructor(data?: CaptionAssetItemSearchEntriesActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
