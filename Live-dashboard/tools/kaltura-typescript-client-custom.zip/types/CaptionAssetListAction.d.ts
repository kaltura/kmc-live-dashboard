import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCaptionAssetListResponse } from './KalturaCaptionAssetListResponse';
import { KalturaAssetFilter } from './KalturaAssetFilter';
import { KalturaFilterPager } from './KalturaFilterPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CaptionAssetListActionArgs extends KalturaRequestArgs {
    filter?: KalturaAssetFilter;
    pager?: KalturaFilterPager;
}
/**
* List caption Assets by filter and pager
**/
export declare class CaptionAssetListAction extends KalturaRequest<KalturaCaptionAssetListResponse> {
    filter: KalturaAssetFilter;
    pager: KalturaFilterPager;
    constructor(data?: CaptionAssetListActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
