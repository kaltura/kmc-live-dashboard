import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CaptionAssetServeActionArgs extends KalturaRequestArgs {
    captionAssetId: string;
}
/**
* Serves caption by its id
**/
export declare class CaptionAssetServeAction extends KalturaRequest<string> {
    captionAssetId: string;
    constructor(data: CaptionAssetServeActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
