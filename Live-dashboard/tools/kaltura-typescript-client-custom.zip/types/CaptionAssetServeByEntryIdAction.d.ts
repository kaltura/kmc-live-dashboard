import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CaptionAssetServeByEntryIdActionArgs extends KalturaRequestArgs {
    entryId: string;
    captionParamId?: number;
}
/**
* Serves caption by entry id and thumnail params id
**/
export declare class CaptionAssetServeByEntryIdAction extends KalturaRequest<string> {
    entryId: string;
    captionParamId: number;
    constructor(data: CaptionAssetServeByEntryIdActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
