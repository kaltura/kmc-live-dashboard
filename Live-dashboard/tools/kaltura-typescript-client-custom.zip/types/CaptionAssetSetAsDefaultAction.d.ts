import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CaptionAssetSetAsDefaultActionArgs extends KalturaRequestArgs {
    captionAssetId: string;
}
/**
* Markss the caption as default and removes that mark from all other caption
* assets of the entry.
**/
export declare class CaptionAssetSetAsDefaultAction extends KalturaRequest<void> {
    captionAssetId: string;
    constructor(data: CaptionAssetSetAsDefaultActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
