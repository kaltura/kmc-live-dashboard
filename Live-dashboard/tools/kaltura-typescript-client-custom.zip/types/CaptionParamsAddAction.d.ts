import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCaptionParams } from './KalturaCaptionParams';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CaptionParamsAddActionArgs extends KalturaRequestArgs {
    captionParams: KalturaCaptionParams;
}
/**
* Add new Caption Params
**/
export declare class CaptionParamsAddAction extends KalturaRequest<KalturaCaptionParams> {
    captionParams: KalturaCaptionParams;
    constructor(data: CaptionParamsAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
