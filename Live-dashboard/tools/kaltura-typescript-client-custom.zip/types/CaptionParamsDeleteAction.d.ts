import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CaptionParamsDeleteActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Delete Caption Params by ID
**/
export declare class CaptionParamsDeleteAction extends KalturaRequest<void> {
    id: number;
    constructor(data: CaptionParamsDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
