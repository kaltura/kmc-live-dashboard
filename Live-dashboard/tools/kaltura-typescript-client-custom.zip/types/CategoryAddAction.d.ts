import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCategory } from './KalturaCategory';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CategoryAddActionArgs extends KalturaRequestArgs {
    category: KalturaCategory;
}
/**
* Add new Category
**/
export declare class CategoryAddAction extends KalturaRequest<KalturaCategory> {
    category: KalturaCategory;
    constructor(data: CategoryAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
