import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaNullableBoolean } from './KalturaNullableBoolean';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CategoryDeleteActionArgs extends KalturaRequestArgs {
    id: number;
    moveEntriesToParentCategory?: KalturaNullableBoolean;
}
/**
* Delete a Category
**/
export declare class CategoryDeleteAction extends KalturaRequest<void> {
    id: number;
    moveEntriesToParentCategory: KalturaNullableBoolean;
    constructor(data: CategoryDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
