import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CategoryEntryDeleteActionArgs extends KalturaRequestArgs {
    entryId: string;
    categoryId: number;
}
/**
* Delete CategoryEntry
**/
export declare class CategoryEntryDeleteAction extends KalturaRequest<void> {
    entryId: string;
    categoryId: number;
    constructor(data: CategoryEntryDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
