"use strict";
var tslib_1 = require("tslib");
var kaltura_request_1 = require("../kaltura-request");
/**
* Index CategoryEntry by Id
**/
var CategoryEntryIndexAction = (function (_super) {
    tslib_1.__extends(CategoryEntryIndexAction, _super);
    function CategoryEntryIndexAction(data) {
        var _this = _super.call(this, data, { responseType: 'n', responseSubType: '', responseConstructor: null }) || this;
        if (typeof _this.shouldUpdate === 'undefined')
            _this.shouldUpdate = true;
        return _this;
    }
    CategoryEntryIndexAction.prototype._getMetadata = function () {
        var result = _super.prototype._getMetadata.call(this);
        Object.assign(result.properties, {
            service: { type: 'c', default: 'categoryentry' },
            action: { type: 'c', default: 'index' },
            entryId: { type: 's' },
            categoryId: { type: 'n' },
            shouldUpdate: { type: 'b' }
        });
        return result;
    };
    return CategoryEntryIndexAction;
}(kaltura_request_1.KalturaRequest));
exports.CategoryEntryIndexAction = CategoryEntryIndexAction;

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInR5cGVzL0NhdGVnb3J5RW50cnlJbmRleEFjdGlvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUlBLHNEQUF3RTtBQVF4RTs7R0FFRztBQUNIO0lBQThDLG9EQUFzQjtJQU1oRSxrQ0FBWSxJQUFtQztRQUEvQyxZQUVJLGtCQUFNLElBQUksRUFBRSxFQUFDLFlBQVksRUFBRyxHQUFHLEVBQUUsZUFBZSxFQUFHLEVBQUUsRUFBRSxtQkFBbUIsRUFBRyxJQUFJLEVBQUUsQ0FBQyxTQUV2RjtRQURHLEVBQUUsQ0FBQyxDQUFDLE9BQU8sS0FBSSxDQUFDLFlBQVksS0FBSyxXQUFXLENBQUM7WUFBQyxLQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQzs7SUFDM0UsQ0FBQztJQUVTLCtDQUFZLEdBQXRCO1FBRUksSUFBTSxNQUFNLEdBQUcsaUJBQU0sWUFBWSxXQUFFLENBQUM7UUFDcEMsTUFBTSxDQUFDLE1BQU0sQ0FDVCxNQUFNLENBQUMsVUFBVSxFQUNqQjtZQUNJLE9BQU8sRUFBRyxFQUFFLElBQUksRUFBRyxHQUFHLEVBQUUsT0FBTyxFQUFHLGVBQWUsRUFBRTtZQUMvRCxNQUFNLEVBQUcsRUFBRSxJQUFJLEVBQUcsR0FBRyxFQUFFLE9BQU8sRUFBRyxPQUFPLEVBQUU7WUFDMUMsT0FBTyxFQUFHLEVBQUUsSUFBSSxFQUFHLEdBQUcsRUFBRTtZQUN4QixVQUFVLEVBQUcsRUFBRSxJQUFJLEVBQUcsR0FBRyxFQUFFO1lBQzNCLFlBQVksRUFBRyxFQUFFLElBQUksRUFBRyxHQUFHLEVBQUU7U0FDcEIsQ0FDSixDQUFDO1FBQ0YsTUFBTSxDQUFDLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBQ0wsK0JBQUM7QUFBRCxDQTNCQSxBQTJCQyxDQTNCNkMsZ0NBQWMsR0EyQjNEO0FBM0JZLDREQUF3QiIsImZpbGUiOiJ0eXBlcy9DYXRlZ29yeUVudHJ5SW5kZXhBY3Rpb24uanMiLCJzb3VyY2VzQ29udGVudCI6WyJcbmltcG9ydCB7IEthbHR1cmFPYmplY3RNZXRhZGF0YSB9IGZyb20gJy4uL2thbHR1cmEtb2JqZWN0LWJhc2UnO1xuXG5cbmltcG9ydCB7IEthbHR1cmFSZXF1ZXN0LCBLYWx0dXJhUmVxdWVzdEFyZ3MgfSBmcm9tICcuLi9rYWx0dXJhLXJlcXVlc3QnO1xuXG5leHBvcnQgaW50ZXJmYWNlIENhdGVnb3J5RW50cnlJbmRleEFjdGlvbkFyZ3MgIGV4dGVuZHMgS2FsdHVyYVJlcXVlc3RBcmdzIHtcbiAgICBlbnRyeUlkIDogc3RyaW5nO1xuXHRjYXRlZ29yeUlkIDogbnVtYmVyO1xuXHRzaG91bGRVcGRhdGU/IDogYm9vbGVhbjtcbn1cblxuLyoqIFxuKiBJbmRleCBDYXRlZ29yeUVudHJ5IGJ5IElkXG4qKi9cbmV4cG9ydCBjbGFzcyBDYXRlZ29yeUVudHJ5SW5kZXhBY3Rpb24gZXh0ZW5kcyBLYWx0dXJhUmVxdWVzdDxudW1iZXI+IHtcblxuICAgIGVudHJ5SWQgOiBzdHJpbmc7XG5cdGNhdGVnb3J5SWQgOiBudW1iZXI7XG5cdHNob3VsZFVwZGF0ZSA6IGJvb2xlYW47XG5cbiAgICBjb25zdHJ1Y3RvcihkYXRhIDogQ2F0ZWdvcnlFbnRyeUluZGV4QWN0aW9uQXJncylcbiAgICB7XG4gICAgICAgIHN1cGVyKGRhdGEsIHtyZXNwb25zZVR5cGUgOiAnbicsIHJlc3BvbnNlU3ViVHlwZSA6ICcnLCByZXNwb25zZUNvbnN0cnVjdG9yIDogbnVsbCB9KTtcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLnNob3VsZFVwZGF0ZSA9PT0gJ3VuZGVmaW5lZCcpIHRoaXMuc2hvdWxkVXBkYXRlID0gdHJ1ZTtcbiAgICB9XG5cbiAgICBwcm90ZWN0ZWQgX2dldE1ldGFkYXRhKCkgOiBLYWx0dXJhT2JqZWN0TWV0YWRhdGFcbiAgICB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHN1cGVyLl9nZXRNZXRhZGF0YSgpO1xuICAgICAgICBPYmplY3QuYXNzaWduKFxuICAgICAgICAgICAgcmVzdWx0LnByb3BlcnRpZXMsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgc2VydmljZSA6IHsgdHlwZSA6ICdjJywgZGVmYXVsdCA6ICdjYXRlZ29yeWVudHJ5JyB9LFxuXHRcdFx0XHRhY3Rpb24gOiB7IHR5cGUgOiAnYycsIGRlZmF1bHQgOiAnaW5kZXgnIH0sXG5cdFx0XHRcdGVudHJ5SWQgOiB7IHR5cGUgOiAncycgfSxcblx0XHRcdFx0Y2F0ZWdvcnlJZCA6IHsgdHlwZSA6ICduJyB9LFxuXHRcdFx0XHRzaG91bGRVcGRhdGUgOiB7IHR5cGUgOiAnYicgfVxuICAgICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbn1cblxuIl19
