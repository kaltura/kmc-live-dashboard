import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CategoryEntryRejectActionArgs extends KalturaRequestArgs {
    entryId: string;
    categoryId: number;
}
/**
* activate CategoryEntry when it is pending moderation
**/
export declare class CategoryEntryRejectAction extends KalturaRequest<void> {
    entryId: string;
    categoryId: number;
    constructor(data: CategoryEntryRejectActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
