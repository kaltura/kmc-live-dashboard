import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CategoryEntrySyncPrivacyContextActionArgs extends KalturaRequestArgs {
    entryId: string;
    categoryId: number;
}
/**
* update privacy context from the category
**/
export declare class CategoryEntrySyncPrivacyContextAction extends KalturaRequest<void> {
    entryId: string;
    categoryId: number;
    constructor(data: CategoryEntrySyncPrivacyContextActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
