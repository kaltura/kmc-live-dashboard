import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCategory } from './KalturaCategory';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CategoryGetActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Get Category by id
**/
export declare class CategoryGetAction extends KalturaRequest<KalturaCategory> {
    id: number;
    constructor(data: CategoryGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
