import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CategoryIndexActionArgs extends KalturaRequestArgs {
    id: number;
    shouldUpdate?: boolean;
}
/**
* Index Category by id
**/
export declare class CategoryIndexAction extends KalturaRequest<number> {
    id: number;
    shouldUpdate: boolean;
    constructor(data: CategoryIndexActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
