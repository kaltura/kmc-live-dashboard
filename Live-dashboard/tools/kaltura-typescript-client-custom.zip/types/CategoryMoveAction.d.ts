import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCategoryListResponse } from './KalturaCategoryListResponse';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CategoryMoveActionArgs extends KalturaRequestArgs {
    categoryIds: string;
    targetCategoryParentId: number;
}
/**
* Move categories that belong to the same parent category to a target categroy -
* enabled only for ks with disable entitlement
**/
export declare class CategoryMoveAction extends KalturaRequest<KalturaCategoryListResponse> {
    categoryIds: string;
    targetCategoryParentId: number;
    constructor(data: CategoryMoveActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
