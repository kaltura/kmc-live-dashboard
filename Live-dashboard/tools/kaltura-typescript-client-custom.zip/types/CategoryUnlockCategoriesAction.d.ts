import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CategoryUnlockCategoriesActionArgs extends KalturaRequestArgs {
}
/**
* Unlock categories
**/
export declare class CategoryUnlockCategoriesAction extends KalturaRequest<void> {
    constructor(data?: CategoryUnlockCategoriesActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
