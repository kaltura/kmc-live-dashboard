import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCategoryUser } from './KalturaCategoryUser';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CategoryUserActivateActionArgs extends KalturaRequestArgs {
    categoryId: number;
    userId: string;
}
/**
* activate CategoryUser
**/
export declare class CategoryUserActivateAction extends KalturaRequest<KalturaCategoryUser> {
    categoryId: number;
    userId: string;
    constructor(data: CategoryUserActivateActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
