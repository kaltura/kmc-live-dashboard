import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCategoryUser } from './KalturaCategoryUser';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CategoryUserAddActionArgs extends KalturaRequestArgs {
    categoryUser: KalturaCategoryUser;
}
/**
* Add new CategoryUser
**/
export declare class CategoryUserAddAction extends KalturaRequest<KalturaCategoryUser> {
    categoryUser: KalturaCategoryUser;
    constructor(data: CategoryUserAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
