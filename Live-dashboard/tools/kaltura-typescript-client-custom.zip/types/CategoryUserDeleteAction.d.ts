import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CategoryUserDeleteActionArgs extends KalturaRequestArgs {
    categoryId: number;
    userId: string;
}
/**
* Delete a CategoryUser
**/
export declare class CategoryUserDeleteAction extends KalturaRequest<void> {
    categoryId: number;
    userId: string;
    constructor(data: CategoryUserDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
