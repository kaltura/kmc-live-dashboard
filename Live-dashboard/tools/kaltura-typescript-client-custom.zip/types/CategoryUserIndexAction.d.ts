import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CategoryUserIndexActionArgs extends KalturaRequestArgs {
    userId: string;
    categoryId: number;
    shouldUpdate?: boolean;
}
/**
* Index CategoryUser by userid and category id
**/
export declare class CategoryUserIndexAction extends KalturaRequest<number> {
    userId: string;
    categoryId: number;
    shouldUpdate: boolean;
    constructor(data: CategoryUserIndexActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
