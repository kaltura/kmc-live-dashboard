import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCategoryUser } from './KalturaCategoryUser';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CategoryUserUpdateActionArgs extends KalturaRequestArgs {
    categoryId: number;
    userId: string;
    categoryUser: KalturaCategoryUser;
    override?: boolean;
}
/**
* Update CategoryUser by id
**/
export declare class CategoryUserUpdateAction extends KalturaRequest<KalturaCategoryUser> {
    categoryId: number;
    userId: string;
    categoryUser: KalturaCategoryUser;
    override: boolean;
    constructor(data: CategoryUserUpdateActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
