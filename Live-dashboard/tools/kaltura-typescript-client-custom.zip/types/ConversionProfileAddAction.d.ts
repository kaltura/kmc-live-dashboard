import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaConversionProfile } from './KalturaConversionProfile';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ConversionProfileAddActionArgs extends KalturaRequestArgs {
    conversionProfile: KalturaConversionProfile;
}
/**
* Add new Conversion Profile
**/
export declare class ConversionProfileAddAction extends KalturaRequest<KalturaConversionProfile> {
    conversionProfile: KalturaConversionProfile;
    constructor(data: ConversionProfileAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
