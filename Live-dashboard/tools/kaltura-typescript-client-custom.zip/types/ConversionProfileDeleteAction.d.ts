import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ConversionProfileDeleteActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Delete Conversion Profile by ID
**/
export declare class ConversionProfileDeleteAction extends KalturaRequest<void> {
    id: number;
    constructor(data: ConversionProfileDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
