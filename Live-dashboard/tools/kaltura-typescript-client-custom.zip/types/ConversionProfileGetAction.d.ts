import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaConversionProfile } from './KalturaConversionProfile';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ConversionProfileGetActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Get Conversion Profile by ID
**/
export declare class ConversionProfileGetAction extends KalturaRequest<KalturaConversionProfile> {
    id: number;
    constructor(data: ConversionProfileGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
