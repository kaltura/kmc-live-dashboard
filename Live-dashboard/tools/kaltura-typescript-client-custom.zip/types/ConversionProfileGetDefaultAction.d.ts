import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaConversionProfile } from './KalturaConversionProfile';
import { KalturaConversionProfileType } from './KalturaConversionProfileType';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ConversionProfileGetDefaultActionArgs extends KalturaRequestArgs {
    type?: KalturaConversionProfileType;
}
/**
* Get the partner's default conversion profile
**/
export declare class ConversionProfileGetDefaultAction extends KalturaRequest<KalturaConversionProfile> {
    type: KalturaConversionProfileType;
    constructor(data?: ConversionProfileGetDefaultActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
