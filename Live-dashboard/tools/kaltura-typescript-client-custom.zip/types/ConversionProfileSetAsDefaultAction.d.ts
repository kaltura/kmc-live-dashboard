import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaConversionProfile } from './KalturaConversionProfile';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ConversionProfileSetAsDefaultActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Set Conversion Profile to be the partner default
**/
export declare class ConversionProfileSetAsDefaultAction extends KalturaRequest<KalturaConversionProfile> {
    id: number;
    constructor(data: ConversionProfileSetAsDefaultActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
