import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCuePoint } from './KalturaCuePoint';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CuePointAddActionArgs extends KalturaRequestArgs {
    cuePoint: KalturaCuePoint;
}
/**
* Allows you to add an cue point object associated with an entry
**/
export declare class CuePointAddAction extends KalturaRequest<KalturaCuePoint> {
    cuePoint: KalturaCuePoint;
    constructor(data: CuePointAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
