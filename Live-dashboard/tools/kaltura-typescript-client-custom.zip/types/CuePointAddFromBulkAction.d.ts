import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCuePointListResponse } from './KalturaCuePointListResponse';
import { KalturaUploadRequest, KalturaUploadRequestArgs } from '../kaltura-upload-request';
export interface CuePointAddFromBulkActionArgs extends KalturaUploadRequestArgs {
    fileData: File;
}
/**
* Allows you to add multiple cue points objects by uploading XML that contains
* multiple cue point definitions
**/
export declare class CuePointAddFromBulkAction extends KalturaUploadRequest<KalturaCuePointListResponse> {
    fileData: File;
    constructor(data: CuePointAddFromBulkActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
