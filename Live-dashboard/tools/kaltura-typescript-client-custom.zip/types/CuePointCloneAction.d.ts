import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCuePoint } from './KalturaCuePoint';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CuePointCloneActionArgs extends KalturaRequestArgs {
    id: string;
    entryId: string;
}
/**
* Clone cuePoint with id to given entry
**/
export declare class CuePointCloneAction extends KalturaRequest<KalturaCuePoint> {
    id: string;
    entryId: string;
    constructor(data: CuePointCloneActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
