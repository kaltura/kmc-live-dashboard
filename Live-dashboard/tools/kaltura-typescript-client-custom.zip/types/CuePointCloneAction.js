"use strict";
var tslib_1 = require("tslib");
var KalturaCuePoint_1 = require("./KalturaCuePoint");
var kaltura_request_1 = require("../kaltura-request");
/**
* Clone cuePoint with id to given entry
**/
var CuePointCloneAction = (function (_super) {
    tslib_1.__extends(CuePointCloneAction, _super);
    function CuePointCloneAction(data) {
        return _super.call(this, data, { responseType: 'o', responseSubType: 'KalturaCuePoint', responseConstructor: KalturaCuePoint_1.KalturaCuePoint }) || this;
    }
    CuePointCloneAction.prototype._getMetadata = function () {
        var result = _super.prototype._getMetadata.call(this);
        Object.assign(result.properties, {
            service: { type: 'c', default: 'cuepoint_cuepoint' },
            action: { type: 'c', default: 'clone' },
            id: { type: 's' },
            entryId: { type: 's' }
        });
        return result;
    };
    return CuePointCloneAction;
}(kaltura_request_1.KalturaRequest));
exports.CuePointCloneAction = CuePointCloneAction;

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInR5cGVzL0N1ZVBvaW50Q2xvbmVBY3Rpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFFQSxxREFBb0Q7QUFFcEQsc0RBQXdFO0FBT3hFOztHQUVHO0FBQ0g7SUFBeUMsK0NBQStCO0lBS3BFLDZCQUFZLElBQThCO2VBRXRDLGtCQUFNLElBQUksRUFBRSxFQUFDLFlBQVksRUFBRyxHQUFHLEVBQUUsZUFBZSxFQUFHLGlCQUFpQixFQUFFLG1CQUFtQixFQUFHLGlDQUFlLEVBQUcsQ0FBQztJQUNuSCxDQUFDO0lBRVMsMENBQVksR0FBdEI7UUFFSSxJQUFNLE1BQU0sR0FBRyxpQkFBTSxZQUFZLFdBQUUsQ0FBQztRQUNwQyxNQUFNLENBQUMsTUFBTSxDQUNULE1BQU0sQ0FBQyxVQUFVLEVBQ2pCO1lBQ0ksT0FBTyxFQUFHLEVBQUUsSUFBSSxFQUFHLEdBQUcsRUFBRSxPQUFPLEVBQUcsbUJBQW1CLEVBQUU7WUFDbkUsTUFBTSxFQUFHLEVBQUUsSUFBSSxFQUFHLEdBQUcsRUFBRSxPQUFPLEVBQUcsT0FBTyxFQUFFO1lBQzFDLEVBQUUsRUFBRyxFQUFFLElBQUksRUFBRyxHQUFHLEVBQUU7WUFDbkIsT0FBTyxFQUFHLEVBQUUsSUFBSSxFQUFHLEdBQUcsRUFBRTtTQUNmLENBQ0osQ0FBQztRQUNGLE1BQU0sQ0FBQyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUNMLDBCQUFDO0FBQUQsQ0F4QkEsQUF3QkMsQ0F4QndDLGdDQUFjLEdBd0J0RDtBQXhCWSxrREFBbUIiLCJmaWxlIjoidHlwZXMvQ3VlUG9pbnRDbG9uZUFjdGlvbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxuaW1wb3J0IHsgS2FsdHVyYU9iamVjdE1ldGFkYXRhIH0gZnJvbSAnLi4va2FsdHVyYS1vYmplY3QtYmFzZSc7XG5pbXBvcnQgeyBLYWx0dXJhQ3VlUG9pbnQgfSBmcm9tICcuL0thbHR1cmFDdWVQb2ludCc7XG5cbmltcG9ydCB7IEthbHR1cmFSZXF1ZXN0LCBLYWx0dXJhUmVxdWVzdEFyZ3MgfSBmcm9tICcuLi9rYWx0dXJhLXJlcXVlc3QnO1xuXG5leHBvcnQgaW50ZXJmYWNlIEN1ZVBvaW50Q2xvbmVBY3Rpb25BcmdzICBleHRlbmRzIEthbHR1cmFSZXF1ZXN0QXJncyB7XG4gICAgaWQgOiBzdHJpbmc7XG5cdGVudHJ5SWQgOiBzdHJpbmc7XG59XG5cbi8qKiBcbiogQ2xvbmUgY3VlUG9pbnQgd2l0aCBpZCB0byBnaXZlbiBlbnRyeVxuKiovXG5leHBvcnQgY2xhc3MgQ3VlUG9pbnRDbG9uZUFjdGlvbiBleHRlbmRzIEthbHR1cmFSZXF1ZXN0PEthbHR1cmFDdWVQb2ludD4ge1xuXG4gICAgaWQgOiBzdHJpbmc7XG5cdGVudHJ5SWQgOiBzdHJpbmc7XG5cbiAgICBjb25zdHJ1Y3RvcihkYXRhIDogQ3VlUG9pbnRDbG9uZUFjdGlvbkFyZ3MpXG4gICAge1xuICAgICAgICBzdXBlcihkYXRhLCB7cmVzcG9uc2VUeXBlIDogJ28nLCByZXNwb25zZVN1YlR5cGUgOiAnS2FsdHVyYUN1ZVBvaW50JywgcmVzcG9uc2VDb25zdHJ1Y3RvciA6IEthbHR1cmFDdWVQb2ludCAgfSk7XG4gICAgfVxuXG4gICAgcHJvdGVjdGVkIF9nZXRNZXRhZGF0YSgpIDogS2FsdHVyYU9iamVjdE1ldGFkYXRhXG4gICAge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBzdXBlci5fZ2V0TWV0YWRhdGEoKTtcbiAgICAgICAgT2JqZWN0LmFzc2lnbihcbiAgICAgICAgICAgIHJlc3VsdC5wcm9wZXJ0aWVzLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHNlcnZpY2UgOiB7IHR5cGUgOiAnYycsIGRlZmF1bHQgOiAnY3VlcG9pbnRfY3VlcG9pbnQnIH0sXG5cdFx0XHRcdGFjdGlvbiA6IHsgdHlwZSA6ICdjJywgZGVmYXVsdCA6ICdjbG9uZScgfSxcblx0XHRcdFx0aWQgOiB7IHR5cGUgOiAncycgfSxcblx0XHRcdFx0ZW50cnlJZCA6IHsgdHlwZSA6ICdzJyB9XG4gICAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxufVxuXG4iXX0=
