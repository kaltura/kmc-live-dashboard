import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCuePointFilter } from './KalturaCuePointFilter';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CuePointCountActionArgs extends KalturaRequestArgs {
    filter?: KalturaCuePointFilter;
}
/**
* count cue point objects by filter
**/
export declare class CuePointCountAction extends KalturaRequest<number> {
    filter: KalturaCuePointFilter;
    constructor(data?: CuePointCountActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
