import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CuePointDeleteActionArgs extends KalturaRequestArgs {
    id: string;
}
/**
* delete cue point by id, and delete all children cue points
**/
export declare class CuePointDeleteAction extends KalturaRequest<void> {
    id: string;
    constructor(data: CuePointDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
