import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCuePoint } from './KalturaCuePoint';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CuePointGetActionArgs extends KalturaRequestArgs {
    id: string;
}
/**
* Retrieve an CuePoint object by id
**/
export declare class CuePointGetAction extends KalturaRequest<KalturaCuePoint> {
    id: string;
    constructor(data: CuePointGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
