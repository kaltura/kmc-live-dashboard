import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCuePointFilter } from './KalturaCuePointFilter';
import { KalturaFilterPager } from './KalturaFilterPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CuePointServeBulkActionArgs extends KalturaRequestArgs {
    filter?: KalturaCuePointFilter;
    pager?: KalturaFilterPager;
}
/**
* Download multiple cue points objects as XML definitions
**/
export declare class CuePointServeBulkAction extends KalturaRequest<string> {
    filter: KalturaCuePointFilter;
    pager: KalturaFilterPager;
    constructor(data?: CuePointServeBulkActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
