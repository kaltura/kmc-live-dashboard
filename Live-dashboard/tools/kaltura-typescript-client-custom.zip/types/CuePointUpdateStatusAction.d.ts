import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaCuePointStatus } from './KalturaCuePointStatus';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface CuePointUpdateStatusActionArgs extends KalturaRequestArgs {
    id: string;
    status: KalturaCuePointStatus;
}
/**
* Update cuePoint status by id
**/
export declare class CuePointUpdateStatusAction extends KalturaRequest<void> {
    id: string;
    status: KalturaCuePointStatus;
    constructor(data: CuePointUpdateStatusActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
