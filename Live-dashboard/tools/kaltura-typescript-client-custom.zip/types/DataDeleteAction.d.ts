import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DataDeleteActionArgs extends KalturaRequestArgs {
    entryId: string;
}
/**
* Delete a data entry.
**/
export declare class DataDeleteAction extends KalturaRequest<void> {
    entryId: string;
    constructor(data: DataDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
