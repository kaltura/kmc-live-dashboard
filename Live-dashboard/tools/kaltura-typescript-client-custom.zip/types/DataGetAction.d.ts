import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDataEntry } from './KalturaDataEntry';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DataGetActionArgs extends KalturaRequestArgs {
    entryId: string;
    version?: number;
}
/**
* Get data entry by ID.
**/
export declare class DataGetAction extends KalturaRequest<KalturaDataEntry> {
    entryId: string;
    version: number;
    constructor(data: DataGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
