import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDataListResponse } from './KalturaDataListResponse';
import { KalturaDataEntryFilter } from './KalturaDataEntryFilter';
import { KalturaFilterPager } from './KalturaFilterPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DataListActionArgs extends KalturaRequestArgs {
    filter?: KalturaDataEntryFilter;
    pager?: KalturaFilterPager;
}
/**
* List data entries by filter with paging support.
**/
export declare class DataListAction extends KalturaRequest<KalturaDataListResponse> {
    filter: KalturaDataEntryFilter;
    pager: KalturaFilterPager;
    constructor(data?: DataListActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
