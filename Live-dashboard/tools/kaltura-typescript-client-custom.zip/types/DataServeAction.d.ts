import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DataServeActionArgs extends KalturaRequestArgs {
    entryId: string;
    version?: number;
    forceProxy?: boolean;
}
/**
* serve action returan the file from dataContent field.
**/
export declare class DataServeAction extends KalturaRequest<string> {
    entryId: string;
    version: number;
    forceProxy: boolean;
    constructor(data: DataServeActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
