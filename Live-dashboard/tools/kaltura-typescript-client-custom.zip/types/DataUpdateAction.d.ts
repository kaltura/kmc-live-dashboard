import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDataEntry } from './KalturaDataEntry';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DataUpdateActionArgs extends KalturaRequestArgs {
    entryId: string;
    documentEntry: KalturaDataEntry;
}
/**
* Update data entry. Only the properties that were set will be updated.
**/
export declare class DataUpdateAction extends KalturaRequest<KalturaDataEntry> {
    entryId: string;
    documentEntry: KalturaDataEntry;
    constructor(data: DataUpdateActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
