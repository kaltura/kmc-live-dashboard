import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDeliveryProfile } from './KalturaDeliveryProfile';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DeliveryProfileAddActionArgs extends KalturaRequestArgs {
    delivery: KalturaDeliveryProfile;
}
/**
* Add new delivery.
**/
export declare class DeliveryProfileAddAction extends KalturaRequest<KalturaDeliveryProfile> {
    delivery: KalturaDeliveryProfile;
    constructor(data: DeliveryProfileAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
