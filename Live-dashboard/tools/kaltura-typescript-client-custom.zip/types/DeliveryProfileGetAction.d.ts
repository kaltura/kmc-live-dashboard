import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDeliveryProfile } from './KalturaDeliveryProfile';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DeliveryProfileGetActionArgs extends KalturaRequestArgs {
    id: string;
}
/**
* Get delivery by id
**/
export declare class DeliveryProfileGetAction extends KalturaRequest<KalturaDeliveryProfile> {
    id: string;
    constructor(data: DeliveryProfileGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
