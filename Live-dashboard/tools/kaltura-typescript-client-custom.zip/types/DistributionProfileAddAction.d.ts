import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDistributionProfile } from './KalturaDistributionProfile';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DistributionProfileAddActionArgs extends KalturaRequestArgs {
    distributionProfile: KalturaDistributionProfile;
}
/**
* Add new Distribution Profile
**/
export declare class DistributionProfileAddAction extends KalturaRequest<KalturaDistributionProfile> {
    distributionProfile: KalturaDistributionProfile;
    constructor(data: DistributionProfileAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
