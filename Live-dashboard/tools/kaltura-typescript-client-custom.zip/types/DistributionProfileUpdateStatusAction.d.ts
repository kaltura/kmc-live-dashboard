import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDistributionProfile } from './KalturaDistributionProfile';
import { KalturaDistributionProfileStatus } from './KalturaDistributionProfileStatus';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DistributionProfileUpdateStatusActionArgs extends KalturaRequestArgs {
    id: number;
    status: KalturaDistributionProfileStatus;
}
/**
* Update Distribution Profile status by id
**/
export declare class DistributionProfileUpdateStatusAction extends KalturaRequest<KalturaDistributionProfile> {
    id: number;
    status: KalturaDistributionProfileStatus;
    constructor(data: DistributionProfileUpdateStatusActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
