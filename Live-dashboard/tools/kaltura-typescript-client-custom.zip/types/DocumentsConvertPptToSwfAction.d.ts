import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DocumentsConvertPptToSwfActionArgs extends KalturaRequestArgs {
    entryId: string;
}
/**
* This will queue a batch job for converting the document file to swf   Returns
* the URL where the new swf will be available
**/
export declare class DocumentsConvertPptToSwfAction extends KalturaRequest<string> {
    entryId: string;
    constructor(data: DocumentsConvertPptToSwfActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
