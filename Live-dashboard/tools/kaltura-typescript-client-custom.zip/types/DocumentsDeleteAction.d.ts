import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DocumentsDeleteActionArgs extends KalturaRequestArgs {
    entryId: string;
}
/**
* Delete a document entry.
**/
export declare class DocumentsDeleteAction extends KalturaRequest<void> {
    entryId: string;
    constructor(data: DocumentsDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
