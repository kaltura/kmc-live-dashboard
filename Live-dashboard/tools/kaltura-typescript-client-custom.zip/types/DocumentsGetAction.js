"use strict";
var tslib_1 = require("tslib");
var KalturaDocumentEntry_1 = require("./KalturaDocumentEntry");
var kaltura_request_1 = require("../kaltura-request");
/**
* Get document entry by ID.
**/
var DocumentsGetAction = (function (_super) {
    tslib_1.__extends(DocumentsGetAction, _super);
    function DocumentsGetAction(data) {
        var _this = _super.call(this, data, { responseType: 'o', responseSubType: 'KalturaDocumentEntry', responseConstructor: KalturaDocumentEntry_1.KalturaDocumentEntry }) || this;
        if (typeof _this.version === 'undefined')
            _this.version = -1;
        return _this;
    }
    DocumentsGetAction.prototype._getMetadata = function () {
        var result = _super.prototype._getMetadata.call(this);
        Object.assign(result.properties, {
            service: { type: 'c', default: 'document_documents' },
            action: { type: 'c', default: 'get' },
            entryId: { type: 's' },
            version: { type: 'n' }
        });
        return result;
    };
    return DocumentsGetAction;
}(kaltura_request_1.KalturaRequest));
exports.DocumentsGetAction = DocumentsGetAction;

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInR5cGVzL0RvY3VtZW50c0dldEFjdGlvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUVBLCtEQUE4RDtBQUU5RCxzREFBd0U7QUFPeEU7O0dBRUc7QUFDSDtJQUF3Qyw4Q0FBb0M7SUFLeEUsNEJBQVksSUFBNkI7UUFBekMsWUFFSSxrQkFBTSxJQUFJLEVBQUUsRUFBQyxZQUFZLEVBQUcsR0FBRyxFQUFFLGVBQWUsRUFBRyxzQkFBc0IsRUFBRSxtQkFBbUIsRUFBRywyQ0FBb0IsRUFBRyxDQUFDLFNBRTVIO1FBREcsRUFBRSxDQUFDLENBQUMsT0FBTyxLQUFJLENBQUMsT0FBTyxLQUFLLFdBQVcsQ0FBQztZQUFDLEtBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUM7O0lBQy9ELENBQUM7SUFFUyx5Q0FBWSxHQUF0QjtRQUVJLElBQU0sTUFBTSxHQUFHLGlCQUFNLFlBQVksV0FBRSxDQUFDO1FBQ3BDLE1BQU0sQ0FBQyxNQUFNLENBQ1QsTUFBTSxDQUFDLFVBQVUsRUFDakI7WUFDSSxPQUFPLEVBQUcsRUFBRSxJQUFJLEVBQUcsR0FBRyxFQUFFLE9BQU8sRUFBRyxvQkFBb0IsRUFBRTtZQUNwRSxNQUFNLEVBQUcsRUFBRSxJQUFJLEVBQUcsR0FBRyxFQUFFLE9BQU8sRUFBRyxLQUFLLEVBQUU7WUFDeEMsT0FBTyxFQUFHLEVBQUUsSUFBSSxFQUFHLEdBQUcsRUFBRTtZQUN4QixPQUFPLEVBQUcsRUFBRSxJQUFJLEVBQUcsR0FBRyxFQUFFO1NBQ2YsQ0FDSixDQUFDO1FBQ0YsTUFBTSxDQUFDLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBQ0wseUJBQUM7QUFBRCxDQXpCQSxBQXlCQyxDQXpCdUMsZ0NBQWMsR0F5QnJEO0FBekJZLGdEQUFrQiIsImZpbGUiOiJ0eXBlcy9Eb2N1bWVudHNHZXRBY3Rpb24uanMiLCJzb3VyY2VzQ29udGVudCI6WyJcbmltcG9ydCB7IEthbHR1cmFPYmplY3RNZXRhZGF0YSB9IGZyb20gJy4uL2thbHR1cmEtb2JqZWN0LWJhc2UnO1xuaW1wb3J0IHsgS2FsdHVyYURvY3VtZW50RW50cnkgfSBmcm9tICcuL0thbHR1cmFEb2N1bWVudEVudHJ5JztcblxuaW1wb3J0IHsgS2FsdHVyYVJlcXVlc3QsIEthbHR1cmFSZXF1ZXN0QXJncyB9IGZyb20gJy4uL2thbHR1cmEtcmVxdWVzdCc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgRG9jdW1lbnRzR2V0QWN0aW9uQXJncyAgZXh0ZW5kcyBLYWx0dXJhUmVxdWVzdEFyZ3Mge1xuICAgIGVudHJ5SWQgOiBzdHJpbmc7XG5cdHZlcnNpb24/IDogbnVtYmVyO1xufVxuXG4vKiogXG4qIEdldCBkb2N1bWVudCBlbnRyeSBieSBJRC5cbioqL1xuZXhwb3J0IGNsYXNzIERvY3VtZW50c0dldEFjdGlvbiBleHRlbmRzIEthbHR1cmFSZXF1ZXN0PEthbHR1cmFEb2N1bWVudEVudHJ5PiB7XG5cbiAgICBlbnRyeUlkIDogc3RyaW5nO1xuXHR2ZXJzaW9uIDogbnVtYmVyO1xuXG4gICAgY29uc3RydWN0b3IoZGF0YSA6IERvY3VtZW50c0dldEFjdGlvbkFyZ3MpXG4gICAge1xuICAgICAgICBzdXBlcihkYXRhLCB7cmVzcG9uc2VUeXBlIDogJ28nLCByZXNwb25zZVN1YlR5cGUgOiAnS2FsdHVyYURvY3VtZW50RW50cnknLCByZXNwb25zZUNvbnN0cnVjdG9yIDogS2FsdHVyYURvY3VtZW50RW50cnkgIH0pO1xuICAgICAgICBpZiAodHlwZW9mIHRoaXMudmVyc2lvbiA9PT0gJ3VuZGVmaW5lZCcpIHRoaXMudmVyc2lvbiA9IC0xO1xuICAgIH1cblxuICAgIHByb3RlY3RlZCBfZ2V0TWV0YWRhdGEoKSA6IEthbHR1cmFPYmplY3RNZXRhZGF0YVxuICAgIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gc3VwZXIuX2dldE1ldGFkYXRhKCk7XG4gICAgICAgIE9iamVjdC5hc3NpZ24oXG4gICAgICAgICAgICByZXN1bHQucHJvcGVydGllcyxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBzZXJ2aWNlIDogeyB0eXBlIDogJ2MnLCBkZWZhdWx0IDogJ2RvY3VtZW50X2RvY3VtZW50cycgfSxcblx0XHRcdFx0YWN0aW9uIDogeyB0eXBlIDogJ2MnLCBkZWZhdWx0IDogJ2dldCcgfSxcblx0XHRcdFx0ZW50cnlJZCA6IHsgdHlwZSA6ICdzJyB9LFxuXHRcdFx0XHR2ZXJzaW9uIDogeyB0eXBlIDogJ24nIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG59XG5cbiJdfQ==
