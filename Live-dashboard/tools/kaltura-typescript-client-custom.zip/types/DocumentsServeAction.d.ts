import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DocumentsServeActionArgs extends KalturaRequestArgs {
    entryId: string;
    flavorAssetId?: string;
    forceProxy?: boolean;
}
/**
* Serves the file content
**/
export declare class DocumentsServeAction extends KalturaRequest<string> {
    entryId: string;
    flavorAssetId: string;
    forceProxy: boolean;
    constructor(data: DocumentsServeActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
