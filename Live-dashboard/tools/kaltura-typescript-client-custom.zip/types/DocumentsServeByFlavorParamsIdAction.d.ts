import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DocumentsServeByFlavorParamsIdActionArgs extends KalturaRequestArgs {
    entryId: string;
    flavorParamsId?: string;
    forceProxy?: boolean;
}
/**
* Serves the file content
**/
export declare class DocumentsServeByFlavorParamsIdAction extends KalturaRequest<string> {
    entryId: string;
    flavorParamsId: string;
    forceProxy: boolean;
    constructor(data: DocumentsServeByFlavorParamsIdActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
