import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDocumentEntry } from './KalturaDocumentEntry';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DocumentsUpdateActionArgs extends KalturaRequestArgs {
    entryId: string;
    documentEntry: KalturaDocumentEntry;
}
/**
* Update document entry. Only the properties that were set will be updated.
**/
export declare class DocumentsUpdateAction extends KalturaRequest<KalturaDocumentEntry> {
    entryId: string;
    documentEntry: KalturaDocumentEntry;
    constructor(data: DocumentsUpdateActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
