import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDocumentEntry } from './KalturaDocumentEntry';
import { KalturaResource } from './KalturaResource';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DocumentsUpdateContentActionArgs extends KalturaRequestArgs {
    entryId: string;
    resource: KalturaResource;
    conversionProfileId?: number;
}
/**
* Replace content associated with the given document entry.
**/
export declare class DocumentsUpdateContentAction extends KalturaRequest<KalturaDocumentEntry> {
    entryId: string;
    resource: KalturaResource;
    conversionProfileId: number;
    constructor(data: DocumentsUpdateContentActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
