import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDropFolder } from './KalturaDropFolder';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DropFolderAddActionArgs extends KalturaRequestArgs {
    dropFolder: KalturaDropFolder;
}
/**
* Allows you to add a new KalturaDropFolder object
**/
export declare class DropFolderAddAction extends KalturaRequest<KalturaDropFolder> {
    dropFolder: KalturaDropFolder;
    constructor(data: DropFolderAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
