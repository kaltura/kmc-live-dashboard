import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDropFolder } from './KalturaDropFolder';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DropFolderDeleteActionArgs extends KalturaRequestArgs {
    dropFolderId: number;
}
/**
* Mark the KalturaDropFolder object as deleted
**/
export declare class DropFolderDeleteAction extends KalturaRequest<KalturaDropFolder> {
    dropFolderId: number;
    constructor(data: DropFolderDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
