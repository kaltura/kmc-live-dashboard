import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDropFolderFile } from './KalturaDropFolderFile';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DropFolderFileAddActionArgs extends KalturaRequestArgs {
    dropFolderFile: KalturaDropFolderFile;
}
/**
* Allows you to add a new KalturaDropFolderFile object
**/
export declare class DropFolderFileAddAction extends KalturaRequest<KalturaDropFolderFile> {
    dropFolderFile: KalturaDropFolderFile;
    constructor(data: DropFolderFileAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
