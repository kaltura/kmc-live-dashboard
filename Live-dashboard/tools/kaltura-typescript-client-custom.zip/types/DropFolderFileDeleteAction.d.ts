import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDropFolderFile } from './KalturaDropFolderFile';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DropFolderFileDeleteActionArgs extends KalturaRequestArgs {
    dropFolderFileId: number;
}
/**
* Mark the KalturaDropFolderFile object as deleted
**/
export declare class DropFolderFileDeleteAction extends KalturaRequest<KalturaDropFolderFile> {
    dropFolderFileId: number;
    constructor(data: DropFolderFileDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
