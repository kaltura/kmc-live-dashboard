import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDropFolderFile } from './KalturaDropFolderFile';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DropFolderFileGetActionArgs extends KalturaRequestArgs {
    dropFolderFileId: number;
}
/**
* Retrieve a KalturaDropFolderFile object by ID
**/
export declare class DropFolderFileGetAction extends KalturaRequest<KalturaDropFolderFile> {
    dropFolderFileId: number;
    constructor(data: DropFolderFileGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
