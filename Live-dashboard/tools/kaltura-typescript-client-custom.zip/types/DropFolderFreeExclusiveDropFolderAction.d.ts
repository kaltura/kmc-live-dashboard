import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDropFolder } from './KalturaDropFolder';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DropFolderFreeExclusiveDropFolderActionArgs extends KalturaRequestArgs {
    dropFolderId: number;
    status: number;
    errorCode?: string;
    errorDescription?: string;
}
/**
* freeExclusive KalturaDropFolder object
**/
export declare class DropFolderFreeExclusiveDropFolderAction extends KalturaRequest<KalturaDropFolder> {
    dropFolderId: number;
    status: number;
    errorCode: string;
    errorDescription: string;
    constructor(data: DropFolderFreeExclusiveDropFolderActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
