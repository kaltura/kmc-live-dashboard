import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDropFolder } from './KalturaDropFolder';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DropFolderGetActionArgs extends KalturaRequestArgs {
    dropFolderId: number;
}
/**
* Retrieve a KalturaDropFolder object by ID
**/
export declare class DropFolderGetAction extends KalturaRequest<KalturaDropFolder> {
    dropFolderId: number;
    constructor(data: DropFolderGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
