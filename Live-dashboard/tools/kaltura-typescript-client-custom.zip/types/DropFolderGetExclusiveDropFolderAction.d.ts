import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDropFolder } from './KalturaDropFolder';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DropFolderGetExclusiveDropFolderActionArgs extends KalturaRequestArgs {
    tag: string;
    maxTime: number;
}
/**
* getExclusive KalturaDropFolder object
**/
export declare class DropFolderGetExclusiveDropFolderAction extends KalturaRequest<KalturaDropFolder> {
    tag: string;
    maxTime: number;
    constructor(data: DropFolderGetExclusiveDropFolderActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
