import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDropFolderListResponse } from './KalturaDropFolderListResponse';
import { KalturaDropFolderFilter } from './KalturaDropFolderFilter';
import { KalturaFilterPager } from './KalturaFilterPager';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface DropFolderListActionArgs extends KalturaRequestArgs {
    filter?: KalturaDropFolderFilter;
    pager?: KalturaFilterPager;
}
/**
* List KalturaDropFolder objects
**/
export declare class DropFolderListAction extends KalturaRequest<KalturaDropFolderListResponse> {
    filter: KalturaDropFolderFilter;
    pager: KalturaFilterPager;
    constructor(data?: DropFolderListActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
