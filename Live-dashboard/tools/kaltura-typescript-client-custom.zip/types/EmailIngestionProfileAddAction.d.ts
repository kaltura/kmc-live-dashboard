import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEmailIngestionProfile } from './KalturaEmailIngestionProfile';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EmailIngestionProfileAddActionArgs extends KalturaRequestArgs {
    EmailIP: KalturaEmailIngestionProfile;
}
/**
* EmailIngestionProfile Add action allows you to add a EmailIngestionProfile to
* Kaltura DB
**/
export declare class EmailIngestionProfileAddAction extends KalturaRequest<KalturaEmailIngestionProfile> {
    EmailIP: KalturaEmailIngestionProfile;
    constructor(data: EmailIngestionProfileAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
