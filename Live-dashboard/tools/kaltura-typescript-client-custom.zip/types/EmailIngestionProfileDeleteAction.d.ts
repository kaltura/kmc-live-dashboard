import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EmailIngestionProfileDeleteActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Delete an existing EmailIngestionProfile
**/
export declare class EmailIngestionProfileDeleteAction extends KalturaRequest<void> {
    id: number;
    constructor(data: EmailIngestionProfileDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
