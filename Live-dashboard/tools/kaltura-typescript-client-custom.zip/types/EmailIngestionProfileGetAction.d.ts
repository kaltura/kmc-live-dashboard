import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEmailIngestionProfile } from './KalturaEmailIngestionProfile';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EmailIngestionProfileGetActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Retrieve a EmailIngestionProfile by id
**/
export declare class EmailIngestionProfileGetAction extends KalturaRequest<KalturaEmailIngestionProfile> {
    id: number;
    constructor(data: EmailIngestionProfileGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
