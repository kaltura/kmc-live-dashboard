import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEmailIngestionProfile } from './KalturaEmailIngestionProfile';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EmailIngestionProfileGetByEmailAddressActionArgs extends KalturaRequestArgs {
    emailAddress: string;
}
/**
* Retrieve a EmailIngestionProfile by email address
**/
export declare class EmailIngestionProfileGetByEmailAddressAction extends KalturaRequest<KalturaEmailIngestionProfile> {
    emailAddress: string;
    constructor(data: EmailIngestionProfileGetByEmailAddressActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
