import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEmailIngestionProfile } from './KalturaEmailIngestionProfile';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EmailIngestionProfileUpdateActionArgs extends KalturaRequestArgs {
    id: number;
    EmailIP: KalturaEmailIngestionProfile;
}
/**
* Update an existing EmailIngestionProfile
**/
export declare class EmailIngestionProfileUpdateAction extends KalturaRequest<KalturaEmailIngestionProfile> {
    id: number;
    EmailIP: KalturaEmailIngestionProfile;
    constructor(data: EmailIngestionProfileUpdateActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
