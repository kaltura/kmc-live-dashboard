import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryDistribution } from './KalturaEntryDistribution';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryDistributionAddActionArgs extends KalturaRequestArgs {
    entryDistribution: KalturaEntryDistribution;
}
/**
* Add new Entry Distribution
**/
export declare class EntryDistributionAddAction extends KalturaRequest<KalturaEntryDistribution> {
    entryDistribution: KalturaEntryDistribution;
    constructor(data: EntryDistributionAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
