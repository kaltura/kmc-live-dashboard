import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryDistributionDeleteActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Delete Entry Distribution by id
**/
export declare class EntryDistributionDeleteAction extends KalturaRequest<void> {
    id: number;
    constructor(data: EntryDistributionDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
