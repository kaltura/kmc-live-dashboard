import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryDistribution } from './KalturaEntryDistribution';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryDistributionGetActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Get Entry Distribution by id
**/
export declare class EntryDistributionGetAction extends KalturaRequest<KalturaEntryDistribution> {
    id: number;
    constructor(data: EntryDistributionGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
