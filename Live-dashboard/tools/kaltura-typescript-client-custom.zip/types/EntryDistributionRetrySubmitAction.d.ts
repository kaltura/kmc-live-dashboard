import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryDistribution } from './KalturaEntryDistribution';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryDistributionRetrySubmitActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Retries last submit action
**/
export declare class EntryDistributionRetrySubmitAction extends KalturaRequest<KalturaEntryDistribution> {
    id: number;
    constructor(data: EntryDistributionRetrySubmitActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
