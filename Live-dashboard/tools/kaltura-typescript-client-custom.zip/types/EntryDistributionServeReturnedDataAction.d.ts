import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaDistributionAction } from './KalturaDistributionAction';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryDistributionServeReturnedDataActionArgs extends KalturaRequestArgs {
    id: number;
    actionType: KalturaDistributionAction;
}
/**
* Serves entry distribution returned data
**/
export declare class EntryDistributionServeReturnedDataAction extends KalturaRequest<string> {
    id: number;
    actionType: KalturaDistributionAction;
    constructor(data: EntryDistributionServeReturnedDataActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
