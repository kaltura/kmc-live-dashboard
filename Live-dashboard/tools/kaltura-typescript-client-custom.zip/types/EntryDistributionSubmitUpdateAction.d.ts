import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryDistribution } from './KalturaEntryDistribution';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryDistributionSubmitUpdateActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Submits Entry Distribution changes to the remote destination
**/
export declare class EntryDistributionSubmitUpdateAction extends KalturaRequest<KalturaEntryDistribution> {
    id: number;
    constructor(data: EntryDistributionSubmitUpdateActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
