import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEntryDistribution } from './KalturaEntryDistribution';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryDistributionValidateActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Validates Entry Distribution by id for submission
**/
export declare class EntryDistributionValidateAction extends KalturaRequest<KalturaEntryDistribution> {
    id: number;
    constructor(data: EntryDistributionValidateActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
