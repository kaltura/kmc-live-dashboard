import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EntryServerNodeValidateRegisteredEntryServerNodeActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Validates server node still registered on entry
**/
export declare class EntryServerNodeValidateRegisteredEntryServerNodeAction extends KalturaRequest<void> {
    id: number;
    constructor(data: EntryServerNodeValidateRegisteredEntryServerNodeActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
