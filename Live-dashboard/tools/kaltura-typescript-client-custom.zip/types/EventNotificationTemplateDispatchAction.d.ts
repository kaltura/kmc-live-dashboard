import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEventNotificationScope } from './KalturaEventNotificationScope';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EventNotificationTemplateDispatchActionArgs extends KalturaRequestArgs {
    id: number;
    scope: KalturaEventNotificationScope;
}
/**
* Dispatch event notification object by id
**/
export declare class EventNotificationTemplateDispatchAction extends KalturaRequest<number> {
    id: number;
    scope: KalturaEventNotificationScope;
    constructor(data: EventNotificationTemplateDispatchActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
