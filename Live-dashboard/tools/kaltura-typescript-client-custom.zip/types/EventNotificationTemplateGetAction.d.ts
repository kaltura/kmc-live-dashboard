import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaEventNotificationTemplate } from './KalturaEventNotificationTemplate';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface EventNotificationTemplateGetActionArgs extends KalturaRequestArgs {
    id: number;
}
/**
* Retrieve an event notification template object by id
**/
export declare class EventNotificationTemplateGetAction extends KalturaRequest<KalturaEventNotificationTemplate> {
    id: number;
    constructor(data: EventNotificationTemplateGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
