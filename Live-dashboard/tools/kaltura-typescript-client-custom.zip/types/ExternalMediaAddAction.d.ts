import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaExternalMediaEntry } from './KalturaExternalMediaEntry';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ExternalMediaAddActionArgs extends KalturaRequestArgs {
    entry: KalturaExternalMediaEntry;
}
/**
* Add external media entry
**/
export declare class ExternalMediaAddAction extends KalturaRequest<KalturaExternalMediaEntry> {
    entry: KalturaExternalMediaEntry;
    constructor(data: ExternalMediaAddActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
