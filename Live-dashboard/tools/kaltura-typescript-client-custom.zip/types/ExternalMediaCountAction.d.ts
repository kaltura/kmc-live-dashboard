import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaExternalMediaEntryFilter } from './KalturaExternalMediaEntryFilter';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ExternalMediaCountActionArgs extends KalturaRequestArgs {
    filter?: KalturaExternalMediaEntryFilter;
}
/**
* Count media entries by filter.
**/
export declare class ExternalMediaCountAction extends KalturaRequest<number> {
    filter: KalturaExternalMediaEntryFilter;
    constructor(data?: ExternalMediaCountActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
