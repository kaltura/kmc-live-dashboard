import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ExternalMediaDeleteActionArgs extends KalturaRequestArgs {
    id: string;
}
/**
* Delete a external media entry.
**/
export declare class ExternalMediaDeleteAction extends KalturaRequest<void> {
    id: string;
    constructor(data: ExternalMediaDeleteActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
