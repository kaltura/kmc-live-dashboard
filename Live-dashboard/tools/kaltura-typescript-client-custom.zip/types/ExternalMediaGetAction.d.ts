import { KalturaObjectMetadata } from '../kaltura-object-base';
import { KalturaExternalMediaEntry } from './KalturaExternalMediaEntry';
import { KalturaRequest, KalturaRequestArgs } from '../kaltura-request';
export interface ExternalMediaGetActionArgs extends KalturaRequestArgs {
    id: string;
}
/**
* Get external media entry by ID.
**/
export declare class ExternalMediaGetAction extends KalturaRequest<KalturaExternalMediaEntry> {
    id: string;
    constructor(data: ExternalMediaGetActionArgs);
    protected _getMetadata(): KalturaObjectMetadata;
}
